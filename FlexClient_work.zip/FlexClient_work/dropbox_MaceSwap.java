/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_239
 *  net.minecraft.class_2596
 *  net.minecraft.class_2824
 *  net.minecraft.class_2868
 *  net.minecraft.class_3966
 *  net.minecraft.class_5321
 *  net.minecraft.class_6880
 *  net.minecraft.class_9304
 *  net.minecraft.class_9362
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.mixin.MinecraftClientAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9362;

public final class MaceSwap
extends Module
implements TickListener,
AttackListener {
    private final ModeSetting<SwapMode> swapMode = (ModeSetting)new ModeSetting<SwapMode>(EncryptedString.of("Mode"), SwapMode.Silent, SwapMode.class).setDescription(EncryptedString.of("Silent: Packet based (fastest), Normal: Client side swap"));
    private final NumberSetting minFallDistance = (NumberSetting)new NumberSetting(EncryptedString.of("Min Fall Distance"), 0.1, 10.0, 1.5, 0.1).setDescription(EncryptedString.of("Minimum fall distance to trigger auto mace swap"));
    private final NumberSetting densityThreshold = (NumberSetting)new NumberSetting(EncryptedString.of("Density Threshold"), 1.0, 20.0, 7.0, 0.5).setDescription(EncryptedString.of("Fall distance to switch from Breach to Density Mace"));
    private final BooleanSetting targetPlayers = new BooleanSetting(EncryptedString.of("Target Players"), true);
    private final BooleanSetting targetMobs = new BooleanSetting(EncryptedString.of("Target Mobs"), false);
    private final BooleanSetting noPassive = new BooleanSetting(EncryptedString.of("No Passive Mobs"), true);
    private final BooleanSetting autoSwitchBack = new BooleanSetting(EncryptedString.of("Auto Switch Back"), true);
    private final BooleanSetting stayOnMace = new BooleanSetting(EncryptedString.of("Stay On Mace"), false);
    private final BooleanSetting breachSwap = (BooleanSetting)new BooleanSetting(EncryptedString.of("Smart Swap"), true).setDescription(EncryptedString.of("Specifically targets Mace with Breach/Density enchantment on hit"));
    private final BooleanSetting stunLink = (BooleanSetting)new BooleanSetting(EncryptedString.of("Shield Stun Link"), true).setDescription(EncryptedString.of("Automatically swap and hit with mace when Shield Disabler stuns a target"));
    private double fallStartY = -1.0;
    private boolean isFalling = false;
    private boolean maceHit = false;
    private boolean needsSwapBack = false;
    private int originalSlot = -1;
    private int ticksWaited = 0;

    public MaceSwap() {
        super(EncryptedString.of("Mace Swap"), EncryptedString.of("Auto swaps to mace on fall/hit for maximum damage"), -1, Category.COMBAT);
        this.addSettings(this.swapMode, this.minFallDistance, this.densityThreshold, this.targetPlayers, this.targetMobs, this.noPassive, this.autoSwitchBack, this.stayOnMace, this.breachSwap, this.stunLink);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(AttackListener.class, this);
        this.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(AttackListener.class, this);
        if (this.needsSwapBack && this.mc.field_1724 != null && this.originalSlot != -1) {
            this.forceSwap(this.originalSlot);
        }
        this.reset();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc.field_1724 != null && this.mc.field_1755 == null) {
            if (this.needsSwapBack) {
                ++this.ticksWaited;
                if (this.ticksWaited >= 1) {
                    if (!this.stayOnMace.getValue()) {
                        this.forceSwap(this.originalSlot);
                    }
                    this.needsSwapBack = false;
                    this.originalSlot = -1;
                }
            } else {
                this.updateFall();
                if (this.isFalling && !(this.mc.field_1724.method_18798().field_1351 >= -0.1)) {
                    int mace;
                    boolean shouldMace;
                    class_1309 target;
                    class_3966 eHit;
                    double fallDist = this.getCurrentFallDistance();
                    class_239 class_2392 = this.mc.field_1765;
                    if (class_2392 instanceof class_3966 && (class_2392 = (eHit = (class_3966)class_2392).method_17782()) instanceof class_1309 && this.hasValidTarget(target = (class_1309)class_2392) && (shouldMace = this.canTriggerMace(fallDist)) && !this.maceHit && (mace = this.getAppropriateMace(fallDist)) != -1 && this.mc.field_1724.method_31548().method_67532() != mace) {
                        if (this.originalSlot == -1) {
                            this.originalSlot = this.mc.field_1724.method_31548().method_67532();
                        }
                        this.forceSwap(mace);
                        if (this.swapMode.isMode(SwapMode.Silent)) {
                            this.mc.method_1562().method_52787((class_2596)class_2824.method_34206((class_1297)target, (boolean)this.mc.field_1724.method_5715()));
                            this.mc.field_1724.method_6104(class_1268.field_5808);
                        } else {
                            ((MinecraftClientAccessor)this.mc).invokeDoAttack();
                        }
                        this.maceHit = true;
                        this.needsSwapBack = true;
                        this.ticksWaited = 0;
                    }
                }
            }
        }
    }

    private void updateFall() {
        boolean onGround = this.mc.field_1724.method_24828();
        boolean falling = this.mc.field_1724.method_18798().field_1351 < -0.1;
        boolean rising = this.mc.field_1724.method_18798().field_1351 > 0.1;
        double currentY = this.mc.field_1724.method_23318();
        if (onGround) {
            if (this.isFalling) {
                this.isFalling = false;
                this.fallStartY = -1.0;
                this.maceHit = false;
            }
            if (this.originalSlot != -1 && !this.stayOnMace.getValue() && !this.needsSwapBack) {
                this.forceSwap(this.originalSlot);
                this.originalSlot = -1;
            }
        } else {
            if (rising && this.maceHit) {
                this.maceHit = false;
                this.fallStartY = currentY;
            }
            if (!this.isFalling) {
                this.isFalling = true;
                this.fallStartY = currentY;
                this.maceHit = false;
            } else if (falling && this.fallStartY != -1.0 && currentY > this.fallStartY) {
                this.fallStartY = currentY;
            }
        }
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        class_1309 target;
        class_3966 eHit;
        class_239 class_2392;
        if (this.breachSwap.getValue() && this.mc.field_1724 != null && this.mc.field_1765 != null && !this.needsSwapBack && (class_2392 = this.mc.field_1765) instanceof class_3966 && (class_2392 = (eHit = (class_3966)class_2392).method_17782()) instanceof class_1309 && this.hasValidTarget(target = (class_1309)class_2392)) {
            this.updateFall();
            double fallDist = this.getCurrentFallDistance();
            if (!this.canTriggerMace(fallDist)) {
                return;
            }
            int mace = this.getAppropriateMace(fallDist);
            if (mace != -1 && this.mc.field_1724.method_31548().method_67532() != mace) {
                this.originalSlot = this.mc.field_1724.method_31548().method_67532();
                if (this.swapMode.isMode(SwapMode.Silent)) {
                    this.mc.method_1562().method_52787((class_2596)new class_2868(mace));
                    this.mc.method_1562().method_52787((class_2596)class_2824.method_34206((class_1297)target, (boolean)this.mc.field_1724.method_5715()));
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                    this.needsSwapBack = true;
                    this.ticksWaited = 0;
                    event.cancel();
                    return;
                }
                this.mc.field_1724.method_31548().method_61496(mace);
                this.syncOnce();
                this.needsSwapBack = true;
                this.ticksWaited = 0;
            }
        }
    }

    private double getCurrentFallDistance() {
        double trackedFall = this.fallStartY == -1.0 ? 0.0 : Math.max(0.0, this.fallStartY - this.mc.field_1724.method_23318());
        return Math.max(trackedFall, this.mc.field_1724.field_6017);
    }

    private boolean canTriggerMace(double fallDistance) {
        return this.isFalling && this.mc.field_1724.method_18798().field_1351 < -0.1 && fallDistance >= this.minFallDistance.getValue();
    }

    private int getAppropriateMace(double fallDistance) {
        int targetSlot;
        boolean useDensity = fallDistance >= this.densityThreshold.getValue();
        int n = targetSlot = useDensity ? this.findMaceWithEnchant("density") : this.findMaceWithEnchant("breach");
        if (targetSlot == -1) {
            targetSlot = this.findAnyMaceSlot();
        }
        return targetSlot;
    }

    private int findMaceWithEnchant(String name) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!(stack.method_7909() instanceof class_9362)) continue;
            class_9304 enchants = stack.method_58657();
            for (class_6880 entry : enchants.method_57534()) {
                if (!entry.method_40230().isPresent() || !((class_5321)entry.method_40230().get()).method_29177().method_12832().contains(name)) continue;
                return i;
            }
        }
        return -1;
    }

    private int findAnyMaceSlot() {
        for (int i = 0; i < 9; ++i) {
            if (!(this.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_9362)) continue;
            return i;
        }
        return -1;
    }

    private void forceSwap(int slot) {
        this.mc.field_1724.method_31548().method_61496(slot);
        if (this.mc.method_1562() != null) {
            this.mc.method_1562().method_52787((class_2596)new class_2868(slot));
        }
        this.syncOnce();
    }

    private boolean hasValidTarget(class_1309 e) {
        if (e == this.mc.field_1724 || !e.method_5805() || e.method_7325()) {
            return false;
        }
        if (e instanceof class_1657) {
            return this.targetPlayers.getValue();
        }
        return !this.targetMobs.getValue() ? false : !this.noPassive.getValue() || !(e instanceof class_1296);
    }

    private void syncOnce() {
        if (this.mc.field_1761 != null) {
            ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
        }
    }

    private void reset() {
        this.fallStartY = -1.0;
        this.isFalling = false;
        this.maceHit = false;
        this.needsSwapBack = false;
        this.originalSlot = -1;
        this.ticksWaited = 0;
    }

    public static enum SwapMode {
        Silent,
        Normal;

    }
}
