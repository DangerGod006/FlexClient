/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_239
 *  net.minecraft.class_3966
 *  org.lwjgl.glfw.GLFW
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class ShieldDisabler
extends Module
implements TickListener,
AttackListener {
    private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
    private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
    private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
    private final NumberSetting stunTiming = (NumberSetting)new NumberSetting(EncryptedString.of("Stun Timing"), 0.0, 100.0, 10.0, 1.0).setDescription(EncryptedString.of("Timing for stun hits (lower = faster)"));
    private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), false);
    private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);
    private final KeybindSetting activateKey = (KeybindSetting)new KeybindSetting(EncryptedString.of("Activate Key"), -1, false).setDescription(EncryptedString.of("Hold this key to do sword -> axe shield stun. None = always active"));
    private final BooleanSetting swordStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Sword Stun"), true).setDescription(EncryptedString.of("When holding a sword, swap to axe, stun shield, then swap back"));
    private final BooleanSetting manualAxeStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Manual Axe Stun"), true).setDescription(EncryptedString.of("If you manually switch to axe while target shields, hit instantly and stay on axe"));
    private final BooleanSetting automaticStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Automatic Stun"), true).setDescription(EncryptedString.of("Automatically detects shield and swaps to axe from sword/any held item"));
    public static boolean isStunning = false;
    int previousSlot;
    int hitClock;
    int switchClock;
    int stunClock;
    private boolean didMainHit;

    public ShieldDisabler() {
        super(EncryptedString.of("Shield Disabler"), EncryptedString.of("Automatically disables your opponents shield"), -1, Category.COMBAT);
        this.addSettings(this.switchDelay, this.hitDelay, this.switchBack, this.stun, this.stunTiming, this.clickSimulate, this.requireHoldAxe, this.activateKey, this.swordStun, this.manualAxeStun, this.automaticStun);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(AttackListener.class, this);
        this.hitClock = this.hitDelay.getValueInt();
        this.switchClock = this.switchDelay.getValueInt();
        this.stunClock = 0;
        this.previousSlot = -1;
        isStunning = false;
        this.didMainHit = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(AttackListener.class, this);
        isStunning = false;
        this.previousSlot = -1;
        this.didMainHit = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null && this.mc.field_1755 == null) {
            isStunning = false;
            class_1657 target = this.getCrosshairPlayer();
            if (target == null || this.mc.field_1724.method_6115()) {
                this.resetIfNeeded();
            } else if (!WorldUtils.isShieldFacingAway(target) && ShieldDisabler.isBlockingWithShield(target)) {
                boolean shouldStun;
                class_1799 heldStack = this.mc.field_1724.method_6047();
                boolean holdingAxe = ShieldDisabler.isAxe(heldStack);
                boolean holdingSword = ShieldDisabler.isSword(heldStack);
                boolean keyActive = this.isActivationPressed();
                boolean hasActivationKey = this.activateKey.getKey() != -1;
                boolean manualInstant = this.manualAxeStun.getValue() && holdingAxe;
                boolean swordKeyStun = this.swordStun.getValue() && holdingSword && keyActive;
                boolean automatic = this.automaticStun.getValue();
                boolean keySwapStun = hasActivationKey && keyActive;
                boolean bl = shouldStun = manualInstant || swordKeyStun || automatic || keySwapStun;
                if ((!this.requireHoldAxe.getValue() || holdingAxe || swordKeyStun || automatic || keySwapStun) && shouldStun && (!manualInstant || !this.didMainHit)) {
                    if (this.previousSlot == -1 && !manualInstant) {
                        this.previousSlot = this.getReturnSlot(false);
                    }
                    if (this.switchClock > 0 && !manualInstant) {
                        --this.switchClock;
                    } else if (holdingAxe || this.selectAxeAndSync()) {
                        if (this.stun.getValue() && this.didMainHit) {
                            if (this.stunClock > 0) {
                                --this.stunClock;
                            } else {
                                this.hitShield(target);
                                this.stunClock = this.stunTiming.getValueInt();
                                this.didMainHit = false;
                                if (!manualInstant) {
                                    this.switchBackToSwordOrPrevious();
                                }
                            }
                        } else if (this.hitClock > 0 && !manualInstant && !automatic) {
                            --this.hitClock;
                        } else {
                            this.hitShield(target);
                            this.didMainHit = true;
                            this.hitClock = this.hitDelay.getValueInt();
                            this.switchClock = this.switchDelay.getValueInt();
                            if (!manualInstant) {
                                this.switchBackToSwordOrPrevious();
                            }
                        }
                    }
                }
            } else {
                this.resetIfNeeded();
            }
        }
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (event != null && this.mc != null && this.mc.method_22683() != null && GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), (int)0) != 1 && this.hitClock > 0) {
            event.cancel();
        }
    }

    private class_1657 getCrosshairPlayer() {
        class_239 hitResult = this.mc.field_1765;
        if (!(hitResult instanceof class_3966)) {
            return null;
        }
        class_1297 entity = ((class_3966)hitResult).method_17782();
        return entity instanceof class_1657 ? (class_1657)entity : null;
    }

    private static boolean isBlockingWithShield(class_1657 player) {
        try {
            return player != null && player.method_24518(class_1802.field_8255) && player.method_6039();
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isActivationPressed() {
        try {
            int key = this.activateKey.getKey();
            return key == -1 || KeyUtils.isKeyPressed(key);
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private boolean selectAxeAndSync() {
        try {
            if (!InventoryUtils.selectAxe()) {
                return false;
            }
            this.syncSelectedSlot();
            return true;
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private void hitShield(class_1657 player) {
        isStunning = true;
        if (this.clickSimulate.getValue()) {
            MouseSimulation.mouseClick(0);
        }
        WorldUtils.hitEntity((class_1297)player, true);
    }

    private int getReturnSlot(boolean holdingAxe) {
        int selected = this.mc.field_1724.method_31548().method_67532();
        if (!holdingAxe) {
            return selected;
        }
        int swordSlot = InventoryUtils.getSwordSlot();
        return swordSlot != -1 ? swordSlot : selected;
    }

    private void switchBackToSwordOrPrevious() {
        if (!this.switchBack.getValue()) {
            this.previousSlot = -1;
        } else {
            int swordSlot;
            int slot = this.previousSlot;
            if ((slot < 0 || slot > 8 || ShieldDisabler.isAxe(this.mc.field_1724.method_31548().method_5438(slot))) && (swordSlot = InventoryUtils.getSwordSlot()) != -1) {
                slot = swordSlot;
            }
            this.setSlotAndSync(slot);
            this.previousSlot = -1;
        }
    }

    private void resetIfNeeded() {
        if (this.previousSlot != -1) {
            this.switchBackToSwordOrPrevious();
        }
        this.stunClock = 0;
        this.didMainHit = false;
        isStunning = false;
    }

    private void setSlotAndSync(int slot) {
        if (slot >= 0 && slot <= 8) {
            this.mc.field_1724.method_31548().method_61496(slot);
            this.syncSelectedSlot();
        }
    }

    private void syncSelectedSlot() {
        try {
            ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static boolean isSword(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && WorldUtils.isSword(stack);
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isAxe(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && WorldUtils.isAxe(stack);
        }
        catch (Throwable ignored) {
            return false;
        }
    }
}
