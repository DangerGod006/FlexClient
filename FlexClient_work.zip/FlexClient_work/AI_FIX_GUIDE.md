# FlexClient 2.0 - Complete Combat Modules Diagnostic & AI Fix Guide

## 1. Directory Structure & Key Files
- `FlexClient2.0_original_backup.jar`: Original untouched version of FlexClient 2.0 (440,206 bytes) before any modifications.
- `FlexClient2.0_current_modded.jar`: Current rebuilt version with modern UI, XP bar corruption fix, and modular combat improvements.
- `decompiled/dev/lvstrng/argon/module/modules/combat/SpearSwap.java`: Main SpearSwap module source.
- `decompiled/dev/lvstrng/argon/module/modules/combat/MaceSwap.java`: Main MaceSwap + Stun Slam module source.
- `decompiled/dev/lvstrng/argon/module/modules/combat/ShieldDisabler.java`: Main ShieldDisabler module source.
- `decompiled/dev/lvstrng/argon/utils/SwapCoordinator.java`: Concurrency lock manager between combat modules.
- `decompiled/dev/lvstrng/argon/mixin/LivingEntityAccessor.java`: Accessor providing `setLastAttackedTicks(int)` for instant 100% weapon strength.
- `decompiled/dev/lvstrng/argon/mixin/MinecraftClientAccessor.java`: Accessor providing `invokeDoAttack()` and `setAttackCooldown(int)`.

---

## 2. History: Original Code State vs What Was Changed

### A. The Original State (Before Changes):
1. **SpearSwap (Original):**
   - Originally from `argon-main`.
   - It only hooked `onAttack` (left-click on triggerSlot) and `onButtonPress` (activateKey).
   - In both cases, it only called `((MinecraftClientAccessor)mc).invokeDoAttack()`.
   - It had a basic timer check that switched back after 1 tick.
   - **Flaws in Original:**
     - Vanilla `invokeDoAttack()` only hits if crosshair is directly intersecting an entity within vanilla 3.0 blocks reach.
     - Spear reach is 4.5+ blocks. If the target was 3.1 to 4.5 blocks away, `invokeDoAttack()` saw `MISS` or `BLOCK` and did nothing!
     - When pressing `Activate Key`, if looking at a block or open air, no swing was visually played or it attempted to mine the ground block.
     - Sometimes corrupted `player.experienceProgress` (`field_7510 > 1.0f`).

2. **MaceSwap (Original):**
   - Originally triggered Mace hit during fall attacks.
   - Did not properly coordinate with SpearSwap or ShieldDisabler, causing conflicting item swaps (swapping to mace while another module swapped to axe).
   - "Stun Slam" (Axe hit to disable shield followed by Mace hit) was unreliable because it lacked tick-separated phase transitions.

3. **ShieldDisabler (Original):**
   - Attempted to swap from sword to axe when target raised a shield.
   - Suffered from race conditions, missing target validations, and lack of synchronization with MaceSwap/SpearSwap.

---

### B. What Was Changed & Current Status:
1. **XP Progress Bar Safeguard:**
   - Added `if (mc.player.experienceProgress > 1.0f) mc.player.experienceProgress = 0.0f;` across tick events to prevent graphical XP bar stretching.
2. **SwapCoordinator Lock System:**
   - Created `SwapCoordinator.java` providing atomic thread-safe locks (`requestLock`, `releaseLock`, `isLockedByOther`) with 350ms stale timeout to prevent modules from fighting over the player's active hotbar slot.
3. **Attack Cooldown & Weapon Strength Management:**
   - Used `((LivingEntityAccessor)player).setLastAttackedTicks(20)` to ensure any weapon strike immediately lands at 100% full attack strength.
   - Used `((MinecraftClientAccessor)mc).setAttackCooldown(0)` to prevent the client click timer from swallowing inputs.
4. **Target Reach Scanner:**
   - Added 3-tier target detection in `SpearSwap` and `MaceSwap`:
     1. Vanilla `crosshairTarget` if entity.
     2. Raycast using `WorldUtils.getEntityInReach(reach)` up to effective reach.
     3. Aim cone search (~56 degrees) up to reach.

---

## 3. The Root Cause of the Anticheat Kick ("BadPackets / Invalid Sequence")

When the user pressed `Activate Key`, the server anticheat instantly kicked them. Here is the exact technical reason:
In `SpearSwap.java` -> `performAttack()`:
```java
class_1297 target = this.getTarget();
if (target != null) {
    this.mc.field_1724.method_6104(class_1268.field_5808); // Packet 1: HandSwingC2SPacket
    this.mc.field_1761.method_2918(this.mc.field_1724, target); // Packet 2: PlayerInteractEntityC2SPacket
} else {
    this.mc.field_1724.method_6104(class_1268.field_5808); // Packet 1: HandSwingC2SPacket
    ((MinecraftClientAccessor)this.mc).invokeDoAttack(); // Packet 2: doAttack() sends SECOND HandSwing or PlayerAction!
}
MouseSimulation.mouseClick(0); // Packet 3: Dispatches GLFW click, triggering doAttack() a THIRD time!
```
**Why Anticheats Kick:**
- Strict anticheats (Polar, GrimAC, Vulcan) monitor the sequence of player packets per tick.
- Sending **2 to 3 `HandSwingC2SPacket`** in the exact same frame, or sending an attack packet followed by a simulated mouse click event and block attack packet, triggers `BadPackets[DoubleSwing]` or `InvalidActionSequence`.
- In addition, if `MouseSimulation.mouseClick(0)` runs on the same frame, the client's internal mouse state gets out of sync with the network stream.

---

## 4. The Exact Required Fix for the Next AI

### Rule 1: Single Dedicated Attack Call (Eliminate Double Swings)
In `SpearSwap`, `MaceSwap`, and `ShieldDisabler`:
- **Remove** `MouseSimulation.mouseClick(0)` completely from automated packet sequences.
- If target exists in reach:
  ```java
  // 1. Reset cooldown to 100%
  ((LivingEntityAccessor)mc.player).setLastAttackedTicks(20);
  // 2. ONE swing hand
  mc.player.swingHand(class_1268.field_5808);
  // 3. ONE attack entity packet
  mc.interactionManager.attackEntity(mc.player, target);
  ```
- If NO target exists (swinging at air):
  ```java
  // ONE swing hand only! Do NOT call invokeDoAttack() or mouseClick!
  mc.player.swingHand(class_1268.field_5808);
  ```

### Rule 2: Strict 1-Tick Slot Holding (Prevent Fast-Switch Kicks)
- When swapping slots:
  ```java
  InventoryUtils.setInvSlot(weaponSlot);
  this.performAttack();
  this.delayTicks = Math.max(1, this.restoreDelay.getValueInt());
  this.state = State.WAITING_SYNC;
  return; // Return immediately, do NOT restore on the same tick!
  ```
- Inside `onTick()`:
  ```java
  if (this.state == State.WAITING_SYNC) {
      if (this.delayTicks > 0) {
          --this.delayTicks;
          return;
      }
      this.finish(); // Restores original slot only after >= 1 tick has elapsed!
  }
  ```

### Rule 3: Anticheat Reach Limit Enforcement
- When `Undetectable` is enabled:
  - Max reach MUST be capped at **3.25 blocks** (or 3.0 blocks for strict vanilla servers).
  - Never allow direct `attackEntity()` calls beyond 3.25 blocks on servers running Polar/GrimAC.

### Rule 4: ShieldDisabler & Stun Slam Staging
- For Axe Shield disable:
  1. Slot -> Axe
  2. Attack shielding opponent -> disables shield
  3. Wait 1 tick (`delayTicks = 1`)
  4. (For Stun Slam) Slot -> Mace -> Attack target
  5. Wait 1 tick -> restore original slot.

---

## 5. Build & Compilation Instructions
```powershell
$libs = (Get-ChildItem "C:\Users\WAHAJ\Documents\Plugins_Making\flexclient-fabric\libs\*.jar" | Select-Object -ExpandProperty FullName) -join ";"
$lwjgl = "C:\Users\WAHAJ\AppData\Roaming\.fastclient\libraries\org\lwjgl\lwjgl-glfw\3.3.3\lwjgl-glfw-3.3.3.jar"
$jspecify = "C:\Users\WAHAJ\AppData\Roaming\.fastclient\libraries\org\jspecify\jspecify\1.0.0\jspecify-1.0.0.jar"
$fastutil = "C:\Users\WAHAJ\AppData\Roaming\.fastclient\libraries\it\unimi\dsi\fastutil\8.5.18\fastutil-8.5.18.jar"
$fastclientHud = "C:\Users\WAHAJ\AppData\Roaming\.fastclient\profiles\1.21.11-Fabric\mods\fastclient-hud-1.21.11-latest.jar"
$jar = "C:\Users\WAHAJ\Downloads\FlexClient2.0.jar"
$cp = "$jar;$libs;$lwjgl;$jspecify;$fastutil;$fastclientHud"

# Compile modified classes
javac --release 21 -cp $cp -d "C:\Users\WAHAJ\Downloads\FlexClient_work\classes" `
  "C:\Users\WAHAJ\Downloads\FlexClient_work\decompiled\dev\lvstrng\argon\mixin\LivingEntityAccessor.java" `
  "C:\Users\WAHAJ\Downloads\FlexClient_work\decompiled\dev\lvstrng\argon\module\modules\combat\SpearSwap.java" `
  "C:\Users\WAHAJ\Downloads\FlexClient_work\decompiled\dev\lvstrng\argon\module\modules\combat\MaceSwap.java" `
  "C:\Users\WAHAJ\Downloads\FlexClient_work\decompiled\dev\lvstrng\argon\module\modules\combat\ShieldDisabler.java"

# Package and deploy
Copy-Item -Path "C:\Users\WAHAJ\Downloads\FlexClient_work\classes\*" -Destination "C:\Users\WAHAJ\Downloads\FlexClient_work\test_unzip\" -Recurse -Force
Push-Location "C:\Users\WAHAJ\Downloads\FlexClient_work\test_unzip"
jar cfm "..\FlexClient_rebuilt.jar" "META-INF\MANIFEST.MF" .
Pop-Location

# Deploy to active client locations
Copy-Item "C:\Users\WAHAJ\Downloads\FlexClient_work\FlexClient_rebuilt.jar" -Destination "C:\Users\WAHAJ\Downloads\FlexClient2.0.jar" -Force
Copy-Item "C:\Users\WAHAJ\Downloads\FlexClient_work\FlexClient_rebuilt.jar" -Destination "C:\Users\WAHAJ\AppData\Roaming\.fastclient\profiles\1.21.11-Fabric\mods\FlexClient2.0.jar" -Force
```
