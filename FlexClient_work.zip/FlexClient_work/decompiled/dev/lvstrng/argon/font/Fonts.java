/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.font;

import dev.lvstrng.argon.font.GlyphPageFontRenderer;

public final class Fonts {
    public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/immediatelyfast/font/font.ttf", 40, false, false, false);
}

