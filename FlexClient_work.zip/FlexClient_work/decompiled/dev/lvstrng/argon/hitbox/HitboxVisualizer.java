/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.hitbox;

import dev.lvstrng.argon.hitbox.VisualizationContext;

public interface HitboxVisualizer {
    public String id();

    default public boolean isAvailable() {
        return true;
    }

    public void onFrame(VisualizationContext var1);
}

