/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 */
package dev.lvstrng.argon.hitbox;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.hitbox.EffectiveAttackHitbox;
import dev.lvstrng.argon.hitbox.HitboxVisualizer;
import dev.lvstrng.argon.hitbox.VisualizationContext;
import dev.lvstrng.argon.module.modules.combat.AttackHitbox;
import dev.lvstrng.argon.module.modules.render.Hitbox;
import dev.lvstrng.argon.utils.Log;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_238;

public final class EffectiveAttackHitboxProvider {
    private static final List<HitboxVisualizer> VISUALIZERS = new CopyOnWriteArrayList<HitboxVisualizer>();
    private static long lastDebugLog;

    private EffectiveAttackHitboxProvider() {
    }

    public static EffectiveAttackHitbox of(class_1297 entity, float tickDelta) {
        if (entity == null) {
            return null;
        }
        return EffectiveAttackHitbox.of(entity, tickDelta);
    }

    public static class_238 combatBox(class_1297 entity, double margin) {
        EffectiveAttackHitbox hitbox = EffectiveAttackHitboxProvider.of(entity, Float.NaN);
        if (hitbox == null) {
            return entity.method_5829();
        }
        return margin != 0.0 ? hitbox.effective().method_1014(margin) : hitbox.effective();
    }

    public static class_238 effectiveBox(class_1297 entity, float tickDelta) {
        EffectiveAttackHitbox hitbox = EffectiveAttackHitboxProvider.of(entity, tickDelta);
        return hitbox == null ? null : hitbox.effective();
    }

    public static class_238 vanillaBox(class_1297 entity, float tickDelta) {
        EffectiveAttackHitbox hitbox = EffectiveAttackHitboxProvider.of(entity, tickDelta);
        return hitbox == null ? null : hitbox.vanilla();
    }

    public static class_238 boundsForVisualization(EffectiveAttackHitbox hitbox, boolean useEffectiveBounds) {
        if (hitbox == null) {
            return null;
        }
        return useEffectiveBounds && hitbox.isActive() ? hitbox.effective() : hitbox.vanilla();
    }

    public static class_238 boundsForDebugHitbox(class_1297 entity, class_238 vanillaBox) {
        Hitbox render = EffectiveAttackHitboxProvider.renderModule();
        if (entity == null || render == null || !render.isShowAttackHitboxInDebugHitbox()) {
            return vanillaBox;
        }
        EffectiveAttackHitbox hitbox = EffectiveAttackHitboxProvider.of(entity, Float.NaN);
        if (hitbox == null || !hitbox.isActive()) {
            return vanillaBox;
        }
        class_238 effective = hitbox.effective();
        EffectiveAttackHitboxProvider.logDebugBounds(render, entity, vanillaBox, effective);
        return effective;
    }

    private static void logDebugBounds(Hitbox render, class_1297 entity, class_238 vanillaBox, class_238 effective) {
        if (!render.isDebugHitboxLogging()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastDebugLog < 1000L) {
            return;
        }
        lastDebugLog = now;
        Log.info("[Hitbox] F3+B bounds | entity=%s | vanilla=%s | effective=%s | expansion=%.2f", entity.method_5864().method_5897().getString(), EffectiveAttackHitboxProvider.format(vanillaBox), EffectiveAttackHitboxProvider.format(effective), EffectiveAttackHitboxProvider.expansion());
    }

    private static String format(class_238 box) {
        return box == null ? "null" : String.format("[%.2f %.2f %.2f -> %.2f %.2f %.2f]", box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324);
    }

    public static double expansion() {
        AttackHitbox module = EffectiveAttackHitboxProvider.module();
        return module != null && module.isEnabled() ? module.getExpansion() : 0.0;
    }

    public static boolean isActive() {
        AttackHitbox module = EffectiveAttackHitboxProvider.module();
        return module != null && module.isCombatActive();
    }

    public static boolean allowsThroughWallsTargeting() {
        AttackHitbox module = EffectiveAttackHitboxProvider.module();
        return module != null && module.isEnabled() && module.allowsThroughWalls();
    }

    private static AttackHitbox module() {
        Argon argon = Argon.INSTANCE;
        return argon == null ? null : argon.getModuleManager().getModule(AttackHitbox.class);
    }

    private static Hitbox renderModule() {
        Argon argon = Argon.INSTANCE;
        return argon == null ? null : argon.getModuleManager().getModule(Hitbox.class);
    }

    public static void register(HitboxVisualizer visualizer) {
        if (visualizer == null) {
            return;
        }
        for (HitboxVisualizer existing : VISUALIZERS) {
            if (!existing.id().equals(visualizer.id())) continue;
            return;
        }
        VISUALIZERS.add(visualizer);
    }

    public static boolean unregister(HitboxVisualizer visualizer) {
        return VISUALIZERS.remove(visualizer);
    }

    public static List<HitboxVisualizer> visualizers() {
        return VISUALIZERS;
    }

    public static boolean dispatch(VisualizationContext context) {
        for (HitboxVisualizer visualizer : VISUALIZERS) {
            if (!visualizer.isAvailable()) continue;
            try {
                visualizer.onFrame(context);
            }
            catch (Exception e) {
                Log.error("Hitbox visualizer '" + visualizer.id() + "' failed", e);
            }
        }
        return context.isHandled();
    }
}

