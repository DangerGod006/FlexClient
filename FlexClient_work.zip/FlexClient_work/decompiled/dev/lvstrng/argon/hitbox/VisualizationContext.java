/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4587
 */
package dev.lvstrng.argon.hitbox;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitbox;
import java.util.List;
import net.minecraft.class_4587;

public final class VisualizationContext {
    private final class_4587 matrices;
    private final List<EffectiveAttackHitbox> boxes;
    private final float tickDelta;
    private final boolean useEffectiveBounds;
    private boolean handled;

    public VisualizationContext(class_4587 matrices, List<EffectiveAttackHitbox> boxes, float tickDelta, boolean useEffectiveBounds) {
        this.matrices = matrices;
        this.boxes = boxes;
        this.tickDelta = tickDelta;
        this.useEffectiveBounds = useEffectiveBounds;
    }

    public class_4587 matrices() {
        return this.matrices;
    }

    public List<EffectiveAttackHitbox> boxes() {
        return this.boxes;
    }

    public float tickDelta() {
        return this.tickDelta;
    }

    public boolean usesEffectiveBounds() {
        return this.useEffectiveBounds;
    }

    public void markHandled() {
        this.handled = true;
    }

    public boolean isHandled() {
        return this.handled;
    }
}

