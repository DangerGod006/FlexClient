/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_4587
 */
package dev.lvstrng.argon.hitbox.compat;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import dev.lvstrng.argon.utils.RenderUtils;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_4587;

public final class VanillaDebugHitboxCompat {
    private VanillaDebugHitboxCompat() {
    }

    public static boolean shouldStayVanilla() {
        return !EffectiveAttackHitboxProvider.isActive();
    }

    public static class_238 boxMinecraftWouldDraw(class_1297 entity, float tickDelta) {
        return EffectiveAttackHitboxProvider.vanillaBox(entity, tickDelta);
    }

    public static void drawVanillaLayer(class_4587 matrices, List<class_238> boxes, int alpha) {
        RenderUtils.renderBoxOutlines(matrices, boxes, new Color(255, 255, 255, alpha), 1.0f);
    }
}

