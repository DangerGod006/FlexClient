/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_238
 */
package dev.lvstrng.argon.hitbox.compat;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitbox;
import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import dev.lvstrng.argon.hitbox.HitboxVisualizer;
import dev.lvstrng.argon.hitbox.VisualizationContext;
import dev.lvstrng.argon.utils.Log;
import dev.lvstrng.argon.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_238;

public final class BetterHitRegCompat
implements HitboxVisualizer {
    private static final String MOD_ID = "betterhitreg";
    private final List<class_238> batch = new ArrayList<class_238>();
    private boolean logged;

    @Override
    public String id() {
        return MOD_ID;
    }

    @Override
    public boolean isAvailable() {
        return FabricLoader.getInstance().isModLoaded(MOD_ID);
    }

    @Override
    public void onFrame(VisualizationContext context) {
        if (context.boxes().isEmpty()) {
            return;
        }
        if (!this.logged) {
            this.logged = true;
            Log.info("[Hitbox] Better HitReg detected - its 'render target hitbox' shows the normal entity box; the Attack Hitbox is drawn alongside it using the same effective bounds combat uses. Better HitReg is not modified.");
        }
        this.batch.clear();
        for (EffectiveAttackHitbox hitbox : context.boxes()) {
            class_238 box = EffectiveAttackHitboxProvider.boundsForVisualization(hitbox, context.usesEffectiveBounds());
            if (box == null) continue;
            this.batch.add(box);
        }
        if (this.batch.isEmpty()) {
            return;
        }
        Color color = RenderUtils.accentColor(255);
        RenderUtils.renderBoxOutlines(context.matrices(), this.batch, color, 2.0f);
        context.markHandled();
    }

    public static void initialize() {
        EffectiveAttackHitboxProvider.register(new BetterHitRegCompat());
        if (FabricLoader.getInstance().isModLoaded(MOD_ID)) {
            Log.info("[Hitbox] Better HitReg compatibility adapter registered");
        }
    }
}

