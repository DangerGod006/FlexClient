/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_3532
 */
package dev.lvstrng.argon.hitbox;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_3532;

public final class EffectiveAttackHitbox {
    private final class_1297 entity;
    private final class_238 vanilla;
    private final class_238 effective;
    private final double expansion;
    private final boolean active;

    EffectiveAttackHitbox(class_1297 entity, class_238 vanilla, class_238 effective, double expansion, boolean active) {
        this.entity = entity;
        this.vanilla = vanilla;
        this.effective = effective;
        this.expansion = expansion;
        this.active = active;
    }

    static EffectiveAttackHitbox of(class_1297 entity, float tickDelta) {
        class_238 box = entity.method_5829();
        if (!Float.isNaN(tickDelta)) {
            double x = class_3532.method_16436((double)tickDelta, (double)entity.field_6014, (double)entity.method_23317());
            double y = class_3532.method_16436((double)tickDelta, (double)entity.field_6036, (double)entity.method_23318());
            double z = class_3532.method_16436((double)tickDelta, (double)entity.field_5969, (double)entity.method_23321());
            box = box.method_989(x - entity.method_23317(), y - entity.method_23318(), z - entity.method_23321());
        }
        double expansion = EffectiveAttackHitboxProvider.expansion();
        boolean active = EffectiveAttackHitboxProvider.isActive();
        class_238 effective = expansion != 0.0 ? box.method_1014(expansion) : box;
        return new EffectiveAttackHitbox(entity, box, effective, expansion, active);
    }

    public class_1297 entity() {
        return this.entity;
    }

    public class_238 vanilla() {
        return this.vanilla;
    }

    public class_238 effective() {
        return this.effective;
    }

    public double expansion() {
        return this.expansion;
    }

    public boolean isActive() {
        return this.active;
    }

    public boolean isExpanded() {
        return this.expansion != 0.0;
    }

    public class_238 toDraw() {
        return this.active ? this.effective : this.vanilla;
    }
}

