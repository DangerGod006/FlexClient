package dev.lvstrng.argon.gui.components;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.Window;
import dev.lvstrng.argon.gui.components.settings.CheckBox;
import dev.lvstrng.argon.gui.components.settings.KeybindBox;
import dev.lvstrng.argon.gui.components.settings.MinMaxSlider;
import dev.lvstrng.argon.gui.components.settings.ModeBox;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.gui.components.settings.Slider;
import dev.lvstrng.argon.gui.components.settings.StringBox;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.MinMaxSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.module.setting.StringSetting;
import dev.lvstrng.argon.utils.AnimationUtils;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ModuleButton {
    public Window parent;
    public Module module;
    public int offset;
    public int settingOffset;
    public Color currentColor;
    public Color currentAlpha;
    public List<RenderableSetting> settings = new ArrayList<RenderableSetting>();
    public Color defaultColor = CatleanTheme.TEXT_PRIMARY;
    public AnimationUtils animation = new AnimationUtils(0.0);
    public boolean extended = false;
    private float hoverProgress = 0.0f;
    private float toggleProgress = 0.0f;

    public ModuleButton(Window parent, Module module, int offset) {
        this.parent = parent;
        this.module = module;
        this.offset = offset;
        this.settingOffset = parent.getHeight();
        this.toggleProgress = module.isEnabled() ? 1.0f : 0.0f;

        for (Setting<?> setting : module.getSettings()) {
            if (setting instanceof BooleanSetting) {
                this.settings.add(new CheckBox(this, (BooleanSetting)setting, this.settingOffset));
            } else if (setting instanceof NumberSetting) {
                this.settings.add(new Slider(this, (NumberSetting)setting, this.settingOffset));
            } else if (setting instanceof ModeSetting) {
                this.settings.add(new ModeBox(this, (ModeSetting)setting, this.settingOffset));
            } else if (setting instanceof KeybindSetting) {
                this.settings.add(new KeybindBox(this, (KeybindSetting)setting, this.settingOffset));
            } else if (setting instanceof StringSetting) {
                this.settings.add(new StringBox(this, (StringSetting)setting, this.settingOffset));
            } else if (setting instanceof MinMaxSetting) {
                this.settings.add(new MinMaxSlider(this, (MinMaxSetting)setting, this.settingOffset));
            }
            this.settingOffset += 36;
        }
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int screenH = class_310.method_1551().method_22683().method_4507();
        if (this.parent.getY() + this.offset > screenH) {
            return;
        }

        if (this.extended || this.animation.getValue() > (double)this.parent.getHeight()) {
            for (RenderableSetting renderableSetting : this.settings) {
                renderableSetting.onUpdate();
            }
        }

        int btnX = this.parent.getX();
        int btnY = this.parent.getY() + this.offset;
        int btnW = this.parent.getWidth();
        int btnH = this.parent.getHeight();

        // Smoothly animate toggle progress
        float targetToggle = this.module.isEnabled() ? 1.0f : 0.0f;
        this.toggleProgress += (targetToggle - this.toggleProgress) * Math.min(1.0f, 0.2f * delta);

        // Smoothly animate hover progress
        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.dragging;
        float targetHover = hovered ? 1.0f : 0.0f;
        this.hoverProgress += (targetHover - this.hoverProgress) * Math.min(1.0f, 0.25f * delta);

        // Background color blending
        Color idleBg = CatleanTheme.BG_MODULE_IDLE;
        Color hoverBg = CatleanTheme.BG_MODULE_HOVER;
        Color baseBg = CatleanTheme.blendColors(idleBg, hoverBg, this.hoverProgress);

        boolean isLast = this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this;
        double bottomRadius = (isLast && !this.extended) ? 10.0 : 0.0;

        if (bottomRadius > 0.0) {
            CatleanTheme.drawRoundedRect(context, btnX, btnY, btnW, btnH, 0.0, 0.0, bottomRadius, bottomRadius, baseBg);
        } else {
            context.method_25294(btnX, btnY, btnX + btnW, btnY + btnH, baseBg.getRGB());
        }

        // Active tint overlay when enabled
        Color accent = CatleanTheme.getAccentColor(255);
        if (this.toggleProgress > 0.01f) {
            int tintAlpha = (int)(22.0f * this.toggleProgress);
            Color activeTint = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), tintAlpha);
            if (bottomRadius > 0.0) {
                CatleanTheme.drawRoundedRect(context, btnX, btnY, btnW, btnH, 0.0, 0.0, bottomRadius, bottomRadius, activeTint);
            } else {
                context.method_25294(btnX, btnY, btnX + btnW, btnY + btnH, activeTint.getRGB());
            }

            // CatLean vibrant left accent indicator bar
            int barHeight = Math.max(4, btnH - 12);
            int barY = btnY + (btnH - barHeight) / 2;
            int barAlpha = (int)(255.0f * this.toggleProgress);
            Color barColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), barAlpha);
            CatleanTheme.drawRoundedRect(context, btnX + 4, barY, 3, barHeight, 1.5, barColor);
        }

        // Module text color transition
        Color textColor = CatleanTheme.blendColors(CatleanTheme.TEXT_PRIMARY, accent, this.toggleProgress);

        CharSequence nameChars = this.module.getName();
        int textX = btnX + (this.toggleProgress > 0.1f ? 14 : 12);
        TextRenderer.drawString(nameChars, context, textX, btnY + (btnH - 8) / 2 - 2, textColor.getRGB());

        // Right side indicators (CatLean style: "..." for settings, [KEY] for keybind)
        int rightOffset = btnX + btnW - 10;

        if (!this.settings.isEmpty()) {
            String dots = "...";
            int dotsW = TextRenderer.getWidth(dots);
            rightOffset -= dotsW;
            Color dotsColor = this.extended ? accent : (hovered ? CatleanTheme.TEXT_SECONDARY : CatleanTheme.TEXT_MUTED);
            TextRenderer.drawString(dots, context, rightOffset, btnY + (btnH - 8) / 2 - 2, dotsColor.getRGB());
            rightOffset -= 6;
        }

        boolean isClickGuiModule = (this.module instanceof ClickGUI) || this.module.getName().toString().equalsIgnoreCase("DANGER");
        if (!isClickGuiModule && this.module.getKey() != -1 && this.module.getKey() != 0) {
            String keyStr = "[" + KeyUtils.getKey(this.module.getKey()) + "]";
            int keyW = TextRenderer.getWidth(keyStr);
            rightOffset -= keyW;
            TextRenderer.drawString(keyStr, context, rightOffset, btnY + (btnH - 8) / 2 - 2, CatleanTheme.TEXT_MUTED.getRGB());
        }

        // Subtle row bottom divider
        if (!isLast) {
            context.method_25294(btnX + 8, btnY + btnH - 1, btnX + btnW - 8, btnY + btnH, new Color(255, 255, 255, 8).getRGB());
        }

        // Render settings drawer with smooth animation
        this.renderSettings(context, mouseX, mouseY, delta);

        for (RenderableSetting renderableSetting2 : this.settings) {
            if (!this.extended) continue;
            renderableSetting2.renderDescription(context, mouseX, mouseY, delta);
        }

        // Modern hover tooltip at bottom center
        if (hovered) {
            CharSequence desc = this.module.getDescription();
            if (desc != null && desc.length() > 0) {
                int tw = TextRenderer.getWidth(desc);
                int screenW = Argon.mc.method_22683().method_4480();
                int screenMidX = screenW / 2;
                int screenBotY = Argon.mc.method_22683().method_4507() - 40;
                int tipX = screenMidX - tw / 2 - 12;
                int tipW = tw + 24;
                int tipH = 22;

                CatleanTheme.drawModernCard(context, tipX, screenBotY, tipW, tipH, 6.0, CatleanTheme.BG_NAVBAR, CatleanTheme.BG_NAVBAR_BORDER);
                TextRenderer.drawString(desc, context, tipX + 12, screenBotY + 5, CatleanTheme.TEXT_PRIMARY.getRGB());
            }
        }
    }

    private void renderSettings(class_332 context, int mouseX, int mouseY, float delta) {
        int scissorX1 = this.parent.getX();
        int scissorY1 = this.parent.getY() + this.offset + this.parent.getHeight();
        int scissorX2 = scissorX1 + this.parent.getWidth();
        int scissorY2 = scissorY1 + (int)Math.max(0.0, this.animation.getValue() - (double)this.parent.getHeight());

        if (scissorY2 > scissorY1) {
            context.method_44379(scissorX1, scissorY1, scissorX2, scissorY2);

            // Settings drawer background
            context.method_25294(scissorX1, scissorY1, scissorX2, scissorY2, CatleanTheme.BG_SETTINGS.getRGB());

            // Left vertical branch line connecting settings to parent module
            Color accent = CatleanTheme.getAccentColor(255);
            int branchX = scissorX1 + 10;
            Color branchColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90);
            context.method_25294(branchX, scissorY1, branchX + 2, scissorY2, branchColor.getRGB());

            for (RenderableSetting renderableSetting : this.settings) {
                renderableSetting.render(context, mouseX, mouseY, delta);
            }

            context.method_44380();
        }
    }

    public void onExtend() {
        for (ModuleButton moduleButton : this.parent.moduleButtons) {
            if (moduleButton != this) {
                moduleButton.extended = false;
            }
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        for (RenderableSetting setting : this.settings) {
            setting.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.extended) {
            for (RenderableSetting renderableSetting : this.settings) {
                renderableSetting.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
            }
        }
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY)) {
            if (button == 2) {
                this.resetModuleSettings();
                return;
            }
            if (button == 0) {
                this.module.toggle();
            }
            if (button == 1) {
                if (this.module.getSettings().isEmpty()) {
                    return;
                }
                if (!this.extended) {
                    this.onExtend();
                }
                this.extended = !this.extended;
            }
        }
        if (this.extended) {
            for (RenderableSetting renderableSetting : this.settings) {
                renderableSetting.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    private void resetModuleSettings() {
        for (Setting<?> setting : this.module.getSettings()) {
            try {
                if (setting instanceof BooleanSetting) {
                    BooleanSetting booleanSetting = (BooleanSetting)setting;
                    booleanSetting.setValue(booleanSetting.getOriginalValue());
                } else if (setting instanceof NumberSetting) {
                    NumberSetting numberSetting = (NumberSetting)setting;
                    numberSetting.setValue(numberSetting.getOriginalValue());
                } else if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting)setting;
                    modeSetting.setModeIndex(modeSetting.getOriginalValue());
                } else if (setting instanceof KeybindSetting) {
                    KeybindSetting keybindSetting = (KeybindSetting)setting;
                    keybindSetting.setKey(keybindSetting.getOriginalKey());
                    keybindSetting.setListening(false);
                    if (keybindSetting.isModuleKey()) {
                        this.module.setKey(keybindSetting.getOriginalKey());
                    }
                } else if (setting instanceof MinMaxSetting) {
                    MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                    minMaxSetting.setMinValue(minMaxSetting.getOriginalMinValue());
                    minMaxSetting.setMaxValue(minMaxSetting.getOriginalMaxValue());
                } else if (setting instanceof StringSetting) {
                    StringSetting stringSetting = (StringSetting)setting;
                    stringSetting.setValue(stringSetting.getOriginalValue());
                }
            } catch (Throwable ignored) {}
        }
    }

    public void onGuiClose() {
        this.currentAlpha = null;
        this.currentColor = null;
        for (RenderableSetting renderableSetting : this.settings) {
            renderableSetting.onGuiClose();
        }
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        for (RenderableSetting renderableSetting : this.settings) {
            renderableSetting.mouseReleased(mouseX, mouseY, button);
        }
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX > (double)this.parent.getX() && mouseX < (double)(this.parent.getX() + this.parent.getWidth())
                && mouseY > (double)(this.parent.getY() + this.offset) && mouseY < (double)(this.parent.getY() + this.offset + this.parent.getHeight());
    }
}
