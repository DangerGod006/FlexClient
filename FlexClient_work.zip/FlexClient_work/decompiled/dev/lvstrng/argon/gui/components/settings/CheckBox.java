package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;

public final class CheckBox extends RenderableSetting {
    private final BooleanSetting setting;
    private Color currentAlpha;
    private float toggleProgress = 0.0f;

    public CheckBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (BooleanSetting)setting;
        this.toggleProgress = this.setting.getValue() ? 1.0f : 0.0f;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Animate toggle progress smoothly
        float target = this.setting.getValue() ? 1.0f : 0.0f;
        this.toggleProgress += (target - this.toggleProgress) * Math.min(1.0f, 0.25f * delta);

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, hovered ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Setting name
        CharSequence chars = this.setting.getName();
        Color accent = CatleanTheme.getAccentColor(255);
        Color nameColor = this.setting.getValue() ? CatleanTheme.TEXT_PRIMARY : CatleanTheme.TEXT_SECONDARY;
        int textY = cardY + (cardH - 8) / 2 - 1;
        TextRenderer.drawString(chars, context, cardX + 10, textY, nameColor.getRGB());

        // Modern CatLean animated pill toggle switch
        int switchW = 30;
        int switchH = 15;
        int switchX = cardX + cardW - switchW - 8;
        int switchY = cardY + (cardH - switchH) / 2;

        CatleanTheme.drawToggleSwitch(context, switchX, switchY, switchW, switchH, this.toggleProgress, CatleanTheme.BG_TOGGLE_OFF, accent);
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.mouseOver && this.parent.extended && keyCode == 259) {
            this.setting.setValue(this.setting.getOriginalValue());
        }
        super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY) && button == 0) {
            this.setting.toggle();
        }
        super.mouseClicked(mouseX, mouseY, button);
    }
}
