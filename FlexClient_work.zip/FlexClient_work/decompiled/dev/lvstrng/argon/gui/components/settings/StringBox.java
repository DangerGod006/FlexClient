package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.module.setting.StringSetting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class StringBox extends RenderableSetting {
    private final StringSetting setting;
    private Color currentAlpha;

    public StringBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (StringSetting)setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, hovered ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Setting name on left
        CharSequence nameChars = this.setting.getName();
        int textY = cardY + (cardH - 8) / 2 - 1;
        TextRenderer.drawString(nameChars, context, cardX + 10, textY, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Preview badge on right
        String preview = this.setting.getValue();
        if (preview.length() > 10) {
            preview = preview.substring(0, 9) + "...";
        }
        int textW = TextRenderer.getWidth(preview);
        int badgeW = Math.max(28, textW + 12);
        int badgeH = 18;
        int badgeX = cardX + cardW - badgeW - 8;
        int badgeY = cardY + (cardH - badgeH) / 2;

        CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 4.0, new Color(28, 36, 50, 200));
        CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 4.0, 1.0, new Color(255, 255, 255, 35));
        TextRenderer.drawString(preview, context, badgeX + (badgeW - textW) / 2, badgeY + 5, CatleanTheme.TEXT_PRIMARY.getRGB());
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY) && button == 0) {
            this.mc.method_1507(new class_437((class_2561)class_2561.method_43473()){
                private String content;
                {
                    this.content = StringBox.this.setting.getValue();
                }

                public void method_25394(class_332 context, int mouseXx, int mouseYx, float deltaTicks) {
                    RenderUtils.unscaledProjection(context);
                    super.method_25394(context, mouseXx *= class_310.method_1551().method_22683().method_4495(), mouseYx *= class_310.method_1551().method_22683().method_4495(), deltaTicks);
                    context.method_25294(0, 0, StringBox.this.mc.method_22683().method_4480(), StringBox.this.mc.method_22683().method_4507(), CatleanTheme.BG_OVERLAY.getRGB());
                    int screenMidX = StringBox.this.mc.method_22683().method_4480() / 2;
                    int screenMidY = StringBox.this.mc.method_22683().method_4507() / 2;
                    int contentWidth = Math.max(TextRenderer.getWidth(this.content), 500);
                    int width = contentWidth + 40;
                    int startX = screenMidX - width / 2;
                    int startY = screenMidY - 40;

                    // Modern dialog card
                    CatleanTheme.drawModernCard(context, startX, startY, width, 80, 10.0, CatleanTheme.BG_CARD, CatleanTheme.BG_CARD_BORDER);

                    // Title
                    Color accent = CatleanTheme.getAccentColor(255);
                    TextRenderer.drawCenteredString(StringBox.this.setting.getName(), context, screenMidX, startY + 10, accent.getRGB());

                    // Input box
                    int boxX = startX + 16;
                    int boxY = startY + 36;
                    int boxW = width - 32;
                    int boxH = 28;
                    CatleanTheme.drawRoundedRect(context, boxX, boxY, boxW, boxH, 6.0, new Color(12, 16, 24, 230));
                    CatleanTheme.drawRoundedOutline(context, boxX, boxY, boxW, boxH, 6.0, 1.0, new Color(255, 255, 255, 40));

                    // Text with blinking cursor
                    boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
                    String display = this.content + (blink ? "_" : "");
                    TextRenderer.drawString(display, context, boxX + 10, boxY + 8, CatleanTheme.TEXT_PRIMARY.getRGB());

                    RenderUtils.scaledProjection(context);
                }

                public boolean method_25404(class_11908 input) {
                    int keyCode = input.comp_4795();
                    if (keyCode == 256 || keyCode == 257) {
                        StringBox.this.setting.setValue(this.content.strip());
                        StringBox.this.mc.method_1507((class_437)Argon.INSTANCE.clickGui);
                        return true;
                    }
                    if (keyCode == 67 && (input.comp_4797() & 2) != 0) {
                        StringBox.this.mc.field_1774.method_1455(this.content);
                        return true;
                    }
                    if (keyCode == 86 && (input.comp_4797() & 2) != 0) {
                        this.content = this.content + StringBox.this.mc.field_1774.method_1460();
                        return true;
                    }
                    if (keyCode == 259) {
                        if (!this.content.isEmpty()) {
                            this.content = this.content.substring(0, this.content.length() - 1);
                        }
                        return true;
                    }
                    return super.method_25404(input);
                }

                public boolean method_25400(class_11905 input) {
                    if (!input.method_74227()) {
                        return super.method_25400(input);
                    }
                    this.content = this.content + input.method_74226();
                    return true;
                }

                public boolean method_25422() {
                    return false;
                }
            });
        }
        super.mouseClicked(mouseX, mouseY, button);
    }
}
