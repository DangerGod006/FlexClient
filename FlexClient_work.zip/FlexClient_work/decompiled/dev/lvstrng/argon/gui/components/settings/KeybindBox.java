package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;

public final class KeybindBox extends RenderableSetting {
    public KeybindSetting keybind;
    private Color currentAlpha;

    public KeybindBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.keybind = (KeybindSetting)setting;
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY)) {
            if (!this.keybind.isListening()) {
                if (button == 0) {
                    this.keybind.toggleListening();
                    this.keybind.setListening(true);
                }
            } else {
                if (this.keybind.isModuleKey()) {
                    this.parent.module.setKey(button);
                }
                this.keybind.setKey(button);
                this.keybind.setListening(false);
            }
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 259) {
            if (this.mouseOver) {
                if (this.keybind.isModuleKey()) {
                    this.parent.module.setKey(this.keybind.getOriginalKey());
                }
                this.keybind.setKey(this.keybind.getOriginalKey());
                this.keybind.setListening(false);
            }
        } else {
            if (this.keybind.isListening() && keyCode != 256) {
                if (this.keybind.isModuleKey()) {
                    this.parent.module.setKey(keyCode);
                }
                this.keybind.setKey(keyCode);
                this.keybind.setListening(false);
            }
            if (this.keybind.getKey() == 256) {
                if (this.keybind.isModuleKey()) {
                    this.parent.module.setKey(this.parent.module.getKey());
                }
                this.keybind.setKey(this.keybind.getKey());
                this.keybind.setListening(false);
            }
        }
        super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, (hovered || this.keybind.isListening()) ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Setting name on left (centered vertically)
        CharSequence nameChars = this.setting.getName();
        int textY = cardY + (cardH - 8) / 2 - 1;
        TextRenderer.drawString(nameChars, context, cardX + 10, textY, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Keycap badge on right (cleanly sized and centered)
        String keyText;
        Color badgeBorder;
        Color badgeBg;
        Color textColor;

        Color accent = CatleanTheme.getAccentColor(255);

        if (this.keybind.isListening()) {
            keyText = "...";
            float pulse = (float)(Math.sin((double)System.currentTimeMillis() / 150.0) * 0.4 + 0.6);
            int pulseAlpha = (int)(255.0f * pulse);
            badgeBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), pulseAlpha);
            badgeBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 60);
            textColor = accent;
        } else if (this.keybind.getKey() == -1) {
            keyText = "NONE";
            badgeBorder = new Color(255, 255, 255, 25);
            badgeBg = new Color(20, 26, 36, 180);
            textColor = CatleanTheme.TEXT_MUTED;
        } else {
            keyText = KeyUtils.getKey(this.keybind.getKey()).toString();
            badgeBorder = new Color(255, 255, 255, 45);
            badgeBg = new Color(28, 36, 50, 220);
            textColor = CatleanTheme.TEXT_PRIMARY;
        }

        int badgeTextW = TextRenderer.getWidth(keyText);
        int badgeW = Math.max(38, badgeTextW + 16);
        int badgeH = 20;
        int badgeX = cardX + cardW - badgeW - 10;
        int badgeY = cardY + (cardH - badgeH) / 2;

        CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 4.0, badgeBg);
        CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 4.0, 1.0, badgeBorder);
        TextRenderer.drawString(keyText, context, badgeX + (badgeW - badgeTextW) / 2, badgeY + 4, textColor.getRGB());
    }
}
