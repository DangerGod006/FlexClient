package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.MathUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class Slider extends RenderableSetting {
    public boolean dragging;
    public double offsetX;
    public double lerpedOffsetX = 0.0;
    private final NumberSetting setting;
    public Color currentColor1;
    public Color currentColor2;
    private Color currentAlpha;

    public Slider(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (NumberSetting)setting;
        double range = this.setting.getMax() - this.setting.getMin();
        double progress = range == 0.0 ? 0.0 : (this.setting.getValue() - this.setting.getMin()) / range;
        this.lerpedOffsetX = progress * (double)(parent.parent.getWidth() - 28);
    }

    @Override
    public void onUpdate() {
        Color clr = CatleanTheme.getAccentColor(255);
        this.currentColor1 = clr;
        this.currentColor2 = clr;
        super.onUpdate();
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, (hovered || this.dragging) ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Top: Setting name on left (cleanly spaced from slider track)
        CharSequence nameChars = this.setting.getName();
        TextRenderer.drawString(nameChars, context, cardX + 10, cardY + 5, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Top: Formatted value pill badge on right
        String valStr = String.valueOf(this.setting.getValue());
        if (valStr.endsWith(".0")) {
            valStr = valStr.substring(0, valStr.length() - 2);
        }
        int valWidth = TextRenderer.getWidth(valStr);
        int badgeW = valWidth + 14;
        int badgeH = 15;
        int badgeX = cardX + cardW - badgeW - 10;
        int badgeY = cardY + 3;

        Color accent = CatleanTheme.getAccentColor(255);
        Color badgeBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 35);
        Color badgeBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 120);
        CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 3.5, badgeBg);
        CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 3.5, 1.0, badgeBorder);
        TextRenderer.drawString(valStr, context, badgeX + (badgeW - valWidth) / 2, badgeY + (badgeH - 8) / 2 - 1, accent.getRGB());

        // Bottom: Slider track positioned with generous gap below text
        int trackX = cardX + 10;
        int trackW = cardW - 20;
        int trackY = cardY + 23;
        int trackH = 4;

        double range = this.setting.getMax() - this.setting.getMin();
        double progress = range == 0.0 ? 0.0 : (this.setting.getValue() - this.setting.getMin()) / range;
        this.offsetX = progress * (double)trackW;
        this.lerpedOffsetX = MathUtils.goodLerp((float)(0.4 * (double)delta), this.lerpedOffsetX, this.offsetX);

        // Draw track background
        CatleanTheme.drawRoundedRect(context, trackX, trackY, trackW, trackH, 2.0, CatleanTheme.BG_TRACK);

        // Draw filled progress track
        int fillW = Math.max(0, Math.min(trackW, (int)this.lerpedOffsetX));
        if (fillW > 0) {
            CatleanTheme.drawRoundedRect(context, trackX, trackY, fillW, trackH, 2.0, accent);
        }

        // Draggable circular knob with drop shadow
        int knobSize = 10;
        int knobX = (int)((double)trackX + this.lerpedOffsetX - (double)(knobSize / 2));
        int knobY = trackY + (trackH - knobSize) / 2;
        CatleanTheme.drawRoundedRect(context, knobX - 1, knobY - 1, knobSize + 2, knobSize + 2, 5.0, new Color(0, 0, 0, 90));
        CatleanTheme.drawRoundedRect(context, knobX, knobY, knobSize, knobSize, 5.0, Color.WHITE);
        if (this.dragging || hovered) {
            CatleanTheme.drawRoundedRect(context, knobX + 2, knobY + 2, knobSize - 4, knobSize - 4, 3.0, accent);
        } else {
            CatleanTheme.drawRoundedRect(context, knobX + 3, knobY + 3, knobSize - 6, knobSize - 6, 2.0, new Color(24, 32, 46));
        }
    }

    @Override
    public void onGuiClose() {
        this.currentColor1 = null;
        this.currentColor2 = null;
        super.onGuiClose();
    }

    private void slide(double mouseX) {
        int cardX = this.parentX() + 16;
        int cardW = this.parentWidth() - 24;
        int trackX = cardX + 10;
        int trackW = cardW - 20;
        double a = mouseX - (double)trackX;
        double b = class_3532.method_15350((double)(a / (double)trackW), 0.0, 1.0);
        this.setting.setValue(MathUtils.roundToDecimal(b * (this.setting.getMax() - this.setting.getMin()) + this.setting.getMin(), this.setting.getIncrement()));
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.mouseOver && this.parent.extended && keyCode == 259) {
            this.setting.setValue(this.setting.getOriginalValue());
        }
        super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY) && button == 0) {
            this.dragging = true;
            this.slide(mouseX);
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (this.dragging && button == 0) {
            this.dragging = false;
        }
        super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.dragging) {
            this.slide(mouseX);
        }
        super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }
}
