package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.MinMaxSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.MathUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class MinMaxSlider extends RenderableSetting {
    public boolean draggingMin;
    public boolean draggingMax;
    public double offsetMinX;
    public double offsetMaxX;
    public double lerpedOffsetMinX = 0.0;
    public double lerpedOffsetMaxX = 0.0;
    public MinMaxSetting setting;
    public Color currentColor1;
    public Color currentColor2;
    private Color currentAlpha;

    public MinMaxSlider(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (MinMaxSetting)setting;
        double range = this.setting.getMax() - this.setting.getMin();
        double pMin = range == 0.0 ? 0.0 : (this.setting.getMinValue() - this.setting.getMin()) / range;
        double pMax = range == 0.0 ? 1.0 : (this.setting.getMaxValue() - this.setting.getMin()) / range;
        int trackW = parent.parent.getWidth() - 32;
        this.lerpedOffsetMinX = pMin * (double)trackW;
        this.lerpedOffsetMaxX = pMax * (double)trackW;
    }

    @Override
    public void onUpdate() {
        Color clr = CatleanTheme.getAccentColor(255);
        this.currentColor1 = clr;
        this.currentColor2 = clr;
        super.onUpdate();
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, (hovered || this.draggingMin || this.draggingMax) ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Top: Setting name on left (cleanly spaced from track)
        CharSequence nameChars = this.setting.getName();
        TextRenderer.drawString(nameChars, context, cardX + 10, cardY + 5, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Top: Formatted range badge on right
        String minStr = String.valueOf(this.setting.getMinValue());
        String maxStr = String.valueOf(this.setting.getMaxValue());
        if (minStr.endsWith(".0")) minStr = minStr.substring(0, minStr.length() - 2);
        if (maxStr.endsWith(".0")) maxStr = maxStr.substring(0, maxStr.length() - 2);
        String rangeStr = minStr.equals(maxStr) ? minStr : minStr + " - " + maxStr;
        int rangeWidth = TextRenderer.getWidth(rangeStr);
        int badgeW = rangeWidth + 14;
        int badgeH = 15;
        int badgeX = cardX + cardW - badgeW - 10;
        int badgeY = cardY + 3;

        Color accent = CatleanTheme.getAccentColor(255);
        Color badgeBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 35);
        Color badgeBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 120);
        CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 3.5, badgeBg);
        CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 3.5, 1.0, badgeBorder);
        TextRenderer.drawString(rangeStr, context, badgeX + (badgeW - rangeWidth) / 2, badgeY + (badgeH - 8) / 2 - 1, accent.getRGB());

        // Bottom: Slider track dimensions with generous vertical spacing
        int trackX = cardX + 10;
        int trackW = cardW - 20;
        int trackY = cardY + 23;
        int trackH = 4;

        double range = this.setting.getMax() - this.setting.getMin();
        double pMin = range == 0.0 ? 0.0 : (this.setting.getMinValue() - this.setting.getMin()) / range;
        double pMax = range == 0.0 ? 1.0 : (this.setting.getMaxValue() - this.setting.getMin()) / range;

        this.offsetMinX = pMin * (double)trackW;
        this.offsetMaxX = pMax * (double)trackW;
        this.lerpedOffsetMinX = MathUtils.goodLerp((float)(0.4 * (double)delta), this.lerpedOffsetMinX, this.offsetMinX);
        this.lerpedOffsetMaxX = MathUtils.goodLerp((float)(0.4 * (double)delta), this.lerpedOffsetMaxX, this.offsetMaxX);

        // Draw track background
        CatleanTheme.drawRoundedRect(context, trackX, trackY, trackW, trackH, 2.0, CatleanTheme.BG_TRACK);

        // Draw range fill between knobs
        int fillStartX = trackX + (int)Math.min(this.lerpedOffsetMinX, this.lerpedOffsetMaxX);
        int fillW = Math.max(0, (int)Math.abs(this.lerpedOffsetMaxX - this.lerpedOffsetMinX));
        if (fillW > 0) {
            CatleanTheme.drawRoundedRect(context, fillStartX, trackY, fillW, trackH, 2.0, accent);
        }

        // Draw Min and Max knobs
        double knobMinX = (double)trackX + this.lerpedOffsetMinX;
        double knobMaxX = (double)trackX + this.lerpedOffsetMaxX;

        int knobSize = 10;
        int kMinX = (int)(knobMinX - (double)(knobSize / 2));
        int kMaxX = (int)(knobMaxX - (double)(knobSize / 2));
        int kY = trackY + (trackH - knobSize) / 2;

        CatleanTheme.drawRoundedRect(context, kMinX - 1, kY - 1, knobSize + 2, knobSize + 2, 5.0, new Color(0, 0, 0, 80));
        CatleanTheme.drawRoundedRect(context, kMinX, kY, knobSize, knobSize, 5.0, Color.WHITE);
        if (this.draggingMin) {
            CatleanTheme.drawRoundedRect(context, kMinX + 2, kY + 2, knobSize - 4, knobSize - 4, 3.0, accent);
        }

        CatleanTheme.drawRoundedRect(context, kMaxX - 1, kY - 1, knobSize + 2, knobSize + 2, 5.0, new Color(0, 0, 0, 80));
        CatleanTheme.drawRoundedRect(context, kMaxX, kY, knobSize, knobSize, 5.0, Color.WHITE);
        if (this.draggingMax) {
            CatleanTheme.drawRoundedRect(context, kMaxX + 2, kY + 2, knobSize - 4, knobSize - 4, 3.0, accent);
        }
    }

    @Override
    public void onGuiClose() {
        this.currentColor1 = null;
        this.currentColor2 = null;
        super.onGuiClose();
    }

    private void slideMin(double mouseX) {
        int cardX = this.parentX() + 16;
        int cardW = this.parentWidth() - 24;
        int trackX = cardX + 10;
        int trackW = cardW - 20;
        double a = mouseX - (double)trackX;
        double b = class_3532.method_15350((double)(a / (double)trackW), 0.0, 1.0);
        double val = MathUtils.roundToDecimal(b * (this.setting.getMax() - this.setting.getMin()) + this.setting.getMin(), this.setting.getIncrement());
        if (val <= this.setting.getMaxValue()) {
            this.setting.setMinValue(val);
        }
    }

    private void slideMax(double mouseX) {
        int cardX = this.parentX() + 16;
        int cardW = this.parentWidth() - 24;
        int trackX = cardX + 10;
        int trackW = cardW - 20;
        double a = mouseX - (double)trackX;
        double b = class_3532.method_15350((double)(a / (double)trackW), 0.0, 1.0);
        double val = MathUtils.roundToDecimal(b * (this.setting.getMax() - this.setting.getMin()) + this.setting.getMin(), this.setting.getIncrement());
        if (val >= this.setting.getMinValue()) {
            this.setting.setMaxValue(val);
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.isHovered(mouseX, mouseY)) {
            int cardX = this.parentX() + 16;
            int trackX = cardX + 10;
            double distMin = Math.abs(mouseX - ((double)trackX + this.lerpedOffsetMinX));
            double distMax = Math.abs(mouseX - ((double)trackX + this.lerpedOffsetMaxX));
            if (distMin <= distMax) {
                this.draggingMin = true;
                this.slideMin(mouseX);
            } else {
                this.draggingMax = true;
                this.slideMax(mouseX);
            }
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.draggingMin = false;
            this.draggingMax = false;
        }
        super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.draggingMin) {
            this.slideMin(mouseX);
        } else if (this.draggingMax) {
            this.slideMax(mouseX);
        }
        super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }
}
