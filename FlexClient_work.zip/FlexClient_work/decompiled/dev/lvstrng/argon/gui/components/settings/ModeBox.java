package dev.lvstrng.argon.gui.components.settings;

import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.gui.components.settings.RenderableSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;

public final class ModeBox extends RenderableSetting {
    public final ModeSetting<?> setting;
    private Color currentAlpha;

    public ModeBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (ModeSetting)setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int curX = this.parentX();
        int curY = this.parentY() + this.parentOffset() + this.offset;
        int curWidth = this.parentWidth();
        int curHeight = this.settingHeight();

        // Sub-panel card inset
        int cardX = curX + 16;
        int cardW = curWidth - 24;
        int cardY = curY + 2;
        int cardH = curHeight - 4;

        boolean hovered = this.isHovered(mouseX, mouseY) && !this.parent.parent.dragging;
        Color rowBg = hovered ? new Color(24, 32, 46, 220) : new Color(14, 19, 28, 180);
        CatleanTheme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 5.0, rowBg);
        CatleanTheme.drawRoundedOutline(context, cardX, cardY, cardW, cardH, 5.0, 1.0, hovered ? new Color(255, 255, 255, 28) : new Color(255, 255, 255, 12));

        // Setting name on left
        CharSequence nameChars = this.setting.getName();
        int textY = cardY + (cardH - 8) / 2 - 1;
        TextRenderer.drawString(nameChars, context, cardX + 10, textY, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Mode name badge on right (CatLean style: "◂ Mode ▸")
        String rawMode = ((Enum)this.setting.getMode()).name();
        String modeName = "◂ " + rawMode + " ▸";
        int badgeTextWidth = TextRenderer.getWidth(modeName);
        int badgeW = badgeTextWidth + 16;
        int badgeH = 18;
        int badgeX = cardX + cardW - badgeW - 10;
        int badgeY = cardY + (cardH - badgeH) / 2;

        Color accent = CatleanTheme.getAccentColor(255);
        Color badgeBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 35);
        Color badgeBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 120);

        CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 4.0, badgeBg);
        CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 4.0, 1.0, badgeBorder);
        TextRenderer.drawString(modeName, context, badgeX + (badgeW - badgeTextWidth) / 2, badgeY + (badgeH - 8) / 2 - 1, accent.getRGB());
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.mouseOver && this.parent.extended && keyCode == 259) {
            this.setting.setModeIndex(this.setting.getOriginalValue());
        }
        super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY) && button == 0) {
            this.setting.cycle();
        }
        super.mouseClicked(mouseX, mouseY, button);
    }
}
