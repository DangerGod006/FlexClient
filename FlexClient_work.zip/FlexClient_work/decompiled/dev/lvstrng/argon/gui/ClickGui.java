package dev.lvstrng.argon.gui;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.Window;
import dev.lvstrng.argon.managers.ConfigManager;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ClickGui extends class_437 {
    public List<Window> windows = new ArrayList<Window>();
    public Color currentColor;

    // Top Navigation Tabs: 0 = Modules, 1 = Themes, 2 = Config
    private int activeTab = 0;
    private final String[] navTabs = new String[]{"Modules", "Themes", "Config"};
    private final int navW = 480;
    private final int navH = 36;

    // Movable / Draggable Search Bar
    private String searchQuery = "";
    private boolean searchFocused = false;
    private int searchX = -1;
    private int searchY = -1;
    private final int searchW = 540;
    private final int searchH = 42;
    private boolean searchDragging = false;
    private int searchDragX = 0;
    private int searchDragY = 0;

    // Config Manager State
    private String newConfigName = "";
    private boolean configInputFocused = false;
    private String configStatusMessage = "";
    private long configStatusTime = 0;

    // Theme Customizer dragging state: -1 = none, 0 = Red, 1 = Green, 2 = Blue, 3 = Alpha
    private int draggingThemeSlider = -1;

    // Screen dimension cache to auto-align windows when resized or maximized
    private int lastScreenW = -1;
    private int lastScreenH = -1;

    public ClickGui() {
        super((class_2561)class_2561.method_43473());
        this.initWindows();
    }

    private void initWindows() {
        this.windows.clear();
        for (Category category : Category.values()) {
            this.windows.add(new Window(0, 54, 285, 28, category, this));
        }
        this.layoutWindows();
    }

    public void layoutWindows() {
        class_1041 win = class_310.method_1551().method_22683();
        int screenW = (win != null) ? win.method_4480() : 1920;
        int numWindows = this.windows.size();
        if (numWindows == 0) return;

        int targetWinW = 285;
        int gap = 24;
        int totalW = numWindows * targetWinW + (numWindows - 1) * gap;
        if (totalW > screenW - 60) {
            targetWinW = Math.max(220, (screenW - 60 - (numWindows - 1) * 14) / numWindows);
            gap = Math.max(10, (screenW - 60 - numWindows * targetWinW) / Math.max(1, numWindows - 1));
            totalW = numWindows * targetWinW + (numWindows - 1) * gap;
        }
        int startX = Math.max(30, (screenW - totalW) / 2);

        for (int i = 0; i < numWindows; ++i) {
            Window window = this.windows.get(i);
            window.setWidth(targetWinW);
            window.setX(startX + i * (targetWinW + gap));
            window.setY(54);
        }
    }

    public void resetSearchPosition() {
        class_1041 win = class_310.method_1551().method_22683();
        int screenW = (win != null) ? win.method_4480() : 1920;
        int screenH = (win != null) ? win.method_4507() : 1080;
        float scaleFactor = (float)class_310.method_1551().method_22683().method_4495();
        this.searchX = (screenW - this.searchW) / 2;
        int hotbarHeightRaw = (int)(56.0f * scaleFactor);
        this.searchY = screenH - hotbarHeightRaw - this.searchH - 8;
    }

    public boolean isSearching() {
        return this.searchQuery != null && !this.searchQuery.isEmpty();
    }

    public String getSearchQuery() {
        return this.searchQuery;
    }

    public boolean isDraggingAlready() {
        if (this.searchDragging) return true;
        for (Window window : this.windows) {
            if (window.dragging) return true;
        }
        return false;
    }

    @Override
    protected void method_25426() { // init()
        super.method_25426();
        this.layoutWindows();
        this.resetSearchPosition();
    }

    protected void method_56131() {
        if (this.field_22787 != null) {
            super.method_56131();
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        if (Argon.mc.field_1755 == this) {
            // Guard against recursion crash
            if (Argon.INSTANCE.previousScreen != null && Argon.INSTANCE.previousScreen != this && !(Argon.INSTANCE.previousScreen instanceof ClickGui)) {
                Argon.INSTANCE.previousScreen.method_25394(context, 0, 0, deltaTicks);
            }

            int toBgAlpha = ClickGUI.background.getValue() ? 190 : 130;
            this.currentColor = this.currentColor == null ? new Color(0, 0, 0, 0) : new Color(0, 0, 0, this.currentColor.getAlpha());
            if (this.currentColor.getAlpha() != toBgAlpha) {
                this.currentColor = ColorUtils.smoothAlphaTransition(0.08f, toBgAlpha, this.currentColor);
            }

            int screenW = Argon.mc.method_22683().method_4480();
            int screenH = Argon.mc.method_22683().method_4507();

            // Auto-realign windows if screen dimensions changed (e.g. minimize -> full screen)
            if (this.lastScreenW != screenW || this.lastScreenH != screenH) {
                this.lastScreenW = screenW;
                this.lastScreenH = screenH;
                this.layoutWindows();
                this.resetSearchPosition();
            }

            if (this.searchX == -1 || this.searchY == -1) {
                this.resetSearchPosition();
            }

            // Background dim overlay
            context.method_25294(0, 0, screenW, screenH, this.currentColor.getRGB());

            RenderUtils.unscaledProjection(context);
            int rawMouseX = mouseX * class_310.method_1551().method_22683().method_4495();
            int rawMouseY = mouseY * class_310.method_1551().method_22683().method_4495();
            super.method_25394(context, rawMouseX, rawMouseY, deltaTicks);

            // 1. Top Navigation Bar (Modules, Themes, Config)
            this.renderTopNavBar(context, screenW, rawMouseX, rawMouseY);

            // 2. Render Current View depending on Active Tab
            if (this.activeTab == 0) {
                // Modules View: Search Bar underneath, Category Windows & expanded settings on top!
                this.renderMovableSearchBar(context, screenW, screenH, rawMouseX, rawMouseY);
                for (Window window : this.windows) {
                    window.render(context, rawMouseX, rawMouseY, deltaTicks);
                    window.updatePosition(rawMouseX, rawMouseY, deltaTicks);
                }
            } else if (this.activeTab == 1) {
                // Themes View: Full screen centered modern Theme Studio (Modules hidden!)
                this.renderThemePanel(context, screenW, screenH, rawMouseX, rawMouseY);
            } else if (this.activeTab == 2) {
                // Config View: Full screen centered CatLean-style Config Manager (Modules hidden!)
                this.renderConfigPanel(context, screenW, screenH, rawMouseX, rawMouseY);
            }

            // 3. Docked Controls Help Info Pill (Bottom-Right Corner)
            this.renderControlsHint(context, screenW, screenH, rawMouseX, rawMouseY);

            RenderUtils.scaledProjection(context);
        }
    }

    private void renderTopNavBar(class_332 context, int screenW, int mouseX, int mouseY) {
        int navX = (screenW - this.navW) / 2;
        int navY = 12;

        // Pill background & subtle border
        CatleanTheme.drawRoundedRect(context, navX, navY, this.navW, this.navH, 17.0, CatleanTheme.BG_NAVBAR);
        CatleanTheme.drawRoundedOutline(context, navX, navY, this.navW, this.navH, 17.0, 1.0, CatleanTheme.BG_NAVBAR_BORDER);

        int tabW = (this.navW - 8) / this.navTabs.length;
        for (int i = 0; i < this.navTabs.length; ++i) {
            int tx = navX + 4 + i * tabW;
            int ty = navY + 3;
            int th = this.navH - 6;
            boolean hovered = mouseX >= tx && mouseX <= tx + tabW && mouseY >= ty && mouseY <= ty + th;
            boolean active = (i == this.activeTab);

            if (active) {
                Color accent = CatleanTheme.getAccentColor(255);
                Color activeBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 50);
                Color activeBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 170);
                CatleanTheme.drawRoundedRect(context, tx, ty, tabW, th, 14.0, activeBg);
                CatleanTheme.drawRoundedOutline(context, tx, ty, tabW, th, 14.0, 1.0, activeBorder);
            } else if (hovered) {
                CatleanTheme.drawRoundedRect(context, tx, ty, tabW, th, 14.0, new Color(255, 255, 255, 16));
            }

            String title = this.navTabs[i];
            int textW = TextRenderer.getWidth(title);
            Color textCol = active ? CatleanTheme.getAccentColor(255) : (hovered ? CatleanTheme.TEXT_PRIMARY : CatleanTheme.TEXT_SECONDARY);
            TextRenderer.drawString(title, context, tx + (tabW - textW) / 2, ty + (th - 8) / 2 - 2, textCol.getRGB());
        }
    }

    private void renderMovableSearchBar(class_332 context, int screenW, int screenH, int mouseX, int mouseY) {
        // Pill background
        Color bg = new Color(13, 18, 28, 245);
        CatleanTheme.drawRoundedRect(context, this.searchX, this.searchY, this.searchW, this.searchH, 19.0, bg);

        // Border: accent glow if focused/active or dragging
        Color accent = CatleanTheme.getAccentColor(255);
        boolean hovered = mouseX >= this.searchX && mouseX <= this.searchX + this.searchW && mouseY >= this.searchY && mouseY <= this.searchY + this.searchH;
        Color border = (this.searchFocused || this.searchDragging) ? accent : (this.isSearching() || hovered ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 150) : CatleanTheme.BG_CARD_BORDER);
        CatleanTheme.drawRoundedOutline(context, this.searchX, this.searchY, this.searchW, this.searchH, 19.0, 1.0, border);

        int textY = this.searchY + (this.searchH - 8) / 2 - 2;

        // Search icon / tag on left
        TextRenderer.drawString("Search", context, this.searchX + 16, textY, accent.getRGB());
        TextRenderer.drawString(":", context, this.searchX + 16 + TextRenderer.getWidth("Search"), textY, CatleanTheme.TEXT_MUTED.getRGB());

        // Text input area
        int textX = this.searchX + 16 + TextRenderer.getWidth("Search:") + 8;
        boolean blink = (System.currentTimeMillis() / 450) % 2 == 0;
        String text = this.searchQuery.isEmpty() ? (this.searchFocused ? "_" : "type to filter modules...") : this.searchQuery + (this.searchFocused && blink ? "_" : "");
        Color textColor = this.searchQuery.isEmpty() ? CatleanTheme.TEXT_MUTED : CatleanTheme.TEXT_PRIMARY;
        TextRenderer.drawString(text, context, textX, textY, textColor.getRGB());

        // Clear button "✕" on right side
        if (!this.searchQuery.isEmpty()) {
            int closeX = this.searchX + this.searchW - 24;
            boolean hoverClose = mouseX >= closeX - 4 && mouseX <= closeX + 16 && mouseY >= this.searchY + 4 && mouseY <= this.searchY + this.searchH - 4;
            Color closeColor = hoverClose ? accent : CatleanTheme.TEXT_MUTED;
            TextRenderer.drawString("✕", context, closeX, textY, closeColor.getRGB());
        }
    }

    private void renderThemePanel(class_332 context, int screenW, int screenH, int mouseX, int mouseY) {
        Color accent = CatleanTheme.getAccentColor(255);
        int pw = Math.min(860, screenW - 40);
        int ph = Math.min(600, screenH - 50);
        int px = (screenW - pw) / 2;
        int py = Math.max(38, (screenH - ph) / 2);

        // Card background & outline
        CatleanTheme.drawRoundedRect(context, px, py, pw, ph, 12.0, new Color(13, 17, 26, 252));
        CatleanTheme.drawRoundedOutline(context, px, py, pw, ph, 12.0, 1.0, CatleanTheme.BG_CARD_BORDER);

        // Header Title & Subtitle with bold font and clean vertical gap
        TextRenderer.drawString("§l⚡ Theme & Visual Appearance", context, px + 26, py + 18, accent.getRGB());
        TextRenderer.drawString("Theme colors, live presets, and visual effects", context, px + 26, py + 38, CatleanTheme.TEXT_MUTED.getRGB());
        int sepY = py + 56;
        context.method_25294(px + 20, sepY, px + pw - 20, sepY + 1, CatleanTheme.BG_CARD_BORDER.getRGB());

        // 1. Color Presets Grid (with generous line space after header separator)
        int presetsLabelY = sepY + 22;
        TextRenderer.drawString("PRESET PALETTES", context, px + 26, presetsLabelY, CatleanTheme.TEXT_SECONDARY.getRGB());
        int btnW = (pw - 52 - 3 * 12) / 4;
        int btnH = 32;
        int startBtnX = px + 26;
        int startBtnY = presetsLabelY + 18;

        for (int i = 0; i < CatleanTheme.PRESETS.length; ++i) {
            CatleanTheme.ThemePreset p = CatleanTheme.PRESETS[i];
            int bx = startBtnX + (i % 4) * (btnW + 12);
            int by = startBtnY + (i / 4) * (btnH + 8);

            boolean hov = mouseX >= bx && mouseX <= bx + btnW && mouseY >= by && mouseY <= by + btnH;
            boolean selected = !ClickGUI.rainbow.getValue() && ClickGUI.red.getValueInt() == p.r && ClickGUI.green.getValueInt() == p.g && ClickGUI.blue.getValueInt() == p.b;

            Color dotCol = new Color(p.r, p.g, p.b);
            Color btnBg = selected ? new Color(p.r, p.g, p.b, 60) : (hov ? new Color(25, 34, 48, 240) : new Color(18, 24, 34, 220));
            CatleanTheme.drawRoundedRect(context, bx, by, btnW, btnH, 6.0, btnBg);
            Color borderCol = selected ? dotCol : (hov ? new Color(255, 255, 255, 60) : CatleanTheme.BG_CARD_BORDER);
            CatleanTheme.drawRoundedOutline(context, bx, by, btnW, btnH, 6.0, 1.0, borderCol);

            // Colored circle dot swatch
            CatleanTheme.drawRoundedRect(context, bx + 12, by + 11, 10, 10, 5.0, dotCol);
            // Preset name cleanly positioned
            TextRenderer.drawString(p.name, context, bx + 30, by + 8, selected ? CatleanTheme.TEXT_PRIMARY.getRGB() : CatleanTheme.TEXT_SECONDARY.getRGB());
        }

        // Divider 2
        int sepY2 = startBtnY + 2 * (btnH + 8) + 8;
        context.method_25294(px + 20, sepY2, px + pw - 20, sepY2 + 1, CatleanTheme.BG_CARD_BORDER.getRGB());

        // 2. Custom RGB Sliders & Live Switch Box
        int tunerLabelY = sepY2 + 16;
        TextRenderer.drawString("CUSTOM COLOR TUNER", context, px + 26, tunerLabelY, CatleanTheme.TEXT_SECONDARY.getRGB());

        // Live Switch Box on left (enclosed card with centered preview and text badge)
        int swatchX = px + 26;
        int swatchY = tunerLabelY + 18;
        int swatchW = 144;
        int swatchH = 168;
        CatleanTheme.drawRoundedRect(context, swatchX, swatchY, swatchW, swatchH, 8.0, new Color(18, 24, 34, 240));
        CatleanTheme.drawRoundedOutline(context, swatchX, swatchY, swatchW, swatchH, 8.0, 1.0, CatleanTheme.BG_CARD_BORDER);

        int previewCol = accent.getRGB();
        CatleanTheme.drawRoundedRect(context, swatchX + 10, swatchY + 10, swatchW - 20, 76, 6.0, new Color(previewCol, true));
        CatleanTheme.drawRoundedOutline(context, swatchX + 10, swatchY + 10, swatchW - 20, 76, 6.0, 1.0, new Color(255, 255, 255, 40));

        // Enclosed Live Switch Info Pod
        int infoY = swatchY + 94;
        int infoH = swatchH - 104;
        CatleanTheme.drawRoundedRect(context, swatchX + 10, infoY, swatchW - 20, infoH, 6.0, new Color(12, 16, 24, 230));
        CatleanTheme.drawRoundedOutline(context, swatchX + 10, infoY, swatchW - 20, infoH, 6.0, 1.0, CatleanTheme.BG_CARD_BORDER);

        int labelW = TextRenderer.getWidth("Live Switch");
        TextRenderer.drawString("Live Switch", context, swatchX + 10 + (swatchW - 20 - labelW) / 2, infoY + 8, CatleanTheme.TEXT_MUTED.getRGB());

        String hexStr = String.format("#%02X%02X%02X", accent.getRed(), accent.getGreen(), accent.getBlue());
        int hexTextW = TextRenderer.getWidth(hexStr);
        int hexBadgeW = hexTextW + 16;
        int hexBadgeH = 20;
        int hexBadgeX = swatchX + 10 + (swatchW - 20 - hexBadgeW) / 2;
        int hexBadgeY = infoY + 30;
        CatleanTheme.drawRoundedRect(context, hexBadgeX, hexBadgeY, hexBadgeW, hexBadgeH, 4.0, new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 40));
        CatleanTheme.drawRoundedOutline(context, hexBadgeX, hexBadgeY, hexBadgeW, hexBadgeH, 4.0, 1.0, accent);
        TextRenderer.drawString(hexStr, context, hexBadgeX + 8, hexBadgeY + 5, accent.getRGB());

        // Sliders on right (comfortable 42px row spacing)
        int sliderX = swatchX + swatchW + 24;
        int sliderW = pw - (sliderX - px) - 26;
        int startSliderY = swatchY;

        this.renderThemeSlider(context, sliderX, startSliderY, sliderW, "Red Channel", ClickGUI.red.getValueInt(), 255, new Color(244, 63, 94), mouseX, mouseY);
        this.renderThemeSlider(context, sliderX, startSliderY + 42, sliderW, "Green Channel", ClickGUI.green.getValueInt(), 255, new Color(16, 185, 129), mouseX, mouseY);
        this.renderThemeSlider(context, sliderX, startSliderY + 84, sliderW, "Blue Channel", ClickGUI.blue.getValueInt(), 255, new Color(59, 130, 246), mouseX, mouseY);
        this.renderThemeSlider(context, sliderX, startSliderY + 126, sliderW, "Window Opacity", ClickGUI.alphaWindow.getValueInt(), 255, accent, mouseX, mouseY);

        // Divider 3
        int sepY3 = swatchY + swatchH + 16;
        context.method_25294(px + 20, sepY3, px + pw - 20, sepY3 + 1, CatleanTheme.BG_CARD_BORDER.getRGB());

        // 3. Effects Toggles (Rainbow, Breathing, Background Dim)
        int effLabelY = sepY3 + 14;
        TextRenderer.drawString("EFFECTS & ENVIRONMENT", context, px + 26, effLabelY, CatleanTheme.TEXT_SECONDARY.getRGB());
        this.renderToggleRow(context, px + 26, effLabelY + 20, pw - 52, "Rainbow RGB Mode", ClickGUI.rainbow.getValue(), mouseX, mouseY);
        this.renderToggleRow(context, px + 26, effLabelY + 54, pw - 52, "Color Breathing Effect", ClickGUI.breathing.getValue(), mouseX, mouseY);
        this.renderToggleRow(context, px + 26, effLabelY + 88, pw - 52, "Background Blur & Dim", ClickGUI.background.getValue(), mouseX, mouseY);
    }

    private void renderThemeSlider(class_332 context, int x, int y, int w, String label, int value, int max, Color col, int mouseX, int mouseY) {
        TextRenderer.drawString(label, context, x, y, CatleanTheme.TEXT_PRIMARY.getRGB());
        String valStr = String.valueOf(value);
        int valW = TextRenderer.getWidth(valStr);
        TextRenderer.drawString(valStr, context, x + w - valW, y, col.getRGB());

        int trackY = y + 14;
        int trackH = 8;
        CatleanTheme.drawRoundedRect(context, x, trackY, w, trackH, 4.0, CatleanTheme.BG_TRACK);

        float pct = Math.max(0.0f, Math.min(1.0f, (float)value / (float)max));
        int fillW = (int)(w * pct);
        if (fillW > 0) {
            CatleanTheme.drawRoundedRect(context, x, trackY, fillW, trackH, 4.0, col);
        }

        // Circular knob with accent center
        int knobX = x + fillW;
        int knobY = trackY + trackH / 2;
        int knobRadius = 6;
        CatleanTheme.drawRoundedRect(context, knobX - knobRadius, knobY - knobRadius, knobRadius * 2, knobRadius * 2, knobRadius, Color.WHITE);
        CatleanTheme.drawRoundedRect(context, knobX - 3, knobY - 3, 6, 6, 3, col);
    }

    private void renderConfigPanel(class_332 context, int screenW, int screenH, int mouseX, int mouseY) {
        Color accent = CatleanTheme.getAccentColor(255);
        int pw = Math.min(860, screenW - 40);
        int ph = Math.min(600, screenH - 50);
        int px = (screenW - pw) / 2;
        int py = Math.max(38, (screenH - ph) / 2);

        // Card background & outline
        CatleanTheme.drawRoundedRect(context, px, py, pw, ph, 12.0, new Color(13, 17, 26, 252));
        CatleanTheme.drawRoundedOutline(context, px, py, pw, ph, 12.0, 1.0, CatleanTheme.BG_CARD_BORDER);

        // Header Title & Subtitle with bold font and clean vertical gap
        TextRenderer.drawString("§l⚡ Configuration Manager", context, px + 26, py + 18, accent.getRGB());
        TextRenderer.drawString("Manage client profiles, keybinds, and module settings", context, px + 26, py + 38, CatleanTheme.TEXT_MUTED.getRGB());
        int sepY = py + 56;
        context.method_25294(px + 20, sepY, px + pw - 20, sepY + 1, CatleanTheme.BG_CARD_BORDER.getRGB());

        // Top Row: Create / Save New Config Input Field (generous line space after divider!)
        int inputX = px + 26;
        int inputY = sepY + 22;
        int inputW = pw - 52 - 160;
        int inputH = 34;

        Color inputBorder = this.configInputFocused ? accent : CatleanTheme.BG_CARD_BORDER;
        CatleanTheme.drawRoundedRect(context, inputX, inputY, inputW, inputH, 6.0, new Color(18, 24, 34, 240));
        CatleanTheme.drawRoundedOutline(context, inputX, inputY, inputW, inputH, 6.0, 1.0, inputBorder);

        boolean blink = (System.currentTimeMillis() / 450) % 2 == 0;
        String inputText = this.newConfigName.isEmpty() ? (this.configInputFocused ? "_" : "Enter new profile name...") : this.newConfigName + (this.configInputFocused && blink ? "_" : "");
        Color inputColor = this.newConfigName.isEmpty() ? CatleanTheme.TEXT_MUTED : CatleanTheme.TEXT_PRIMARY;
        TextRenderer.drawString(inputText, context, inputX + 14, inputY + 10, inputColor.getRGB());

        // Save Profile Button
        int saveBtnX = inputX + inputW + 12;
        int saveBtnY = inputY;
        int saveBtnW = 148;
        int saveBtnH = inputH;
        this.renderActionButton(context, saveBtnX, saveBtnY, saveBtnW, saveBtnH, "+ Save Profile", mouseX, mouseY);

        // Status Toast Message
        if (!this.configStatusMessage.isEmpty() && System.currentTimeMillis() - this.configStatusTime < 3500) {
            TextRenderer.drawString(this.configStatusMessage, context, inputX + 14, inputY + inputH + 5, CatleanTheme.ACCENT_TEAL.getRGB());
        }

        // Section: Config Profiles List
        int listY = inputY + inputH + 20;
        TextRenderer.drawString("SAVED PROFILES", context, px + 26, listY, CatleanTheme.TEXT_SECONDARY.getRGB());

        List<String> configs = ConfigManager.listConfigs();
        String activeCfg = ConfigManager.getActiveConfig();

        int cardY = listY + 20;
        int cardH = 46;
        int gap = 8;
        int maxVisible = 6;

        for (int i = 0; i < Math.min(maxVisible, configs.size()); ++i) {
            String cfg = configs.get(i);
            int cy = cardY + i * (cardH + gap);
            boolean isActive = cfg.equalsIgnoreCase(activeCfg);

            // Row Card
            Color rowBg = isActive ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 35) : new Color(18, 24, 34, 220);
            CatleanTheme.drawRoundedRect(context, px + 26, cy, pw - 52, cardH, 6.0, rowBg);
            Color rowBorder = isActive ? accent : CatleanTheme.BG_CARD_BORDER;
            CatleanTheme.drawRoundedOutline(context, px + 26, cy, pw - 52, cardH, 6.0, 1.0, rowBorder);

            // Profile Name cleanly drawn without corrupt emoji
            int nameX = px + 42;
            int nameY = cy + (cardH - 8) / 2 - 1;
            TextRenderer.drawString(cfg, context, nameX, nameY, isActive ? CatleanTheme.TEXT_PRIMARY.getRGB() : CatleanTheme.TEXT_SECONDARY.getRGB());

            if (isActive) {
                int nameW = TextRenderer.getWidth(cfg);
                int actTextW = TextRenderer.getWidth("ACTIVE");
                int badgeW = actTextW + 16;
                int badgeH = 20;
                int badgeX = nameX + nameW + 18; // Generous 18px gap - NEVER touches profile name!
                int badgeY = cy + (cardH - badgeH) / 2;
                CatleanTheme.drawRoundedRect(context, badgeX, badgeY, badgeW, badgeH, 4.0, new Color(16, 185, 129, 60));
                CatleanTheme.drawRoundedOutline(context, badgeX, badgeY, badgeW, badgeH, 4.0, 1.0, new Color(16, 185, 129));
                TextRenderer.drawString("ACTIVE", context, badgeX + (badgeW - actTextW) / 2, badgeY + 4, new Color(16, 185, 129).getRGB());
            }

            // Action Buttons: Sized dynamically to guarantee NO overlap
            int rightEdge = px + pw - 26 - 14;
            int btnH = 28;
            int btnY = cy + (cardH - btnH) / 2;
            boolean isDefault = cfg.equalsIgnoreCase("default");

            int loadW = TextRenderer.getWidth("Load") + 24;
            int overW = TextRenderer.getWidth("Overwrite") + 24;
            int delW = TextRenderer.getWidth("Delete") + 24;
            int btnGap = 10;

            if (!isDefault) {
                // Delete button
                int delX = rightEdge - delW;
                boolean delHov = mouseX >= delX && mouseX <= delX + delW && mouseY >= btnY && mouseY <= btnY + btnH;
                CatleanTheme.drawRoundedRect(context, delX, btnY, delW, btnH, 4.0, delHov ? new Color(244, 63, 94, 80) : new Color(244, 63, 94, 35));
                CatleanTheme.drawRoundedOutline(context, delX, btnY, delW, btnH, 4.0, 1.0, new Color(244, 63, 94, 160));
                int dw = TextRenderer.getWidth("Delete");
                TextRenderer.drawString("Delete", context, delX + (delW - dw) / 2, btnY + 7, new Color(244, 63, 94).getRGB());

                // Overwrite button
                int overX = delX - btnGap - overW;
                boolean overHov = mouseX >= overX && mouseX <= overX + overW && mouseY >= btnY && mouseY <= btnY + btnH;
                CatleanTheme.drawRoundedRect(context, overX, btnY, overW, btnH, 4.0, overHov ? new Color(25, 34, 48, 250) : new Color(18, 24, 34, 220));
                CatleanTheme.drawRoundedOutline(context, overX, btnY, overW, btnH, 4.0, 1.0, overHov ? accent : CatleanTheme.BG_CARD_BORDER);
                int ow = TextRenderer.getWidth("Overwrite");
                TextRenderer.drawString("Overwrite", context, overX + (overW - ow) / 2, btnY + 7, overHov ? CatleanTheme.TEXT_PRIMARY.getRGB() : CatleanTheme.TEXT_SECONDARY.getRGB());

                // Load button
                int loadX = overX - btnGap - loadW;
                boolean loadHov = mouseX >= loadX && mouseX <= loadX + loadW && mouseY >= btnY && mouseY <= btnY + btnH;
                CatleanTheme.drawRoundedRect(context, loadX, btnY, loadW, btnH, 4.0, loadHov ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90) : new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 45));
                CatleanTheme.drawRoundedOutline(context, loadX, btnY, loadW, btnH, 4.0, 1.0, accent);
                int lw = TextRenderer.getWidth("Load");
                TextRenderer.drawString("Load", context, loadX + (loadW - lw) / 2, btnY + 7, accent.getRGB());
            } else {
                // Overwrite button
                int overX = rightEdge - overW;
                boolean overHov = mouseX >= overX && mouseX <= overX + overW && mouseY >= btnY && mouseY <= btnY + btnH;
                CatleanTheme.drawRoundedRect(context, overX, btnY, overW, btnH, 4.0, overHov ? new Color(25, 34, 48, 250) : new Color(18, 24, 34, 220));
                CatleanTheme.drawRoundedOutline(context, overX, btnY, overW, btnH, 4.0, 1.0, overHov ? accent : CatleanTheme.BG_CARD_BORDER);
                int ow = TextRenderer.getWidth("Overwrite");
                TextRenderer.drawString("Overwrite", context, overX + (overW - ow) / 2, btnY + 7, overHov ? CatleanTheme.TEXT_PRIMARY.getRGB() : CatleanTheme.TEXT_SECONDARY.getRGB());

                // Load button
                int loadX = overX - btnGap - loadW;
                boolean loadHov = mouseX >= loadX && mouseX <= loadX + loadW && mouseY >= btnY && mouseY <= btnY + btnH;
                CatleanTheme.drawRoundedRect(context, loadX, btnY, loadW, btnH, 4.0, loadHov ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90) : new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 45));
                CatleanTheme.drawRoundedOutline(context, loadX, btnY, loadW, btnH, 4.0, 1.0, accent);
                int lw = TextRenderer.getWidth("Load");
                TextRenderer.drawString("Load", context, loadX + (loadW - lw) / 2, btnY + 7, accent.getRGB());
            }
        }

        // Bottom Action Toolbar (Divider + 3 Buttons)
        int sepBottom = py + ph - 54;
        context.method_25294(px + 20, sepBottom, px + pw - 20, sepBottom + 1, CatleanTheme.BG_CARD_BORDER.getRGB());
        int toolbarY = sepBottom + 12;
        int toolbarBtnW = (pw - 52 - 20) / 3;
        int toolbarBtnH = 30;

        this.renderActionButton(context, px + 26, toolbarY, toolbarBtnW, toolbarBtnH, "⟳ Align Windows", mouseX, mouseY);
        this.renderActionButton(context, px + 26 + toolbarBtnW + 10, toolbarY, toolbarBtnW, toolbarBtnH, "↺ Reset Default", mouseX, mouseY);
        this.renderActionButton(context, px + 26 + (toolbarBtnW + 10) * 2, toolbarY, toolbarBtnW, toolbarBtnH, "📂 Open Folder", mouseX, mouseY);
    }

    private void renderControlsHint(class_332 context, int screenW, int screenH, int mouseX, int mouseY) {
        int lmbBadgeW = TextRenderer.getWidth("LMB") + 10;
        int toggleW = TextRenderer.getWidth("Toggle");
        int rmbBadgeW = TextRenderer.getWidth("RMB") + 10;
        int settingsW = TextRenderer.getWidth("Settings");
        int mmbBadgeW = TextRenderer.getWidth("MMB") + 10;
        int resetW = TextRenderer.getWidth("Reset");
        int dotW = 16;

        int totalContentW = lmbBadgeW + 6 + toggleW + dotW + rmbBadgeW + 6 + settingsW + dotW + mmbBadgeW + 6 + resetW;
        int hintW = totalContentW + 28;
        int hintH = 28;
        int hintX = screenW - hintW - 24;
        int hintY = screenH - hintH - 14;

        CatleanTheme.drawRoundedRect(context, hintX, hintY, hintW, hintH, 14.0, new Color(13, 17, 26, 235));
        CatleanTheme.drawRoundedOutline(context, hintX, hintY, hintW, hintH, 14.0, 1.0, new Color(255, 255, 255, 25));

        int curX = hintX + 14;
        int itemY = hintY + (hintH - 16) / 2;

        curX = this.drawHintItem(context, curX, itemY, "LMB", "Toggle");
        curX = this.drawHintDot(context, curX, itemY);
        curX = this.drawHintItem(context, curX, itemY, "RMB", "Settings");
        curX = this.drawHintDot(context, curX, itemY);
        this.drawHintItem(context, curX, itemY, "MMB", "Reset");
    }

    private int drawHintItem(class_332 context, int x, int y, String badge, String text) {
        int bw = TextRenderer.getWidth(badge) + 10;
        int bh = 16;
        CatleanTheme.drawRoundedRect(context, x, y, bw, bh, 4.0, new Color(26, 34, 48, 240));
        CatleanTheme.drawRoundedOutline(context, x, y, bw, bh, 4.0, 1.0, new Color(255, 255, 255, 30));
        int btw = TextRenderer.getWidth(badge);
        TextRenderer.drawString(badge, context, x + (bw - btw) / 2, y + 4, CatleanTheme.ACCENT_CYAN.getRGB());

        int tx = x + bw + 6;
        TextRenderer.drawString(text, context, tx, y + 4, CatleanTheme.TEXT_SECONDARY.getRGB());
        return tx + TextRenderer.getWidth(text);
    }

    private int drawHintDot(class_332 context, int x, int y) {
        TextRenderer.drawString("•", context, x + 6, y + 4, CatleanTheme.TEXT_MUTED.getRGB());
        return x + 16;
    }

    private void renderToggleRow(class_332 context, int x, int y, int w, String label, boolean val, int mouseX, int mouseY) {
        TextRenderer.drawString(label, context, x, y + 4, CatleanTheme.TEXT_PRIMARY.getRGB());

        int switchW = 36;
        int switchH = 18;
        int switchX = x + w - switchW;
        int switchY = y + 1;
        Color accent = CatleanTheme.getAccentColor(255);
        Color offColor = new Color(38, 48, 68);
        Color onColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 180);

        CatleanTheme.drawToggleSwitch(context, switchX, switchY, switchW, switchH, val ? 1.0f : 0.0f, offColor, onColor);
    }

    private void renderActionButton(class_332 context, int x, int y, int w, int h, String text, int mouseX, int mouseY) {
        boolean hov = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        Color bg = hov ? new Color(32, 42, 60, 240) : new Color(20, 26, 38, 220);
        CatleanTheme.drawRoundedRect(context, x, y, w, h, 6.0, bg);
        Color border = hov ? CatleanTheme.getAccentColor(180) : CatleanTheme.BG_CARD_BORDER;
        CatleanTheme.drawRoundedOutline(context, x, y, w, h, 6.0, 1.0, border);

        int tw = TextRenderer.getWidth(text);
        Color tc = hov ? CatleanTheme.TEXT_PRIMARY : CatleanTheme.TEXT_SECONDARY;
        TextRenderer.drawString(text, context, x + (w - tw) / 2, y + (h - 8) / 2 - 2, tc.getRGB());
    }

    public boolean method_25404(class_11908 input) {
        int keyCode = input.comp_4795();
        int scanCode = input.comp_4796();
        int modifiers = input.comp_4797();

        if (this.searchFocused) {
            if (keyCode == 256) { // ESC
                this.searchFocused = false;
                this.searchQuery = "";
                return true;
            }
            if (keyCode == 259) { // Backspace
                if (!this.searchQuery.isEmpty()) {
                    this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
                }
                return true;
            }
            if (keyCode == 257) { // Enter
                this.searchFocused = false;
                return true;
            }
        }

        if (this.configInputFocused) {
            if (keyCode == 256) { // ESC
                this.configInputFocused = false;
                return true;
            }
            if (keyCode == 259) { // Backspace
                if (!this.newConfigName.isEmpty()) {
                    this.newConfigName = this.newConfigName.substring(0, this.newConfigName.length() - 1);
                }
                return true;
            }
            if (keyCode == 257) { // Enter saves config
                this.configInputFocused = false;
                if (!this.newConfigName.trim().isEmpty()) {
                    ConfigManager.saveConfig(this.newConfigName.trim());
                    this.configStatusMessage = "Profile '" + this.newConfigName.trim() + "' saved!";
                    this.configStatusTime = System.currentTimeMillis();
                    this.newConfigName = "";
                }
                return true;
            }
        }

        if (keyCode == 256 && this.activeTab != 0) {
            this.activeTab = 0;
            return true;
        }

        for (Window window : this.windows) {
            window.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.method_25404(input);
    }

    public boolean method_25400(class_11905 input) {
        if (this.searchFocused && input.method_74227()) {
            this.searchQuery += input.method_74226();
            return true;
        }
        if (this.configInputFocused && input.method_74227()) {
            String s = input.method_74226();
            for (char c : s.toCharArray()) {
                if (Character.isLetterOrDigit(c) || c == '_' || c == '-') {
                    if (this.newConfigName.length() < 24) {
                        this.newConfigName += c;
                    }
                }
            }
            return true;
        }
        return super.method_25400(input);
    }

    public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798() * (double)class_310.method_1551().method_22683().method_4495();
        double mouseY = click.comp_4799() * (double)class_310.method_1551().method_22683().method_4495();
        int button = click.method_74245();
        int screenW = Argon.mc.method_22683().method_4480();
        int screenH = Argon.mc.method_22683().method_4507();

        // 1. Check top nav bar click
        int navX = (screenW - this.navW) / 2;
        int navY = 12;

        if (mouseX >= (double)navX && mouseX <= (double)(navX + this.navW) && mouseY >= (double)navY && mouseY <= (double)(navY + this.navH) && button == 0) {
            int tabW = (this.navW - 8) / this.navTabs.length;
            int clickedTab = (int)((mouseX - (double)(navX + 4)) / (double)tabW);
            if (clickedTab >= 0 && clickedTab < this.navTabs.length) {
                this.activeTab = clickedTab;
                this.searchFocused = false;
                this.configInputFocused = false;
            }
            return true;
        }

        // 2. Active Tab Interactions
        if (this.activeTab == 1) {
            // Themes interactions
            if (this.handleThemesClick(mouseX, mouseY, button, screenW, screenH)) {
                return true;
            }
        } else if (this.activeTab == 2) {
            // Config interactions
            if (this.handleConfigClick(mouseX, mouseY, button, screenW, screenH)) {
                return true;
            }
        } else if (this.activeTab == 0) {
            // Check if user clicked on any window or expanded module setting first (foreground priority)
            boolean clickedOnWindow = false;
            for (Window window : this.windows) {
                if (window.isMouseOverWindow(mouseX, mouseY)) {
                    clickedOnWindow = true;
                    break;
                }
            }

            if (clickedOnWindow) {
                this.searchFocused = false;
                for (Window window : this.windows) {
                    window.mouseClicked(mouseX, mouseY, button);
                }
                return true;
            }

            // Search bar interaction (only if not clicking on an overlapping window)
            if (mouseX >= (double)this.searchX && mouseX <= (double)(this.searchX + this.searchW)
                    && mouseY >= (double)this.searchY && mouseY <= (double)(this.searchY + this.searchH) && button == 0) {
                // Clear button click
                if (!this.searchQuery.isEmpty() && mouseX >= (double)(this.searchX + this.searchW - 28)) {
                    this.searchQuery = "";
                } else if (mouseX <= (double)(this.searchX + 90)) {
                    // Dragging search bar
                    this.searchDragging = true;
                    this.searchDragX = (int)(mouseX - (double)this.searchX);
                    this.searchDragY = (int)(mouseY - (double)this.searchY);
                } else {
                    this.searchFocused = true;
                }
                return true;
            } else if (button == 0) {
                this.searchFocused = false;
            }

            // Window interactions fallback
            for (Window window : this.windows) {
                window.mouseClicked(mouseX, mouseY, button);
            }
        }

        return super.method_25402(click, doubled);
    }

    private boolean handleThemesClick(double mouseX, double mouseY, int button, int screenW, int screenH) {
        int pw = Math.min(860, screenW - 40);
        int ph = Math.min(600, screenH - 50);
        int px = (screenW - pw) / 2;
        int py = Math.max(38, (screenH - ph) / 2);

        if (mouseX < px || mouseX > px + pw || mouseY < py || mouseY > py + ph) {
            return false;
        }

        // Check Presets (8 Cards)
        int sepY = py + 56;
        int presetsLabelY = sepY + 22;
        int btnW = (pw - 52 - 3 * 12) / 4;
        int btnH = 32;
        int startBtnX = px + 26;
        int startBtnY = presetsLabelY + 18;

        for (int i = 0; i < CatleanTheme.PRESETS.length; ++i) {
            int bx = startBtnX + (i % 4) * (btnW + 12);
            int by = startBtnY + (i / 4) * (btnH + 8);
            if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= by && mouseY <= by + btnH && button == 0) {
                CatleanTheme.applyPreset(i);
                return true;
            }
        }

        // Check RGB Sliders (Red, Green, Blue, Alpha)
        int sepY2 = startBtnY + 2 * (btnH + 8) + 8;
        int tunerLabelY = sepY2 + 16;
        int swatchX = px + 26;
        int swatchY = tunerLabelY + 18;
        int swatchW = 144;
        int sliderX = swatchX + swatchW + 24;
        int sliderW = pw - (sliderX - px) - 26;
        int startSliderY = swatchY;

        if (button == 0 && mouseX >= sliderX - 6 && mouseX <= sliderX + sliderW + 6) {
            for (int s = 0; s < 4; ++s) {
                int sy = startSliderY + s * 42;
                if (mouseY >= sy && mouseY <= sy + 36) {
                    this.draggingThemeSlider = s;
                    this.updateThemeSlider(mouseX, sliderX, sliderW, s);
                    return true;
                }
            }
        }

        // Check Effects Toggles
        int sepY3 = swatchY + 168 + 16;
        int effLabelY = sepY3 + 14;

        if (button == 0) {
            // Rainbow
            if (mouseY >= effLabelY + 20 && mouseY <= effLabelY + 20 + 26) {
                ClickGUI.rainbow.toggle();
                return true;
            }
            // Breathing
            if (mouseY >= effLabelY + 54 && mouseY <= effLabelY + 54 + 26) {
                ClickGUI.breathing.toggle();
                return true;
            }
            // Background Dim
            if (mouseY >= effLabelY + 88 && mouseY <= effLabelY + 88 + 26) {
                ClickGUI.background.toggle();
                return true;
            }
        }
        return true;
    }

    private void updateThemeSlider(double mouseX, int x, int w, int sliderIdx) {
        float pct = Math.max(0.0f, Math.min(1.0f, (float)(mouseX - x) / (float)w));
        int val = (int)(pct * 255.0f);
        if (sliderIdx == 0) {
            ClickGUI.red.setValue(val);
            ClickGUI.rainbow.setValue(false);
        } else if (sliderIdx == 1) {
            ClickGUI.green.setValue(val);
            ClickGUI.rainbow.setValue(false);
        } else if (sliderIdx == 2) {
            ClickGUI.blue.setValue(val);
            ClickGUI.rainbow.setValue(false);
        } else if (sliderIdx == 3) {
            ClickGUI.alphaWindow.setValue(Math.max(50, val));
        }
    }

    private boolean handleConfigClick(double mouseX, double mouseY, int button, int screenW, int screenH) {
        int pw = Math.min(860, screenW - 40);
        int ph = Math.min(600, screenH - 50);
        int px = (screenW - pw) / 2;
        int py = Math.max(38, (screenH - ph) / 2);

        if (mouseX < px || mouseX > px + pw || mouseY < py || mouseY > py + ph) {
            return false;
        }

        // Input Box click
        int sepY = py + 56;
        int inputX = px + 26;
        int inputY = sepY + 22;
        int inputW = pw - 52 - 160;
        int inputH = 34;

        if (mouseX >= inputX && mouseX <= inputX + inputW && mouseY >= inputY && mouseY <= inputY + inputH && button == 0) {
            this.configInputFocused = true;
            return true;
        } else if (button == 0) {
            this.configInputFocused = false;
        }

        // Save Profile Button click
        int saveBtnX = inputX + inputW + 12;
        int saveBtnY = inputY;
        int saveBtnW = 148;
        int saveBtnH = inputH;
        if (mouseX >= saveBtnX && mouseX <= saveBtnX + saveBtnW && mouseY >= saveBtnY && mouseY <= saveBtnY + saveBtnH && button == 0) {
            if (!this.newConfigName.trim().isEmpty()) {
                ConfigManager.saveConfig(this.newConfigName.trim());
                this.configStatusMessage = "Profile '" + this.newConfigName.trim() + "' saved!";
                this.configStatusTime = System.currentTimeMillis();
                this.newConfigName = "";
            } else {
                this.configStatusMessage = "Please enter a profile name first!";
                this.configStatusTime = System.currentTimeMillis();
            }
            return true;
        }

        // Config Rows Actions
        List<String> configs = ConfigManager.listConfigs();
        int listY = inputY + inputH + 20;
        int cardY = listY + 20;
        int cardH = 46;
        int gap = 8;
        int maxVisible = 6;

        for (int i = 0; i < Math.min(maxVisible, configs.size()); ++i) {
            String cfg = configs.get(i);
            int cy = cardY + i * (cardH + gap);
            int btnH = 28;
            int btnY = cy + (cardH - btnH) / 2;
            int rightEdge = px + pw - 26 - 12;
            boolean isDefault = cfg.equalsIgnoreCase("default");

            int loadW = TextRenderer.getWidth("Load") + 22;
            int overW = TextRenderer.getWidth("Overwrite") + 22;
            int delW = TextRenderer.getWidth("Delete") + 22;
            int btnGap = 10;

            if (!isDefault) {
                int delX = rightEdge - delW;
                int overX = delX - btnGap - overW;
                int loadX = overX - btnGap - loadW;

                // Delete click
                if (mouseX >= delX && mouseX <= delX + delW && mouseY >= btnY && mouseY <= btnY + btnH && button == 0) {
                    ConfigManager.deleteConfig(cfg);
                    this.configStatusMessage = "Deleted '" + cfg + "'";
                    this.configStatusTime = System.currentTimeMillis();
                    return true;
                }

                // Overwrite click
                if (mouseX >= overX && mouseX <= overX + overW && mouseY >= btnY && mouseY <= btnY + btnH && button == 0) {
                    ConfigManager.saveConfig(cfg);
                    this.configStatusMessage = "Updated '" + cfg + "'";
                    this.configStatusTime = System.currentTimeMillis();
                    return true;
                }

                // Load click
                if (mouseX >= loadX && mouseX <= loadX + loadW && mouseY >= btnY && mouseY <= btnY + btnH && button == 0) {
                    ConfigManager.loadConfig(cfg);
                    this.configStatusMessage = "Activated '" + cfg + "'";
                    this.configStatusTime = System.currentTimeMillis();
                    return true;
                }
            } else {
                int overX = rightEdge - overW;
                int loadX = overX - btnGap - loadW;

                // Overwrite click
                if (mouseX >= overX && mouseX <= overX + overW && mouseY >= btnY && mouseY <= btnY + btnH && button == 0) {
                    ConfigManager.saveConfig(cfg);
                    this.configStatusMessage = "Updated '" + cfg + "'";
                    this.configStatusTime = System.currentTimeMillis();
                    return true;
                }

                // Load click
                if (mouseX >= loadX && mouseX <= loadX + loadW && mouseY >= btnY && mouseY <= btnY + btnH && button == 0) {
                    ConfigManager.loadConfig(cfg);
                    this.configStatusMessage = "Activated '" + cfg + "'";
                    this.configStatusTime = System.currentTimeMillis();
                    return true;
                }
            }
        }

        // Bottom Toolbar Actions
        int sepBottom = py + ph - 54;
        int toolbarY = sepBottom + 12;
        int toolbarBtnW = (pw - 52 - 20) / 3;
        int toolbarBtnH = 30;

        // Align Windows
        if (mouseX >= px + 26 && mouseX <= px + 26 + toolbarBtnW && mouseY >= toolbarY && mouseY <= toolbarY + toolbarBtnH && button == 0) {
            this.layoutWindows();
            this.configStatusMessage = "Windows aligned!";
            this.configStatusTime = System.currentTimeMillis();
            return true;
        }

        // Reset Default
        int resetX = px + 26 + toolbarBtnW + 10;
        if (mouseX >= resetX && mouseX <= resetX + toolbarBtnW && mouseY >= toolbarY && mouseY <= toolbarY + toolbarBtnH && button == 0) {
            ConfigManager.loadConfig("default");
            this.configStatusMessage = "Reset to default config!";
            this.configStatusTime = System.currentTimeMillis();
            return true;
        }

        // Open Folder
        int openX = px + 26 + (toolbarBtnW + 10) * 2;
        if (mouseX >= openX && mouseX <= openX + toolbarBtnW && mouseY >= toolbarY && mouseY <= toolbarY + toolbarBtnH && button == 0) {
            ConfigManager.openConfigsFolder();
            return true;
        }

        return true;
    }

    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        double mouseX = click.comp_4798() * (double)class_310.method_1551().method_22683().method_4495();
        double mouseY = click.comp_4799() * (double)class_310.method_1551().method_22683().method_4495();
        int button = click.method_74245();
        int screenW = Argon.mc.method_22683().method_4480();
        int screenH = Argon.mc.method_22683().method_4507();

        if (this.activeTab == 1 && this.draggingThemeSlider != -1 && button == 0) {
            int pw = 640;
            int px = (screenW - pw) / 2;
            int sliderX = px + 128;
            int sliderW = pw - 150;
            this.updateThemeSlider(mouseX, sliderX, sliderW, this.draggingThemeSlider);
            return true;
        }

        if (this.activeTab == 0) {
            // Dragging search bar
            if (this.searchDragging && button == 0) {
                this.searchX = (int)(mouseX - (double)this.searchDragX);
                this.searchY = (int)(mouseY - (double)this.searchDragY);
                this.searchX = Math.max(10, Math.min(screenW - this.searchW - 10, this.searchX));
                this.searchY = Math.max(10, Math.min(screenH - this.searchH - 10, this.searchY));
                return true;
            }

            for (Window window : this.windows) {
                window.mouseDragged(mouseX, mouseY, button, offsetX, offsetY);
            }
        }

        return super.method_25403(click, offsetX, offsetY);
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        class_310 mc = class_310.method_1551();
        double scaledMouseX = mouseX * (double)mc.method_22683().method_4495();
        double scaledMouseY = mouseY * (double)mc.method_22683().method_4495();

        if (this.activeTab == 0) {
            for (Window window : this.windows) {
                window.mouseScrolled(scaledMouseX, scaledMouseY, horizontalAmount, verticalAmount);
            }
        }
        return super.method_25401(scaledMouseX, scaledMouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25419() {
        Argon.INSTANCE.getModuleManager().getModule(ClickGUI.class).toggle();
    }

    public void onGuiClose() {
        Argon.mc.method_1507(Argon.INSTANCE.previousScreen);
        this.currentColor = null;
        this.searchFocused = false;
        this.searchDragging = false;
        this.configInputFocused = false;
        this.draggingThemeSlider = -1;
        Argon.INSTANCE.previousScreen = null;
        for (Window window : this.windows) {
            window.onGuiClose();
        }
    }

    public boolean method_25406(class_11909 click) {
        double mouseX = click.comp_4798() * (double)class_310.method_1551().method_22683().method_4495();
        double mouseY = click.comp_4799() * (double)class_310.method_1551().method_22683().method_4495();
        int button = click.method_74245();
        if (button == 0) {
            this.searchDragging = false;
            this.draggingThemeSlider = -1;
        }
        if (this.activeTab == 0) {
            for (Window window : this.windows) {
                window.mouseReleased(mouseX, mouseY, button);
            }
        }
        return super.method_25406(click);
    }
}
