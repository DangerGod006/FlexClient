package dev.lvstrng.argon.gui;

import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.Utils;
import java.awt.Color;
import net.minecraft.class_332;

public final class CatleanTheme {
    // CatLean signature colors
    public static final Color ACCENT_CYAN = new Color(56, 189, 248);
    public static final Color ACCENT_TEAL = new Color(34, 211, 238);
    public static final Color ACCENT_BLUE = new Color(96, 165, 250);

    // Backgrounds
    public static final Color BG_OVERLAY = new Color(8, 12, 18, 170);
    public static final Color BG_NAVBAR = new Color(16, 21, 30, 235);
    public static final Color BG_NAVBAR_BORDER = new Color(255, 255, 255, 28);
    public static final Color BG_NAVBAR_ACTIVE = new Color(56, 189, 248, 45);
    public static final Color BG_NAVBAR_ACTIVE_BORDER = new Color(56, 189, 248, 160);

    public static final Color BG_CARD = new Color(16, 21, 31, 235);
    public static final Color BG_CARD_HEADER = new Color(22, 28, 41, 245);
    public static final Color BG_CARD_BORDER = new Color(255, 255, 255, 22);
    public static final Color BG_CARD_SHADOW = new Color(0, 0, 0, 90);

    public static final Color BG_MODULE_IDLE = new Color(20, 26, 38, 180);
    public static final Color BG_MODULE_HOVER = new Color(32, 42, 60, 220);
    public static final Color BG_MODULE_ACTIVE_TINT = new Color(56, 189, 248, 20);

    public static final Color BG_SETTINGS = new Color(12, 16, 24, 245);
    public static final Color BG_SETTINGS_BORDER = new Color(255, 255, 255, 14);

    public static final Color BG_TRACK = new Color(30, 38, 54, 220);
    public static final Color BG_TOGGLE_OFF = new Color(38, 48, 68, 240);

    // Text colors
    public static final Color TEXT_PRIMARY = new Color(242, 246, 254);
    public static final Color TEXT_SECONDARY = new Color(160, 175, 198);
    public static final Color TEXT_MUTED = new Color(110, 125, 148);
    public static final Color TEXT_ACCENT = new Color(56, 189, 248);

    public static final class ThemePreset {
        public final String name;
        public final String tag;
        public final int r;
        public final int g;
        public final int b;

        public ThemePreset(String name, String tag, int r, int g, int b) {
            this.name = name;
            this.tag = tag;
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }

    public static final ThemePreset[] PRESETS = new ThemePreset[]{
        new ThemePreset("Cyan", "CatLean", 56, 189, 248),
        new ThemePreset("Purple", "Vibrant", 168, 85, 247),
        new ThemePreset("Teal", "Ocean", 20, 184, 166),
        new ThemePreset("Mint", "Fresh", 16, 185, 129),
        new ThemePreset("Ruby", "Crimson", 244, 63, 94),
        new ThemePreset("Orange", "Sunset", 249, 115, 22),
        new ThemePreset("Blue", "Cobalt", 59, 130, 246),
        new ThemePreset("White", "Monolith", 240, 240, 240)
    };

    public static void applyPreset(int index) {
        if (index >= 0 && index < PRESETS.length) {
            ThemePreset p = PRESETS[index];
            ClickGUI.red.setValue(p.r);
            ClickGUI.green.setValue(p.g);
            ClickGUI.blue.setValue(p.b);
            ClickGUI.rainbow.setValue(false);
        }
    }

    private static final int[][] CORNER_LOOKUP = new int[32][32];
    static {
        for (int r = 1; r < 32; ++r) {
            for (int dy = 0; dy < r; ++dy) {
                CORNER_LOOKUP[r][dy] = (int)Math.round(Math.sqrt((double)Math.max(0, r * r - dy * dy)));
            }
        }
    }

    private static long lastAccentTime = 0;
    private static int lastAlpha = -1;
    private static Color cachedAccent = null;

    public static Color getAccentColor(int alpha) {
        int a = Math.min(255, Math.max(0, alpha));
        long now = System.currentTimeMillis();
        if (now == lastAccentTime && a == lastAlpha && cachedAccent != null) {
            return cachedAccent;
        }

        Color res;
        if (ClickGUI.rainbow.getValue()) {
            float hue = ((now % 4000L) / 4000.0f);
            Color hsb = Color.getHSBColor(hue, 0.75f, 1.0f);
            res = new Color(hsb.getRed(), hsb.getGreen(), hsb.getBlue(), a);
        } else if (ClickGUI.breathing.getValue()) {
            int r = ClickGUI.red.getValueInt();
            int g = ClickGUI.green.getValueInt();
            int b = ClickGUI.blue.getValueInt();
            float factor = (float)(0.65 + 0.35 * Math.sin(now / 350.0));
            res = new Color((int)(r * factor), (int)(g * factor), (int)(b * factor), a);
        } else {
            int r = ClickGUI.red.getValueInt();
            int g = ClickGUI.green.getValueInt();
            int b = ClickGUI.blue.getValueInt();
            if (r == 255 && g == 0 && b == 50) {
                res = new Color(ACCENT_CYAN.getRed(), ACCENT_CYAN.getGreen(), ACCENT_CYAN.getBlue(), a);
            } else {
                res = new Color(r, g, b, a);
            }
        }
        lastAccentTime = now;
        lastAlpha = a;
        cachedAccent = res;
        return res;
    }

    public static Color getAccentColor(int alpha, int increment) {
        return getAccentColor(alpha);
    }

    public static Color blendColors(Color from, Color to, float factor) {
        if (factor <= 0.002f) return from;
        if (factor >= 0.998f) return to;
        float f = Math.max(0.0f, Math.min(1.0f, factor));
        int r = (int)((float)from.getRed() + (float)(to.getRed() - from.getRed()) * f);
        int g = (int)((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * f);
        int b = (int)((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * f);
        int a = (int)((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * f);
        return new Color(r, g, b, a);
    }

    // High performance direct fill methods (0 lag, buttery smooth 144+ FPS)
    public static void drawRect(class_332 context, int x, int y, int width, int height, int color) {
        context.method_25294(x, y, x + width, y + height, color);
    }

    public static void drawRoundedRect(class_332 context, int x, int y, int width, int height, double radius, Color color) {
        if (color == null || color.getAlpha() == 0 || width <= 0 || height <= 0) return;
        int r = (int)Math.min(radius, Math.min((double)width / 2.0, (double)height / 2.0));
        int c = color.getRGB();
        if (r <= 1) {
            context.method_25294(x, y, x + width, y + height, c);
            return;
        }
        // Middle body
        context.method_25294(x + r, y, x + width - r, y + height, c);
        // Left strip
        context.method_25294(x, y + r, x + r, y + height - r, c);
        // Right strip
        context.method_25294(x + width - r, y + r, x + width, y + height - r, c);
        // 4 corner blocks
        drawCorner(context, x, y, r, c, 0);
        drawCorner(context, x + width - r, y, r, c, 1);
        drawCorner(context, x, y + height - r, r, c, 2);
        drawCorner(context, x + width - r, y + height - r, r, c, 3);
    }

    public static void drawRoundedRect(class_332 context, int x, int y, int width, int height, double rTL, double rTR, double rBL, double rBR, Color color) {
        if (color == null || color.getAlpha() == 0 || width <= 0 || height <= 0) return;
        int tl = (int)rTL;
        int tr = (int)rTR;
        int bl = (int)rBL;
        int br = (int)rBR;
        int maxR = Math.max(Math.max(tl, tr), Math.max(bl, br));
        int c = color.getRGB();
        if (maxR <= 1) {
            context.method_25294(x, y, x + width, y + height, c);
            return;
        }
        int topR = Math.max(tl, tr);
        int botR = Math.max(bl, br);
        context.method_25294(x + Math.max(tl, bl), y, x + width - Math.max(tr, br), y + height, c);
        if (tl > 0 || bl > 0) context.method_25294(x, y + tl, x + Math.max(tl, bl), y + height - bl, c);
        if (tr > 0 || br > 0) context.method_25294(x + width - Math.max(tr, br), y + tr, x + width, y + height - br, c);

        if (tl > 0) drawCorner(context, x, y, tl, c, 0);
        if (tr > 0) drawCorner(context, x + width - tr, y, tr, c, 1);
        if (bl > 0) drawCorner(context, x, y + height - bl, bl, c, 2);
        if (br > 0) drawCorner(context, x + width - br, y + height - br, br, c, 3);
    }

    private static void drawCorner(class_332 context, int cx, int cy, int r, int color, int corner) {
        if (r <= 0) return;
        boolean fast = r < 32;
        for (int iy = 0; iy < r; ++iy) {
            int dy = r - 1 - iy;
            int w = (fast && dy < 32) ? CORNER_LOOKUP[r][dy] : (int)Math.round(Math.sqrt((double)Math.max(0, r * r - dy * dy)));
            if (w <= 0) continue;
            if (corner == 0) { // Top-Left
                context.method_25294(cx + r - w, cy + iy, cx + r, cy + iy + 1, color);
            } else if (corner == 1) { // Top-Right
                context.method_25294(cx, cy + iy, cx + w, cy + iy + 1, color);
            } else if (corner == 2) { // Bottom-Left
                context.method_25294(cx + r - w, cy + r - 1 - iy, cx + r, cy + r - iy, color);
            } else { // Bottom-Right
                context.method_25294(cx, cy + r - 1 - iy, cx + w, cy + r - iy, color);
            }
        }
    }

    public static void drawRoundedOutline(class_332 context, int x, int y, int width, int height, double radius, double thickness, Color color) {
        if (color == null || color.getAlpha() == 0 || width <= 0 || height <= 0) return;
        int t = Math.max(1, (int)thickness);
        int r = (int)Math.min(radius, Math.min((double)width / 2.0, (double)height / 2.0));
        int c = color.getRGB();

        // 4 straight edges (ultra fast)
        context.method_25294(x + r, y, x + width - r, y + t, c);
        context.method_25294(x + r, y + height - t, x + width - r, y + height, c);
        context.method_25294(x, y + r, x + t, y + height - r, c);
        context.method_25294(x + width - t, y + r, x + width, y + height - r, c);

        // 4 corner arcs
        drawCornerOutline(context, x, y, r, t, c, 0);
        drawCornerOutline(context, x + width - r, y, r, t, c, 1);
        drawCornerOutline(context, x, y + height - r, r, t, c, 2);
        drawCornerOutline(context, x + width - r, y + height - r, r, t, c, 3);
    }

    private static void drawCornerOutline(class_332 context, int cx, int cy, int r, int t, int color, int corner) {
        if (r <= 0) return;
        int innerR = Math.max(0, r - t);
        boolean fast = r < 32;
        boolean fastInner = innerR < 32;
        for (int iy = 0; iy < r; ++iy) {
            int dy = r - 1 - iy;
            int outerW = (fast && dy < 32) ? CORNER_LOOKUP[r][dy] : (int)Math.round(Math.sqrt((double)Math.max(0, r * r - dy * dy)));
            int innerW = 0;
            if (dy < innerR) {
                innerW = (fastInner && dy < 32) ? CORNER_LOOKUP[innerR][dy] : (int)Math.round(Math.sqrt((double)Math.max(0, innerR * innerR - dy * dy)));
            }
            if (outerW <= innerW) continue;
            if (corner == 0) { // Top-Left
                context.method_25294(cx + r - outerW, cy + iy, cx + r - innerW, cy + iy + 1, color);
            } else if (corner == 1) { // Top-Right
                context.method_25294(cx + innerW, cy + iy, cx + outerW, cy + iy + 1, color);
            } else if (corner == 2) { // Bottom-Left
                context.method_25294(cx + r - outerW, cy + r - 1 - iy, cx + r - innerW, cy + r - iy, color);
            } else { // Bottom-Right
                context.method_25294(cx + innerW, cy + r - 1 - iy, cx + outerW, cy + r - iy, color);
            }
        }
    }

    public static void drawModernCard(class_332 context, int x, int y, int width, int height, double radius, Color bg, Color border) {
        drawRoundedRect(context, x, y, width, height, radius, bg);
        if (border != null && border.getAlpha() > 0) {
            drawRoundedOutline(context, x, y, width, height, radius, 1.0, border);
        }
    }

    public static void drawToggleSwitch(class_332 context, int x, int y, int width, int height, float progress, Color offColor, Color onColor) {
        double radius = (double)height / 2.0;
        float p = Math.max(0.0f, Math.min(1.0f, progress));
        int r = (int)((float)offColor.getRed() + (float)(onColor.getRed() - offColor.getRed()) * p);
        int g = (int)((float)offColor.getGreen() + (float)(onColor.getGreen() - offColor.getGreen()) * p);
        int b = (int)((float)offColor.getBlue() + (float)(onColor.getBlue() - offColor.getBlue()) * p);
        int a = (int)((float)offColor.getAlpha() + (float)(onColor.getAlpha() - offColor.getAlpha()) * p);
        Color trackColor = new Color(r, g, b, a);
        drawRoundedRect(context, x, y, width, height, radius, trackColor);
        drawRoundedOutline(context, x, y, width, height, radius, 1.0, new Color(255, 255, 255, 25));

        int knobSize = height - 4;
        int knobX = x + 2 + (int)((float)(width - knobSize - 4) * p);
        int knobY = y + 2;
        drawRoundedRect(context, knobX, knobY, knobSize, knobSize, (double)knobSize / 2.0, new Color(255, 255, 255, 255));
    }
}
