package dev.lvstrng.argon.gui;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.ClickGui;
import dev.lvstrng.argon.gui.components.ModuleButton;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.MathUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;

public final class Window {
    public List<ModuleButton> moduleButtons = new ArrayList<ModuleButton>();
    public int x;
    public int y;
    private int width;
    private final int height;
    public Color currentColor;
    private final Category category;
    public boolean dragging;
    public boolean extended;
    private int dragX;
    private int dragY;
    private int prevX;
    private int prevY;
    public ClickGui parent;
    public static final int HEADER_HEIGHT = 34;

    public Window(int x, int y, int width, int height, Category category, ClickGui parent) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.dragging = false;
        this.extended = true;
        this.height = height; // 28
        this.category = category;
        this.parent = parent;
        this.prevX = x;
        this.prevY = y;
        int offset = HEADER_HEIGHT;
        for (Module module : new ArrayList<Module>(Argon.INSTANCE.getModuleManager().getModulesInCategory(category))) {
            this.moduleButtons.add(new ModuleButton(this, module, offset));
            offset += height;
        }
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int toAlpha = ClickGUI.alphaWindow.getValueInt();
        if (this.currentColor == null || this.currentColor.getAlpha() != toAlpha) {
            this.currentColor = new Color(0, 0, 0, toAlpha);
        }

        int winX = this.prevX;
        int winY = this.prevY;
        int winW = this.width;
        int headerH = HEADER_HEIGHT;

        // Calculate total content height for outer card border
        int totalH = headerH;
        if (this.extended && !this.moduleButtons.isEmpty()) {
            int lastOffset = headerH;
            for (ModuleButton mb : this.moduleButtons) {
                if (this.parent.isSearching()) {
                    String query = this.parent.getSearchQuery().toLowerCase().trim();
                    if (!mb.module.getName().toString().toLowerCase().contains(query)) continue;
                }
                lastOffset = mb.offset + (int)Math.max((double)this.height, mb.animation.getValue());
            }
            totalH = lastOffset;
        }

        // Draw modern CatLean window frosted glass background
        Color cardBg = new Color(CatleanTheme.BG_CARD.getRed(), CatleanTheme.BG_CARD.getGreen(), CatleanTheme.BG_CARD.getBlue(), Math.min(255, toAlpha));
        CatleanTheme.drawRoundedRect(context, winX, winY, winW, totalH, 10.0, cardBg);

        // Draw header background (rounded top corners)
        Color headerBg = new Color(CatleanTheme.BG_CARD_HEADER.getRed(), CatleanTheme.BG_CARD_HEADER.getGreen(), CatleanTheme.BG_CARD_HEADER.getBlue(), Math.min(255, toAlpha + 25));
        CatleanTheme.drawRoundedRect(context, winX, winY, winW, headerH, 10.0, 10.0, 0.0, 0.0, headerBg);

        // Header accent bottom divider line (CatLean cyan / theme accent)
        Color accent = CatleanTheme.getAccentColor(255);
        context.method_25294(winX, winY + headerH - 2, winX + winW, winY + headerH, accent.getRGB());

        // Header Category title (clean, centered, vibrant accent)
        String catName = this.category.name.toString();
        int titleW = TextRenderer.getWidth(catName);
        int titleX = winX + (winW - titleW) / 2;
        TextRenderer.drawString(catName, context, titleX, winY + (headerH - 8) / 2 - 2, accent.getRGB());

        // Draw card border
        CatleanTheme.drawRoundedOutline(context, winX, winY, winW, totalH, 10.0, 1.0, CatleanTheme.BG_CARD_BORDER);

        // Render module buttons
        this.updateButtons(delta);
        if (this.extended) {
            for (ModuleButton moduleButton : this.moduleButtons) {
                // If search filter is active, check match
                if (this.parent.isSearching()) {
                    String query = this.parent.getSearchQuery().toLowerCase().trim();
                    if (!moduleButton.module.getName().toString().toLowerCase().contains(query)) {
                        continue;
                    }
                }
                moduleButton.render(context, mouseX, mouseY, delta);
            }
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        for (ModuleButton moduleButton : this.moduleButtons) {
            moduleButton.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    public void onGuiClose() {
        this.currentColor = null;
        for (ModuleButton moduleButton : this.moduleButtons) {
            moduleButton.onGuiClose();
        }
        this.dragging = false;
    }

    public boolean isDraggingAlready() {
        for (Window window : this.parent.windows) {
            if (!window.dragging) continue;
            return true;
        }
        return false;
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY)) {
            switch (button) {
                case 0: {
                    if (this.parent.isDraggingAlready()) break;
                    this.dragging = true;
                    this.dragX = (int)(mouseX - (double)this.x);
                    this.dragY = (int)(mouseY - (double)this.y);
                    break;
                }
                case 1: {
                    if (!this.dragging) {
                        this.extended = !this.extended;
                    }
                    break;
                }
            }
        }
        if (this.extended) {
            for (ModuleButton moduleButton : this.moduleButtons) {
                if (this.parent.isSearching()) {
                    String query = this.parent.getSearchQuery().toLowerCase().trim();
                    if (!moduleButton.module.getName().toString().toLowerCase().contains(query)) {
                        continue;
                    }
                }
                moduleButton.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.extended) {
            for (ModuleButton moduleButton : this.moduleButtons) {
                moduleButton.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
            }
        }
    }

    public void updateButtons(float delta) {
        int offset = HEADER_HEIGHT;
        for (ModuleButton moduleButton : this.moduleButtons) {
            if (this.parent.isSearching()) {
                String query = this.parent.getSearchQuery().toLowerCase().trim();
                if (!moduleButton.module.getName().toString().toLowerCase().contains(query)) {
                    continue;
                }
            }
            double targetH = moduleButton.extended ? (double)(this.height + moduleButton.settings.size() * 36) : (double)this.height;
            moduleButton.animation.animate(0.4 * (double)delta, targetH);
            double supHeight = moduleButton.animation.getValue();
            moduleButton.offset = offset;
            offset += (int)supHeight;
        }
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && this.dragging) {
            this.dragging = false;
        }
        for (ModuleButton moduleButton : this.moduleButtons) {
            moduleButton.mouseReleased(mouseX, mouseY, button);
        }
    }

    public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.prevX = this.x;
        this.prevY = this.y;
        this.prevY = (int)((double)this.prevY + verticalAmount * 24.0);
        this.setY((int)((double)this.y + verticalAmount * 24.0));
    }

    public int getX() {
        return this.prevX;
    }

    public int getY() {
        return this.prevY;
    }

    public void setY(int y) {
        this.y = y;
        this.prevY = y;
    }

    public void setX(int x) {
        this.x = x;
        this.prevX = x;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX > (double)this.x && mouseX < (double)(this.x + this.width) && mouseY > (double)this.y && mouseY < (double)(this.y + HEADER_HEIGHT);
    }

    public boolean isPrevHovered(double mouseX, double mouseY) {
        return mouseX > (double)this.prevX && mouseX < (double)(this.prevX + this.width) && mouseY > (double)this.prevY && mouseY < (double)(this.prevY + HEADER_HEIGHT);
    }

    public void updatePosition(double mouseX, double mouseY, float delta) {
        this.prevX = this.x;
        this.prevY = this.y;
        if (this.dragging) {
            this.x = (int)MathUtils.goodLerp(0.35f * delta, this.isHovered(mouseX, mouseY) ? (double)this.x : (double)this.prevX, mouseX - (double)this.dragX);
            this.y = (int)MathUtils.goodLerp(0.35f * delta, this.isHovered(mouseX, mouseY) ? (double)this.y : (double)this.prevY, mouseY - (double)this.dragY);
        }
    }

    public boolean isMouseOverWindow(double mouseX, double mouseY) {
        int winX = Math.min(this.x, this.prevX);
        int winY = Math.min(this.y, this.prevY);
        int winW = this.width;
        int headerH = HEADER_HEIGHT;
        int totalH = headerH;
        if (this.extended && !this.moduleButtons.isEmpty()) {
            int lastOffset = headerH;
            for (ModuleButton mb : this.moduleButtons) {
                if (this.parent.isSearching()) {
                    String query = this.parent.getSearchQuery().toLowerCase().trim();
                    if (!mb.module.getName().toString().toLowerCase().contains(query)) continue;
                }
                lastOffset = mb.offset + (int)Math.max((double)this.height, mb.animation.getValue());
            }
            totalH = lastOffset;
        }
        int maxX = Math.max(this.x, this.prevX) + winW;
        int maxY = Math.max(this.y, this.prevY) + totalH;
        return mouseX >= (double)winX && mouseX <= (double)maxX && mouseY >= (double)winY && mouseY <= (double)maxY;
    }
}
