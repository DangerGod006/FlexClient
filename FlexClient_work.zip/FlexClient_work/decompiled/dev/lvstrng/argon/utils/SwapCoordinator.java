package dev.lvstrng.argon.utils;

import dev.lvstrng.argon.module.Module;

/**
 * Coordinates item swaps across combat modules (MaceSwap, SpearSwap, etc.)
 * to prevent race conditions, duplicate swaps, and inventory desyncs.
 */
public final class SwapCoordinator {
    private static Module activeModule = null;
    private static long lockTime = 0L;

    private SwapCoordinator() {}

    /**
     * Attempts to acquire the exclusive swap lock for the given module.
     * Auto-expires any stale lock older than 800ms to eliminate deadlocks.
     * @return true if the module acquired the lock or already owns it, false if another module is busy.
     */
    public static synchronized boolean requestLock(Module module) {
        if (module == null) return false;
        long now = System.currentTimeMillis();
        if (activeModule != null && (now - lockTime > 350L)) {
            activeModule = null;
        }
        if (activeModule == null || activeModule == module) {
            activeModule = module;
            lockTime = now;
            return true;
        }
        return false;
    }

    /**
     * Releases the exclusive swap lock if owned by the given module.
     */
    public static synchronized void releaseLock(Module module) {
        if (activeModule == module) {
            activeModule = null;
            lockTime = 0L;
        }
    }

    /**
     * Forcefully clears the lock (e.g. on disconnect or world change).
     */
    public static synchronized void forceRelease() {
        activeModule = null;
        lockTime = 0L;
    }

    /**
     * Checks if another module currently holds the swap lock.
     * Auto-expires stale locks older than 350ms.
     */
    public static synchronized boolean isLockedByOther(Module module) {
        if (activeModule == null || activeModule == module) return false;
        long now = System.currentTimeMillis();
        if (now - lockTime > 350L) {
            activeModule = null;
            lockTime = 0L;
            return false;
        }
        return true;
    }

    /**
     * Returns the currently active module, or null.
     */
    public static synchronized Module getActiveModule() {
        if (activeModule != null && (System.currentTimeMillis() - lockTime > 350L)) {
            activeModule = null;
            lockTime = 0L;
        }
        return activeModule;
    }
}
