/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package dev.lvstrng.argon.utils;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Log {
    private static final Logger LOGGER = LoggerFactory.getLogger((String)"FlexClient");
    private static final String PREFIX = "[FlexClient] ";
    private static final Set<String> REPORTED = Collections.newSetFromMap(new ConcurrentHashMap());

    private Log() {
    }

    public static void info(String message) {
        LOGGER.info(PREFIX + message);
    }

    public static void info(String message, Object ... args) {
        LOGGER.info(PREFIX + message, args);
    }

    public static void warn(String message) {
        LOGGER.warn(PREFIX + message);
    }

    public static void warn(String message, Object ... args) {
        LOGGER.warn(PREFIX + message, args);
    }

    public static void error(String message, Throwable throwable) {
        LOGGER.error(PREFIX + message, throwable);
    }

    public static void error(String message) {
        LOGGER.error(PREFIX + message);
    }

    public static void once(String key, String message, Throwable throwable) {
        if (REPORTED.add(key)) {
            Log.error(message, throwable);
        }
    }
}

