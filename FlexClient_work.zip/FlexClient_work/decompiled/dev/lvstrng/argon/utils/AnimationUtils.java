package dev.lvstrng.argon.utils;

import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.utils.MathUtils;

public final class AnimationUtils {
    private double value;
    private final double originalValue;
    private double endValue;

    public AnimationUtils(double value) {
        this.value = value;
        this.originalValue = value;
        this.endValue = value;
    }

    public double animate(double delta, double end) {
        this.endValue = end;
        if (ClickGUI.animationMode.isMode(ClickGUI.AnimationMode.Normal)) {
            this.value = MathUtils.goodLerp((float)delta, this.value, end);
        } else if (ClickGUI.animationMode.isMode(ClickGUI.AnimationMode.Positive)) {
            this.value = MathUtils.smoothStepLerp(delta, this.value, end);
        } else if (ClickGUI.animationMode.isMode(ClickGUI.AnimationMode.Off)) {
            this.value = end;
        }
        return this.value;
    }

    public double getValue() {
        return this.value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public double getOriginalValue() {
        return this.originalValue;
    }

    public double getEndValue() {
        return this.endValue;
    }

    public void setEndValue(double endValue) {
        this.endValue = endValue;
    }

    public double getAnimationProgress() {
        return this.endValue == 0.0 ? 1.0 : Math.max(0.0, Math.min(1.0, this.value / this.endValue));
    }

    public void reset(double delta) {
        this.value = MathUtils.smoothStepLerp(delta, this.value, this.originalValue);
    }

    public static double easeOutCubic(double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        return 1.0 - Math.pow(1.0 - t, 3.0);
    }

    public static double easeInOutQuad(double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        return t < 0.5 ? 2.0 * t * t : 1.0 - Math.pow(-2.0 * t + 2.0, 2.0) / 2.0;
    }

    public static double smoothLerp(double current, double target, double speed) {
        return current + (target - current) * Math.max(0.0, Math.min(1.0, speed));
    }
}
