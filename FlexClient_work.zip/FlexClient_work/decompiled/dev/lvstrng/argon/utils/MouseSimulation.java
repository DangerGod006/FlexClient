package dev.lvstrng.argon.utils;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.EventManager;
import dev.lvstrng.argon.event.events.ButtonListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class MouseSimulation {
    public static final ConcurrentHashMap<Integer, Boolean> mouseButtons = new ConcurrentHashMap<>();
    public static final ExecutorService clickExecutor = Executors.newFixedThreadPool(8);

    private static volatile boolean cancelAttack = false;
    private static volatile boolean cancelUse = false;

    // FastClient HUD CPS Counter reflection cache
    private static Object cpsModule = null;
    private static Field leftClicksField = null;
    private static Field rightClicksField = null;
    private static boolean reflectionAttempted = false;

    private static volatile long lastLeftClickTime = 0;
    private static volatile long lastRightClickTime = 0;

    public static boolean isMouseButtonPressed(int keyCode) {
        Boolean key = mouseButtons.get(keyCode);
        return key != null && key;
    }

    public static boolean shouldCancelVanillaAttack() {
        if (cancelAttack) {
            cancelAttack = false;
            return true;
        }
        return false;
    }

    public static boolean shouldCancelVanillaUse() {
        if (cancelUse) {
            cancelUse = false;
            return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private static void registerFastClientHudClick(int button) {
        long now = System.currentTimeMillis();
        // Debounce: prevent duplicate registration within 15ms
        if (button == 0) {
            if (now - lastLeftClickTime < 15) return;
            lastLeftClickTime = now;
        } else if (button == 1) {
            if (now - lastRightClickTime < 15) return;
            lastRightClickTime = now;
        }

        try {
            if (!reflectionAttempted || (cpsModule == null && Argon.mc != null && Argon.mc.field_1687 != null)) {
                reflectionAttempted = true;
                try {
                    Class<?> mmClass = Class.forName("net.fastclient.hud.core.ModuleManager");
                    Method getInstance = mmClass.getMethod("getInstance");
                    Object mm = getInstance.invoke(null);
                    if (mm != null) {
                        Method getModule = mmClass.getMethod("getModule", String.class);
                        cpsModule = getModule.invoke(mm, "CPSCounter");
                        if (cpsModule != null) {
                            Class<?> cpsClass = cpsModule.getClass();
                            leftClicksField = cpsClass.getDeclaredField("leftClicks");
                            leftClicksField.setAccessible(true);
                            rightClicksField = cpsClass.getDeclaredField("rightClicks");
                            rightClicksField.setAccessible(true);
                        }
                    }
                } catch (Throwable ignored) {}
            }

            if (cpsModule != null) {
                if (button == 0 && leftClicksField != null) {
                    Queue<Long> queue = (Queue<Long>) leftClicksField.get(cpsModule);
                    if (queue != null) queue.add(now);
                } else if (button == 1 && rightClicksField != null) {
                    Queue<Long> queue = (Queue<Long>) rightClicksField.get(cpsModule);
                    if (queue != null) queue.add(now);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void mousePress(int keyCode) {
        mouseButtons.put(keyCode, true);

        if (Argon.mc != null) {
            try {
                if (Argon.mc.field_1690 != null) {
                    class_3675.class_306 key = class_3675.class_307.field_1668.method_1447(keyCode);
                    class_304.method_1416(key, true);
                    class_304.method_1420(key);
                }
            } catch (Throwable ignored) {}

            if (Argon.mc.method_22683() != null) {
                EventManager.fire(new ButtonListener.ButtonEvent(keyCode, Argon.mc.method_22683().method_4490(), 1));
            }
        }
    }

    public static void mouseRelease(int keyCode) {
        mouseButtons.put(keyCode, false);

        if (Argon.mc != null) {
            try {
                if (Argon.mc.field_1690 != null) {
                    class_3675.class_306 key = class_3675.class_307.field_1668.method_1447(keyCode);
                    class_304.method_1416(key, false);
                }
            } catch (Throwable ignored) {}

            if (Argon.mc.method_22683() != null) {
                EventManager.fire(new ButtonListener.ButtonEvent(keyCode, Argon.mc.method_22683().method_4490(), 0));
            }
        }
    }

    public static void mouseClick(int keyCode, int millis) {
        // 1. Direct FastClient HUD CPS registration (guarantees exactly 1 click per event)
        registerFastClientHudClick(keyCode);

        // 2. Pulse mouse button state for Keystrokes HUD
        mousePress(keyCode);

        // 3. Release after short duration (~35ms)
        int holdTime = Math.max(25, Math.min(millis, 50));
        clickExecutor.submit(() -> {
            try {
                Thread.sleep(holdTime);
            } catch (InterruptedException ignored) {}
            mouseRelease(keyCode);
        });
    }

    public static void mouseClick(int keyCode) {
        MouseSimulation.mouseClick(keyCode, 35);
    }
}
