/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonPrimitive
 */
package dev.lvstrng.argon.managers;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.MinMaxSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.module.setting.StringSetting;
import dev.lvstrng.argon.utils.Log;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.List;

public final class ProfileManager {
    private static final String FOLDER_NAME = "UJHfsGGjbPfVZ";
    private static final String FILE_NAME = "a.json";
    private final Gson gson = new Gson();
    private final Path profilePath;

    public ProfileManager() {
        String home = System.getProperty("user.home", ".");
        this.profilePath = Paths.get(home, new String[0]).resolve(FOLDER_NAME).resolve(FILE_NAME);
    }

    public void loadProfile() {
        try {
            JsonObject profile;
            if (!Files.isRegularFile(this.profilePath, new LinkOption[0])) {
                Log.info("No profile found at %s - using defaults", this.profilePath);
                return;
            }
            String json = Files.readString(this.profilePath);
            try {
                profile = (JsonObject)this.gson.fromJson(json, JsonObject.class);
            }
            catch (JsonParseException e) {
                Log.error("Profile is corrupt, starting with default settings", e);
                this.quarantineCorruptProfile();
                return;
            }
            if (profile == null) {
                Log.warn("Profile is empty, starting with default settings");
                return;
            }
            List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
            for (Module module : modules) {
                if (!module.isEnabled()) continue;
                module.setEnabled(false);
            }
            int restored = 0;
            for (int index = 0; index < modules.size(); ++index) {
                Module module = modules.get(index);
                JsonElement moduleElement = profile.get(module.getName().toString());
                if (moduleElement == null) {
                    moduleElement = profile.get(String.valueOf(index));
                }
                if (moduleElement == null || !moduleElement.isJsonObject()) continue;
                JsonObject moduleConfig = moduleElement.getAsJsonObject();
                restored += this.applyModuleConfig(module, moduleConfig) ? 1 : 0;
            }
            Log.info("Loaded profile: %d/%d modules configured", restored, modules.size());
        }
        catch (IOException e) {
            Log.error("Failed to read profile", e);
        }
        catch (RuntimeException e) {
            Log.error("Unexpected failure while loading profile", e);
        }
    }

    public void saveProfile() {
        try {
            Path folder = this.profilePath.getParent();
            if (folder != null) {
                Files.createDirectories(folder, new FileAttribute[0]);
            }
            JsonObject profile = new JsonObject();
            List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
            for (Module module : modules) {
                profile.add(module.getName().toString(), (JsonElement)ProfileManager.serializeModule(module));
            }
            Path tmp = Paths.get(String.valueOf(this.profilePath) + ".tmp", new String[0]);
            Files.writeString(tmp, (CharSequence)this.gson.toJson((JsonElement)profile), new OpenOption[0]);
            try {
                Files.move(tmp, this.profilePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            }
            catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, this.profilePath, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (IOException e) {
            Log.error("Failed to save profile", e);
        }
        catch (RuntimeException e) {
            Log.error("Unexpected failure while saving profile", e);
        }
    }

    private boolean applyModuleConfig(Module module, JsonObject moduleConfig) {
        boolean configured = false;
        JsonElement enabledElement = moduleConfig.get("enabled");
        if (ProfileManager.isBoolean(enabledElement)) {
            boolean enabled = enabledElement.getAsBoolean();
            module.setEnabledStatus(enabled);
            if (enabled) {
                try {
                    module.onEnable();
                }
                catch (RuntimeException e) {
                    Log.error("Module '" + String.valueOf(module.getName()) + "' failed to enable", e);
                }
            }
            configured = true;
        }
        List<Setting<?>> settings = module.getSettings();
        for (int index = 0; index < settings.size(); ++index) {
            Setting<?> setting = settings.get(index);
            JsonElement element = moduleConfig.get(setting.getName().toString());
            if (element == null) {
                element = moduleConfig.get(String.valueOf(index));
            }
            if (element == null || !this.applySetting(module, setting, element)) continue;
            configured = true;
        }
        return configured;
    }

    private boolean applySetting(Module module, Setting<?> setting, JsonElement element) {
        try {
            if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                if (ProfileManager.isBoolean(element)) {
                    booleanSetting.setValue(element.getAsBoolean());
                    return true;
                }
            } else if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                if (ProfileManager.isNumber(element)) {
                    modeSetting.setModeIndex(element.getAsInt());
                    return true;
                }
            } else if (setting instanceof NumberSetting) {
                NumberSetting numberSetting = (NumberSetting)setting;
                if (ProfileManager.isNumber(element)) {
                    numberSetting.setValue(element.getAsDouble());
                    return true;
                }
            } else if (setting instanceof KeybindSetting) {
                KeybindSetting keybindSetting = (KeybindSetting)setting;
                if (ProfileManager.isNumber(element)) {
                    int key = element.getAsInt();
                    keybindSetting.setKey(key);
                    if (keybindSetting.isModuleKey()) {
                        module.setKey(key);
                    }
                    return true;
                }
            } else if (setting instanceof StringSetting) {
                StringSetting stringSetting = (StringSetting)setting;
                if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
                    stringSetting.setValue(element.getAsString());
                    return true;
                }
            } else if (setting instanceof MinMaxSetting) {
                MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                if (element.isJsonObject()) {
                    JsonObject minMax = element.getAsJsonObject();
                    JsonElement minElement = minMax.get("1");
                    JsonElement maxElement = minMax.get("2");
                    if (ProfileManager.isNumber(minElement) && ProfileManager.isNumber(maxElement)) {
                        minMaxSetting.setMinValue(minElement.getAsDouble());
                        minMaxSetting.setMaxValue(maxElement.getAsDouble());
                        return true;
                    }
                }
            }
            return false;
        }
        catch (RuntimeException e) {
            Log.warn("Ignoring invalid saved value for '%s' in module '%s'", setting.getName(), module.getName());
            return false;
        }
    }

    private static JsonObject serializeModule(Module module) {
        JsonObject moduleConfig = new JsonObject();
        moduleConfig.addProperty("enabled", Boolean.valueOf(module.isEnabled()));
        List<Setting<?>> settings = module.getSettings();
        for (Setting<?> setting : settings) {
            String key = setting.getName().toString();
            if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                moduleConfig.addProperty(key, Boolean.valueOf(booleanSetting.getValue()));
                continue;
            }
            if (setting instanceof ModeSetting) {
                ModeSetting modeSetting = (ModeSetting)setting;
                moduleConfig.addProperty(key, (Number)modeSetting.getModeIndex());
                continue;
            }
            if (setting instanceof NumberSetting) {
                NumberSetting numberSetting = (NumberSetting)setting;
                moduleConfig.addProperty(key, (Number)numberSetting.getValue());
                continue;
            }
            if (setting instanceof KeybindSetting) {
                KeybindSetting keybindSetting = (KeybindSetting)setting;
                moduleConfig.addProperty(key, (Number)keybindSetting.getKey());
                continue;
            }
            if (setting instanceof StringSetting) {
                StringSetting stringSetting = (StringSetting)setting;
                String value = stringSetting.getValue();
                moduleConfig.addProperty(key, value == null ? "" : value);
                continue;
            }
            if (!(setting instanceof MinMaxSetting)) continue;
            MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
            JsonObject minMax = new JsonObject();
            minMax.addProperty("1", (Number)minMaxSetting.getMinValue());
            minMax.addProperty("2", (Number)minMaxSetting.getMaxValue());
            moduleConfig.add(key, (JsonElement)minMax);
        }
        return moduleConfig;
    }

    private void quarantineCorruptProfile() {
        try {
            Path backup = Paths.get(String.valueOf(this.profilePath) + ".corrupt", new String[0]);
            Files.move(this.profilePath, backup, StandardCopyOption.REPLACE_EXISTING);
            Log.warn("Kept a copy of the corrupt profile at %s", backup);
        }
        catch (IOException e) {
            Log.error("Could not quarantine the corrupt profile", e);
        }
    }

    private static boolean isBoolean(JsonElement element) {
        return element != null && element.isJsonPrimitive() && ((JsonPrimitive)element).isBoolean();
    }

    private static boolean isNumber(JsonElement element) {
        return element != null && element.isJsonPrimitive() && ((JsonPrimitive)element).isNumber();
    }
}

