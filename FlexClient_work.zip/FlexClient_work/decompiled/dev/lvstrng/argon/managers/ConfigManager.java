package dev.lvstrng.argon.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.MinMaxSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.module.setting.StringSetting;
import dev.lvstrng.argon.utils.Log;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static String activeConfig = "default";

    public static Path getConfigsDirectory() {
        String home = System.getProperty("user.home", ".");
        Path dir = Paths.get(home).resolve("FlexClient").resolve("configs");
        try {
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }
        } catch (Exception ignored) {}
        return dir;
    }

    public static List<String> listConfigs() {
        List<String> list = new ArrayList<>();
        try {
            Path dir = getConfigsDirectory();
            ensureBuiltinConfigs(dir);
            if (Files.isDirectory(dir)) {
                try (Stream<Path> stream = Files.list(dir)) {
                    stream.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
                        String name = p.getFileName().toString();
                        list.add(name.substring(0, name.length() - 5));
                    });
                }
            }
        } catch (Exception ignored) {}
        if (!list.contains("default")) {
            list.add(0, "default");
        }
        if (!list.contains("DANGER")) {
            list.add("DANGER");
        }
        return list;
    }

    private static void ensureBuiltinConfigs(Path dir) {
        try {
            Path defaultFile = dir.resolve("default.json");
            if (!Files.exists(defaultFile)) {
                boolean extracted = false;
                try (InputStream in = ConfigManager.class.getResourceAsStream("/assets/flexclient/configs/default.json")) {
                    if (in != null) {
                        Files.copy(in, defaultFile);
                        extracted = true;
                    }
                } catch (Exception ignored) {}
                if (!extracted) {
                    saveCleanDefaultConfig(defaultFile);
                }
            }

            Path dangerFile = dir.resolve("DANGER.json");
            if (!Files.exists(dangerFile)) {
                try (InputStream in = ConfigManager.class.getResourceAsStream("/assets/flexclient/configs/DANGER.json")) {
                    if (in != null) {
                        Files.copy(in, dangerFile);
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private static void saveCleanDefaultConfig(Path file) {
        try {
            JsonObject root = new JsonObject();
            List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
            for (Module module : modules) {
                JsonObject obj = serializeModule(module);
                // In clean default config, modules are disabled initially (except ClickGUI)
                if (module instanceof dev.lvstrng.argon.module.modules.client.ClickGUI) {
                    obj.addProperty("enabled", true);
                } else {
                    obj.addProperty("enabled", false);
                }
                root.add(module.getName().toString(), obj);
            }
            Files.writeString(file, GSON.toJson(root));
        } catch (Exception ignored) {}
    }

    public static boolean saveConfig(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        String cleanName = name.trim().replaceAll("[^a-zA-Z0-9_\\-]", "");
        if (cleanName.isEmpty()) cleanName = "config";
        try {
            Path file = getConfigsDirectory().resolve(cleanName + ".json");
            JsonObject root = new JsonObject();
            List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
            for (Module module : modules) {
                root.add(module.getName().toString(), serializeModule(module));
            }
            Files.writeString(file, GSON.toJson(root));
            activeConfig = cleanName;
            return true;
        } catch (Exception e) {
            Log.error("Failed to save config: " + cleanName, e);
            return false;
        }
    }

    public static boolean loadConfig(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        String cleanName = name.trim();
        try {
            Path file = getConfigsDirectory().resolve(cleanName + ".json");
            if (!Files.exists(file)) {
                ensureBuiltinConfigs(getConfigsDirectory());
            }
            if (!Files.exists(file)) return false;
            String json = Files.readString(file);
            JsonObject root = GSON.fromJson(json, JsonObject.class);
            if (root == null) return false;

            List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
            for (Module module : modules) {
                JsonElement elem = root.get(module.getName().toString());
                if (elem != null && elem.isJsonObject()) {
                    applyModuleConfig(module, elem.getAsJsonObject());
                } else if (cleanName.equalsIgnoreCase("default") && !(module instanceof dev.lvstrng.argon.module.modules.client.ClickGUI)) {
                    // For default config, any unconfigured module is turned off
                    module.setEnabledStatus(false);
                    try { module.onDisable(); } catch (Exception ignored) {}
                }
            }
            activeConfig = cleanName;
            return true;
        } catch (Exception e) {
            Log.error("Failed to load config: " + cleanName, e);
            return false;
        }
    }

    public static boolean deleteConfig(String name) {
        if (name == null || name.equalsIgnoreCase("default") || name.equalsIgnoreCase("DANGER")) return false;
        try {
            Path file = getConfigsDirectory().resolve(name + ".json");
            boolean deleted = Files.deleteIfExists(file);
            if (deleted && activeConfig.equals(name)) {
                activeConfig = "default";
            }
            return deleted;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static String getActiveConfig() {
        return activeConfig;
    }

    public static void openConfigsFolder() {
        try {
            File folder = getConfigsDirectory().toFile();
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop.getDesktop().open(folder);
            } else {
                new ProcessBuilder("explorer.exe", folder.getAbsolutePath()).start();
            }
        } catch (Exception ignored) {}
    }

    private static JsonObject serializeModule(Module module) {
        JsonObject obj = new JsonObject();
        obj.addProperty("enabled", module.isEnabled());
        for (Setting<?> setting : module.getSettings()) {
            String key = setting.getName().toString();
            if (setting instanceof BooleanSetting) {
                obj.addProperty(key, ((BooleanSetting)setting).getValue());
            } else if (setting instanceof ModeSetting) {
                obj.addProperty(key, ((ModeSetting)setting).getModeIndex());
            } else if (setting instanceof NumberSetting) {
                obj.addProperty(key, ((NumberSetting)setting).getValue());
            } else if (setting instanceof KeybindSetting) {
                obj.addProperty(key, ((KeybindSetting)setting).getKey());
            } else if (setting instanceof StringSetting) {
                obj.addProperty(key, ((StringSetting)setting).getValue());
            } else if (setting instanceof MinMaxSetting) {
                MinMaxSetting mms = (MinMaxSetting)setting;
                JsonObject mm = new JsonObject();
                mm.addProperty("min", mms.getMinValue());
                mm.addProperty("max", mms.getMaxValue());
                obj.add(key, mm);
            }
        }
        return obj;
    }

    private static void applyModuleConfig(Module module, JsonObject config) {
        if (config.has("enabled")) {
            boolean enabled = config.get("enabled").getAsBoolean();
            module.setEnabledStatus(enabled);
            if (!(module instanceof dev.lvstrng.argon.module.modules.client.ClickGUI)) {
                if (enabled) {
                    try {
                        module.onEnable();
                    } catch (Exception ignored) {}
                } else {
                    try {
                        module.onDisable();
                    } catch (Exception ignored) {}
                }
            }
        }
        for (Setting<?> setting : module.getSettings()) {
            String key = setting.getName().toString();
            if (!config.has(key)) continue;
            JsonElement elem = config.get(key);
            try {
                if (setting instanceof BooleanSetting && elem.isJsonPrimitive()) {
                    ((BooleanSetting)setting).setValue(elem.getAsBoolean());
                } else if (setting instanceof ModeSetting && elem.isJsonPrimitive()) {
                    ((ModeSetting)setting).setModeIndex(elem.getAsInt());
                } else if (setting instanceof NumberSetting && elem.isJsonPrimitive()) {
                    ((NumberSetting)setting).setValue(elem.getAsDouble());
                } else if (setting instanceof KeybindSetting && elem.isJsonPrimitive()) {
                    int k = elem.getAsInt();
                    ((KeybindSetting)setting).setKey(k);
                    if (((KeybindSetting)setting).isModuleKey()) module.setKey(k);
                } else if (setting instanceof StringSetting && elem.isJsonPrimitive()) {
                    ((StringSetting)setting).setValue(elem.getAsString());
                } else if (setting instanceof MinMaxSetting && elem.isJsonObject()) {
                    MinMaxSetting mms = (MinMaxSetting)setting;
                    JsonObject mm = elem.getAsJsonObject();
                    if (mm.has("min") && mm.has("max")) {
                        mms.setMinValue(mm.get("min").getAsDouble());
                        mms.setMaxValue(mm.get("max").getAsDouble());
                    } else if (mm.has("1") && mm.has("2")) {
                        mms.setMinValue(mm.get("1").getAsDouble());
                        mms.setMaxValue(mm.get("2").getAsDouble());
                    }
                }
            } catch (Exception ignored) {}
        }
    }
}
