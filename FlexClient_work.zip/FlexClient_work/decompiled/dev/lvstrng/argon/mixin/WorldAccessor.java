/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1937
 *  net.minecraft.class_5562
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.lvstrng.argon.mixin;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_5562;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_1937.class})
public interface WorldAccessor {
    @Accessor(value="field_27082")
    public List<class_5562> getBlockEntityTickers();
}

