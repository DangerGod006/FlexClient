/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_12155
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import net.minecraft.class_12155;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_12155.class})
public class EntityHitboxDebugRendererMixin {
    @Redirect(method={"method_75432"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1297;method_5829()Lnet/minecraft/class_238;", ordinal=0))
    private class_238 flexClient$attackHitboxForDebug(class_1297 entity) {
        return EffectiveAttackHitboxProvider.boundsForDebugHitbox(entity, entity.method_5829());
    }
}

