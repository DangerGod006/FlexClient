/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.modules.render.NoBounce;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1799.class})
public class ItemStackMixin {
    @Inject(method={"method_7965"}, at={@At(value="HEAD")}, cancellable=true)
    private void removeBounceAnimation(CallbackInfoReturnable<Integer> cir) {
        if (Argon.mc.field_1724 != null) {
            class_1799 mainHandStack;
            NoBounce noBounce = Argon.INSTANCE.getModuleManager().getModule(NoBounce.class);
            if (Argon.INSTANCE != null && Argon.mc.field_1724 != null && noBounce.isEnabled() && (mainHandStack = Argon.mc.field_1724.method_6047()).method_31574(class_1802.field_8301)) {
                cir.setReturnValue((Object)0);
            }
        }
    }
}

