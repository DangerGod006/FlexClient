/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_310
 *  net.minecraft.class_638
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.EventManager;
import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.BlockBreakingListener;
import dev.lvstrng.argon.event.events.ItemUseListener;
import dev.lvstrng.argon.event.events.ResolutionListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.utils.MouseSimulation;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_310.class})
public class MinecraftClientMixin {
    @Shadow
    public class_638 field_1687;
    @Shadow
    @Final
    private class_1041 field_1704;

    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    private void onTick(CallbackInfo ci) {
        if (this.field_1687 != null) {
            TickListener.TickEvent event = new TickListener.TickEvent();
            EventManager.fire(event);
        }
    }

    @Inject(method={"method_15993"}, at={@At(value="HEAD")})
    private void onResolutionChanged(CallbackInfo ci) {
        EventManager.fire(new ResolutionListener.ResolutionEvent(this.field_1704));
    }

    @Inject(method={"method_1583"}, at={@At(value="HEAD")}, cancellable=true)
    private void onItemUse(CallbackInfo ci) {
        ItemUseListener.ItemUseEvent event = new ItemUseListener.ItemUseEvent();
        EventManager.fire(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
        if (MouseSimulation.shouldCancelVanillaUse()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1536"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttack(CallbackInfoReturnable<Boolean> cir) {
        AttackListener.AttackEvent event = new AttackListener.AttackEvent();
        EventManager.fire(event);
        if (event.isCancelled()) {
            cir.setReturnValue(Boolean.FALSE);
        }
        if (MouseSimulation.shouldCancelVanillaAttack()) {
            cir.setReturnValue(Boolean.FALSE);
        }
    }

    @Inject(method={"method_1590"}, at={@At(value="HEAD")}, cancellable=true)
    private void onBlockBreaking(boolean breaking, CallbackInfo ci) {
        BlockBreakingListener.BlockBreakingEvent event = new BlockBreakingListener.BlockBreakingEvent();
        EventManager.fire(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
        if (MouseSimulation.shouldCancelVanillaAttack()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1490"}, at={@At(value="HEAD")})
    private void onClose(CallbackInfo ci) {
        Argon.INSTANCE.getProfileManager().saveProfile();
    }
}

