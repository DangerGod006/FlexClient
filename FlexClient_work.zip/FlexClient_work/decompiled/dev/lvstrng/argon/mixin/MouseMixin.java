/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_312
 *  org.lwjgl.glfw.GLFW
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.event.EventManager;
import dev.lvstrng.argon.event.events.ButtonListener;
import dev.lvstrng.argon.event.events.MouseMoveListener;
import dev.lvstrng.argon.event.events.MouseUpdateListener;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_312.class})
public abstract class MouseMixin {
    @Shadow
    @Final
    private class_310 field_1779;
    @Unique
    private double argon$lastMouseX;
    @Unique
    private double argon$lastMouseY;
    @Unique
    private boolean argon$initialized;
    @Unique
    private final int[] argon$buttonStates = new int[8];

    @Shadow
    public abstract double method_1603();

    @Shadow
    public abstract double method_1604();

    @Inject(method={"method_55793"}, at={@At(value="TAIL")})
    private void onMouseUpdate(CallbackInfo ci) {
        EventManager.fire(new MouseUpdateListener.MouseUpdateEvent());
        long window = this.field_1779.method_22683().method_4490();
        double x = this.method_1603();
        double y = this.method_1604();
        if (!this.argon$initialized) {
            this.argon$initialized = true;
            this.argon$lastMouseX = x;
            this.argon$lastMouseY = y;
            for (int button = 0; button < this.argon$buttonStates.length; ++button) {
                this.argon$buttonStates[button] = GLFW.glfwGetMouseButton((long)window, (int)button);
            }
        } else {
            if (x != this.argon$lastMouseX || y != this.argon$lastMouseY) {
                this.argon$lastMouseX = x;
                this.argon$lastMouseY = y;
                EventManager.fire(new MouseMoveListener.MouseMoveEvent(window, x, y));
            }
            for (int button = 0; button < this.argon$buttonStates.length; ++button) {
                int state = GLFW.glfwGetMouseButton((long)window, (int)button);
                if (state == this.argon$buttonStates[button]) continue;
                this.argon$buttonStates[button] = state;
                EventManager.fire(new ButtonListener.ButtonEvent(button, window, state));
            }
        }
    }
}

