package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.utils.MouseSimulation;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Pseudo
@Mixin(targets = "net.fastclient.hud.modules.impl.hud.Keystrokes", remap = false)
public class FastClientKeystrokesMixin {
    @Redirect(
        method = "onRender",
        at = @At(value = "INVOKE", target = "Lorg/lwjgl/glfw/GLFW;glfwGetMouseButton(JI)I"),
        remap = false,
        require = 0
    )
    private int redirectGetMouseButton(long window, int button) {
        if (MouseSimulation.isMouseButtonPressed(button)) {
            return 1;
        }
        return GLFW.glfwGetMouseButton(window, button);
    }
}
