/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_3966
 *  net.minecraft.class_4587
 *  net.minecraft.class_757
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.EventManager;
import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.module.modules.combat.AttackHitbox;
import dev.lvstrng.argon.module.modules.combat.Reach;
import dev.lvstrng.argon.module.modules.combat.SpearSwap;
import dev.lvstrng.argon.module.modules.misc.Freecam;
import dev.lvstrng.argon.utils.WorldUtils;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_757.class})
public abstract class GameRendererMixin {
    private static final double VANILLA_REACH = 3.0;

    @Inject(method={"method_3188"}, at={@At(value="INVOKE_STRING", target="Lnet/minecraft/class_3695;method_15405(Ljava/lang/String;)V", args={"ldc=hand"})})
    private void onWorldRender(class_9779 tickCounter, CallbackInfo ci) {
        class_4587 matrixStack = new class_4587();
        EventManager.fire(new GameRenderListener.GameRenderEvent(matrixStack, tickCounter.method_60637(true)));
    }

    @Inject(method={"method_3202"}, at={@At(value="HEAD")}, cancellable=true)
    private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
        if (Argon.INSTANCE.getModuleManager().getModule(Freecam.class).isEnabled()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"method_3190"}, at={@At(value="TAIL")})
    private void onUpdateCrosshairTarget(float tickDelta, CallbackInfo ci) {
        if (Argon.INSTANCE == null) {
            return;
        }
        Reach reach = Argon.INSTANCE.getModuleManager().getModule(Reach.class);
        AttackHitbox attack = Argon.INSTANCE.getModuleManager().getModule(AttackHitbox.class);
        SpearSwap spearSwap = Argon.INSTANCE.getModuleManager().getModule(SpearSwap.class);
        boolean reachActive = reach != null && reach.isActive();
        boolean attackActive = attack != null && attack.isCombatActive();
        boolean spearActive = spearSwap != null && spearSwap.isReachActive();
        if (!reachActive && !attackActive && !spearActive) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        class_1297 cameraEntity = mc.method_1560();
        if (cameraEntity == null) {
            return;
        }
        double distance = 3.0;
        if (reachActive && reach.getReach() > 0.0) {
            distance = Math.max(distance, reach.getReach());
        }
        if (spearActive && spearSwap.getSpearReach() > 0.0) {
            distance = Math.max(distance, spearSwap.getSpearReach());
        }
        class_243 start = cameraEntity.method_5836(tickDelta);
        class_243 direction = cameraEntity.method_5828(tickDelta);
        class_243 end = start.method_1031(direction.field_1352 * distance, direction.field_1351 * distance, direction.field_1350 * distance);
        double maxSquared = distance * distance;
        double expansion = AttackHitbox.expansion();
        double rejectLimit = distance + expansion + 4.0;
        double rejectLimitSquared = rejectLimit * rejectLimit;
        class_1297 closest = null;
        class_243 closestHit = null;
        double closestDistance = maxSquared;
        for (class_1297 targetEntity : mc.field_1687.method_18112()) {
            if (targetEntity == cameraEntity || !targetEntity.method_5732() || !targetEntity.method_5805() || targetEntity.method_5707(start) > rejectLimitSquared) continue;
            class_238 box = AttackHitbox.combatBox(targetEntity, targetEntity.method_5871());
            Optional<class_243> hit = box.method_992(start, end);
            if (hit.isEmpty()) continue;
            double hitDistance = start.method_1025(hit.get());
            if (hitDistance < closestDistance) {
                closestDistance = hitDistance;
                closest = targetEntity;
                closestHit = hit.get();
            }
        }
        if (closest == null) {
            return;
        }
        if (reachActive && reach.shouldKeepCloserTarget() && mc.field_1765 instanceof class_3966) {
            class_3966 existing = (class_3966)mc.field_1765;
            double existingDistance = start.method_1025(existing.method_17784());
            if (existingDistance <= closestDistance) {
                return;
            }
        }
        if (!AttackHitbox.allowsThroughWallsTargeting() && !WorldUtils.hasLineOfSight(closestHit)) {
            return;
        }
        mc.field_1765 = new class_3966(closest, closestHit);
    }
}

