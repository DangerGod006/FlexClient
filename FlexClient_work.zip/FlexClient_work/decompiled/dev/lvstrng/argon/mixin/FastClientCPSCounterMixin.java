package dev.lvstrng.argon.mixin;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Pseudo
@Mixin(targets = "net.fastclient.hud.modules.impl.hud.CPSCounter", remap = false)
public class FastClientCPSCounterMixin {
    @Redirect(
        method = "onTick",
        at = @At(value = "INVOKE", target = "Lorg/lwjgl/glfw/GLFW;glfwGetMouseButton(JI)I"),
        remap = false,
        require = 0
    )
    private int redirectGetMouseButton(long window, int button) {
        // Return physical GLFW button state only so onTick does not duplicate
        // the click that MouseSimulation.registerFastClientHudClick() adds directly.
        return GLFW.glfwGetMouseButton(window, button);
    }
}
