/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event;

import java.util.EventListener;

public interface Listener
extends EventListener {
}

