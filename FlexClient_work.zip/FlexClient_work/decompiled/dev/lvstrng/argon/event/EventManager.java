/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.Event;
import dev.lvstrng.argon.event.Listener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class EventManager {
    private final Map<Class<?>, List<PrioritizedListener<?>>> listeners = new ConcurrentHashMap();
    private final Map<Class<?>, List<?>> snapshots = new ConcurrentHashMap();

    public static <L extends Listener, E extends Event<L>> void fire(E event) {
        Argon instance = Argon.INSTANCE;
        if (instance == null) {
            return;
        }
        EventManager manager = instance.getEventManager();
        if (manager != null) {
            manager.fireImpl(event);
        }
    }

    private <L extends Listener, E extends Event<L>> void fireImpl(E event) {
        List<L> snapshot = this.snapshot(event.getListenerType());
        if (snapshot.isEmpty()) {
            return;
        }
        event.fire(snapshot);
    }

    private <L extends Listener> List<L> snapshot(Class<L> type) {
        return this.snapshots.computeIfAbsent(type, this::buildSnapshot);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private List<?> buildSnapshot(Class<?> type) {
        ArrayList copy;
        List<PrioritizedListener<?>> registered = this.listeners.get(type);
        if (registered == null) {
            return List.of();
        }
        List<PrioritizedListener<?>> list = registered;
        synchronized (list) {
            if (registered.isEmpty()) {
                return List.of();
            }
            copy = new ArrayList(registered);
        }
        copy.sort(Comparator.comparingInt(entry -> entry.priority()).reversed());
        ArrayList out = new ArrayList(copy.size());
        for (PrioritizedListener prioritizedListener : copy) {
            Object listener = prioritizedListener.listener();
            if (listener == null) continue;
            out.add(listener);
        }
        return List.copyOf(out);
    }

    public <L extends Listener> void add(Class<L> type, L listener) {
        this.add(type, listener, 0);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <L extends Listener> void add(Class<L> type, L listener, int priority) {
        List registered;
        if (type == null || listener == null) {
            return;
        }
        List list = registered = this.listeners.computeIfAbsent(type, key -> new ArrayList());
        synchronized (list) {
            registered.add(new PrioritizedListener<L>(listener, priority));
        }
        this.snapshots.remove(type);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <L extends Listener> void remove(Class<L> type, L listener) {
        boolean changed;
        if (type == null || listener == null) {
            return;
        }
        List<PrioritizedListener<?>> registered = this.listeners.get(type);
        if (registered == null) {
            return;
        }
        List<PrioritizedListener<?>> list = registered;
        synchronized (list) {
            changed = registered.removeIf(entry -> entry.listener() == listener);
        }
        if (changed) {
            this.snapshots.remove(type);
        }
    }

    private static final class PrioritizedListener<L extends Listener> {
        private final L listener;
        private final int priority;

        PrioritizedListener(L listener, int priority) {
            this.listener = listener;
            this.priority = priority;
        }

        int priority() {
            return this.priority;
        }

        L listener() {
            return this.listener;
        }
    }
}

