/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4587
 */
package dev.lvstrng.argon.event.events;

import dev.lvstrng.argon.event.Event;
import dev.lvstrng.argon.event.Listener;
import java.util.List;
import net.minecraft.class_4587;

public interface GameRenderListener
extends Listener {
    public void onGameRender(GameRenderEvent var1);

    public static class GameRenderEvent
    extends Event<GameRenderListener> {
        public class_4587 matrices;
        public float delta;

        public GameRenderEvent(class_4587 matrices, float delta) {
            this.matrices = matrices;
            this.delta = delta;
        }

        @Override
        public void fire(List<GameRenderListener> listeners) {
            listeners.forEach(e -> e.onGameRender(this));
        }

        @Override
        public Class<GameRenderListener> getListenerType() {
            return GameRenderListener.class;
        }
    }
}

