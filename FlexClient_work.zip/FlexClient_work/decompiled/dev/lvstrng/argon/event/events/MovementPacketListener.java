/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event.events;

import dev.lvstrng.argon.event.Event;
import dev.lvstrng.argon.event.Listener;
import java.util.List;

public interface MovementPacketListener
extends Listener {
    public void onSendMovementPackets();

    public static class MovementPacketEvent
    extends Event<MovementPacketListener> {
        @Override
        public void fire(List<MovementPacketListener> listeners) {
            listeners.forEach(MovementPacketListener::onSendMovementPackets);
        }

        @Override
        public Class<MovementPacketListener> getListenerType() {
            return MovementPacketListener.class;
        }
    }
}

