/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event.events;

import dev.lvstrng.argon.event.Event;
import dev.lvstrng.argon.event.Listener;
import java.util.List;

public interface TickListener
extends Listener {
    public void onTick();

    public static class TickEvent
    extends Event<TickListener> {
        @Override
        public void fire(List<TickListener> listeners) {
            listeners.forEach(TickListener::onTick);
        }

        @Override
        public Class<TickListener> getListenerType() {
            return TickListener.class;
        }
    }
}

