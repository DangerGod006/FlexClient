/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event.events;

import dev.lvstrng.argon.event.Event;
import dev.lvstrng.argon.event.Listener;
import java.util.List;

public interface ButtonListener
extends Listener {
    public void onButtonPress(ButtonEvent var1);

    public static class ButtonEvent
    extends Event<ButtonListener> {
        public int button;
        public int action;
        public long window;

        public ButtonEvent(int button, long window, int action) {
            this.button = button;
            this.window = window;
            this.action = action;
        }

        @Override
        public void fire(List<ButtonListener> listeners) {
            listeners.forEach(e -> e.onButtonPress(this));
        }

        @Override
        public Class<ButtonListener> getListenerType() {
            return ButtonListener.class;
        }
    }
}

