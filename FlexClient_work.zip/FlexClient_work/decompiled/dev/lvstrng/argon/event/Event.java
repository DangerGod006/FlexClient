/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.event;

import dev.lvstrng.argon.event.Listener;
import java.util.List;

public abstract class Event<T extends Listener> {
    public abstract void fire(List<T> var1);

    public abstract Class<T> getListenerType();
}

