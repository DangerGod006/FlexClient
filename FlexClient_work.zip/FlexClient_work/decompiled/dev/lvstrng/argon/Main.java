/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ModInitializer
 */
package dev.lvstrng.argon;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.utils.Log;
import net.fabricmc.api.ModInitializer;

public final class Main
implements ModInitializer {
    public void onInitialize() {
        try {
            new Argon();
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            Log.error("Initialization interrupted", e);
        }
        catch (Exception e) {
            Log.error("Initialization failed - the client may not work correctly", e);
        }
    }
}

