/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 */
package dev.lvstrng.argon;

import dev.lvstrng.argon.event.EventManager;
import dev.lvstrng.argon.gui.ClickGui;
import dev.lvstrng.argon.hitbox.compat.BetterHitRegCompat;
import dev.lvstrng.argon.managers.FriendManager;
import dev.lvstrng.argon.managers.ProfileManager;
import dev.lvstrng.argon.module.ModuleManager;
import dev.lvstrng.argon.utils.Log;
import dev.lvstrng.argon.utils.rotation.RotatorManager;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class Argon {
    public RotatorManager rotatorManager;
    public ProfileManager profileManager;
    public ModuleManager moduleManager;
    public EventManager eventManager;
    public FriendManager friendManager;
    public static class_310 mc;
    public String version = " b1.3 DANGER";
    public static boolean BETA;
    public static Argon INSTANCE;
    public boolean guiInitialized;
    public ClickGui clickGui;
    public class_437 previousScreen = null;
    public long lastModified;
    public File argonJar;

    public Argon() throws InterruptedException, IOException {
        Log.info("Initializing...");
        INSTANCE = this;
        this.eventManager = new EventManager();
        Log.info("Registering modules...");
        this.moduleManager = new ModuleManager();
        Log.info("Registering hitbox compatibility adapters...");
        BetterHitRegCompat.initialize();
        Log.info("Loading resources...");
        this.clickGui = new ClickGui();
        this.rotatorManager = new RotatorManager();
        this.profileManager = new ProfileManager();
        this.friendManager = new FriendManager();
        Log.info("Loading configuration...");
        this.getProfileManager().loadProfile();
        this.setLastModified();
        this.guiInitialized = false;
        mc = class_310.method_1551();
        Log.info("Initialization complete (Minecraft %s).", mc.method_1515());
    }

    public ProfileManager getProfileManager() {
        return this.profileManager;
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public FriendManager getFriendManager() {
        return this.friendManager;
    }

    public EventManager getEventManager() {
        return this.eventManager;
    }

    public ClickGui getClickGui() {
        return this.clickGui;
    }

    public void resetModifiedDate() {
        this.argonJar.setLastModified(this.lastModified);
    }

    public String getVersion() {
        return this.version;
    }

    public void setLastModified() {
        try {
            this.argonJar = new File(Argon.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            this.lastModified = this.argonJar.lastModified();
        }
        catch (URISyntaxException uRISyntaxException) {
            // empty catch block
        }
    }
}

