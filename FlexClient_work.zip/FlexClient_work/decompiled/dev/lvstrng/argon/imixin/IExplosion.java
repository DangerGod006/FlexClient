/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 */
package dev.lvstrng.argon.imixin;

import net.minecraft.class_243;

public interface IExplosion {
    public void set(class_243 var1, float var2, boolean var3);
}

