/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.imixin;

public interface IKeyBinding {
    public boolean isActuallyPressed();

    public void resetPressed();
}

