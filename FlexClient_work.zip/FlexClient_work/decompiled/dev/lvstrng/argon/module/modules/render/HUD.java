/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_640
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.gui.CatleanTheme;
import dev.lvstrng.argon.gui.ClickGui;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import dev.lvstrng.argon.utils.Utils;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_640;

public final class HUD
extends Module
implements HudListener {
    private static final CharSequence argon = EncryptedString.of("DANGER |");
    private static final CharSequence ownerText = EncryptedString.of("Developed by DANGERxDEV");
    private final BooleanSetting info = new BooleanSetting(EncryptedString.of("Info"), true);
    private final BooleanSetting ownerInfo = (BooleanSetting)new BooleanSetting(EncryptedString.of("Owner Info"), true).setDescription(EncryptedString.of("Shows 'Developed by DANGERxDEV' text in top left"));
    private final BooleanSetting modules = (BooleanSetting)new BooleanSetting("Modules", true).setDescription(EncryptedString.of("Renders module array list"));

    public HUD() {
        super(EncryptedString.of("HUD"), EncryptedString.of("Renders the client version and enabled modules on the HUD"), -1, Category.RENDER);
        this.addSettings(this.info, this.ownerInfo, this.modules);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(HudListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(HudListener.class, this);
        super.onDisable();
    }

    @Override
    public void onRenderHud(HudListener.HudEvent event) {
        if (this.mc.field_1755 != Argon.INSTANCE.clickGui) {
            List<Module> enabledModules = Argon.INSTANCE.getModuleManager().getEnabledModules().stream().sorted((module1, module2) -> {
                CharSequence name1 = module1.getName();
                CharSequence name2 = module2.getName();
                int filteredLength1 = TextRenderer.getWidth(name1);
                int filteredLength2 = TextRenderer.getWidth(name2);
                return Integer.compare(filteredLength2, filteredLength1);
            }).toList();
            class_332 context = event.context;
            boolean customFont = ClickGUI.customFont.getValue();
            if (!(this.mc.field_1755 instanceof ClickGui)) {
                if (this.info.getValue() && this.mc.field_1724 != null) {
                    class_640 entry;
                    String server;
                    RenderUtils.unscaledProjection(context);
                    int argonOffset = 10;
                    int argonOffset2 = 10 + TextRenderer.getWidth(argon);
                    Object ping = "Ping: ";
                    String fps = "FPS: " + this.mc.method_47599() + " |";
                    String string = server = this.mc.method_1558() == null ? "None" : this.mc.method_1558().field_3761;
                    ping = this.mc != null && this.mc.field_1724 != null && this.mc.method_1562() != null ? ((entry = this.mc.method_1562().method_2871(this.mc.field_1724.method_5667())) != null ? (String)ping + entry.method_2959() + " |" : (String)ping + "N/A |") : (String)ping + "N/A |";
                    RenderUtils.renderRoundedQuad(context, new Color(35, 35, 35, 255), 5.0, 6.0, argonOffset2 + TextRenderer.getWidth(fps) + TextRenderer.getWidth((CharSequence)ping) + TextRenderer.getWidth(server) + 35, 30.0, 5.0, 15.0);
                    TextRenderer.drawString(argon, context, argonOffset, 12, Utils.getMainColor(255, 4).getRGB());
                    TextRenderer.drawString(fps, context, (argonOffset += TextRenderer.getWidth(argon)) + 10, 12, Utils.getMainColor(255, 3).getRGB());
                    TextRenderer.drawString((CharSequence)ping, context, argonOffset + 10 + TextRenderer.getWidth(fps) + 10, 12, Utils.getMainColor(255, 2).getRGB());
                    TextRenderer.drawString(server, context, argonOffset + 10 + TextRenderer.getWidth(fps) + TextRenderer.getWidth((CharSequence)ping) + 20, 12, Utils.getMainColor(255, 1).getRGB());
                    RenderUtils.scaledProjection(context);
                }
                if (this.ownerInfo.getValue() && this.mc.field_1724 != null) {
                    RenderUtils.unscaledProjection(context);
                    float scale = 1.5f;
                    org.joml.Matrix3x2fStack matrices = context.method_51448();
                    matrices.pushMatrix();
                    matrices.scale(scale, scale);

                    int rawScreenW = this.mc.method_22683().method_4489();
                    int scaledScreenW = (int)(rawScreenW / scale);

                    String clientTitle = "FlexClient";
                    String devPrefix = "by ";
                    String devName = "DANGERxDEV";
                    int clientW = TextRenderer.getWidth(clientTitle);
                    int devPreW = TextRenderer.getWidth(devPrefix);
                    int devNameW = TextRenderer.getWidth(devName);
                    int badgeH = 24;
                    int totalBadgeW = 14 + 12 + clientW + 8 + 6 + 8 + devPreW + devNameW + 20 + 14;
                    int bx = scaledScreenW - totalBadgeW - 16;
                    int by = 10;

                    // 1. Animated breathing accent pulse
                    float pulse = (float)(Math.sin((double)System.currentTimeMillis() / 450.0) * 0.25 + 0.75);
                    Color accent = CatleanTheme.getAccentColor(255);
                    Color glowBorder = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(220.0f * pulse));
                    Color bloomBg = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(25.0f * pulse));

                    // 2. Soft outer glow bloom
                    CatleanTheme.drawRoundedRect(context, bx - 2, by - 2, totalBadgeW + 4, badgeH + 4, 13.0, bloomBg);

                    // 3. Ultra-dark obsidian frosted glass body
                    CatleanTheme.drawRoundedRect(context, bx, by, totalBadgeW, badgeH, 12.0, new Color(9, 13, 22, 245));
                    CatleanTheme.drawRoundedOutline(context, bx, by, totalBadgeW, badgeH, 12.0, 1.0, glowBorder);

                    // 4. Glowing electric lightning icon
                    TextRenderer.drawString("⚡", context, bx + 12, by + 6, accent.getRGB());

                    // 5. Client brand title
                    int cx = bx + 24;
                    TextRenderer.drawString(clientTitle, context, cx, by + 6, accent.getRGB());

                    // 6. Styled divider
                    int sepX = cx + clientW + 6;
                    TextRenderer.drawString("|", context, sepX, by + 6, new Color(255, 255, 255, 50).getRGB());

                    // 7. Developer tag
                    int dx = sepX + 8;
                    TextRenderer.drawString(devPrefix, context, dx, by + 6, CatleanTheme.TEXT_MUTED.getRGB());
                    int nx = dx + devPreW;
                    TextRenderer.drawString(devName, context, nx, by + 6, CatleanTheme.TEXT_PRIMARY.getRGB());

                    // 8. Live Radar ping animation (expanding ripple + solid center dot)
                    int dotCenterX = bx + totalBadgeW - 16;
                    int dotCenterY = by + badgeH / 2;
                    float cycle = (float)((System.currentTimeMillis() % 1400L) / 1400.0);
                    int ringAlpha = (int)(180.0f * (1.0f - cycle));
                    int ringSize = (int)(3.0f + cycle * 6.0f);
                    Color ringCol = new Color(34, 197, 94, ringAlpha);
                    CatleanTheme.drawRoundedOutline(context, dotCenterX - ringSize / 2, dotCenterY - ringSize / 2, ringSize, ringSize, ringSize / 2.0, 1.0, ringCol);

                    // Solid radar center dot
                    CatleanTheme.drawRoundedRect(context, dotCenterX - 3, dotCenterY - 3, 6, 6, 3.0, new Color(34, 197, 94, 255));

                    matrices.popMatrix();
                    RenderUtils.scaledProjection(context);
                }
                if (this.modules.getValue()) {
                    int offset = 55;
                    for (Module module : enabledModules) {
                        RenderUtils.unscaledProjection(context);
                        int charOffset = 6 + TextRenderer.getWidth(module.getName());
                        RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, 175), 0.0, offset - 4, charOffset + 5, offset + 18 - 1, 0.0, 0.0, 0.0, 5.0, 10.0);
                        context.method_25296(0, offset - 4, 2, offset + 18, Utils.getMainColor(255, enabledModules.indexOf(module)).getRGB(), Utils.getMainColor(255, enabledModules.indexOf(module) + 1).getRGB());
                        int charOffset2 = customFont ? 5 : 8;
                        TextRenderer.drawString(module.getName(), context, charOffset2, offset + (customFont ? 1 : 0), Utils.getMainColor(255, enabledModules.indexOf(module)).getRGB());
                        offset += 21;
                        RenderUtils.scaledProjection(context);
                    }
                }
            }
        }
    }
}

