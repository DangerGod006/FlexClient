/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1656
 *  net.minecraft.class_746
 */
package dev.lvstrng.argon.module.modules.misc;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.class_1656;
import net.minecraft.class_746;

public final class Fly
extends Module
implements TickListener {
    private final ModeSetting<Mode> mode = new ModeSetting<Mode>(EncryptedString.of("Mode"), Mode.Velocity, Mode.class);
    private final NumberSetting speed = (NumberSetting)new NumberSetting(EncryptedString.of("Speed"), 0.05, 5.0, 0.6, 0.05).setDescription(EncryptedString.of("Blocks per tick in Velocity mode, creative fly multiplier in Vanilla mode"));
    private final BooleanSetting hover = (BooleanSetting)new BooleanSetting(EncryptedString.of("Hover"), true).setDescription(EncryptedString.of("Hold altitude when neither jump nor sneak is held"));
    private final BooleanSetting noFallDamage = (BooleanSetting)new BooleanSetting(EncryptedString.of("No Fall Damage"), true).setDescription(EncryptedString.of("Keeps fall distance at zero while flying"));

    public Fly() {
        super(EncryptedString.of("Fly"), EncryptedString.of("Client side flight | set the speed in the settings"), -1, Category.MISC);
        this.addSettings(this.mode, this.speed, this.hover, this.noFallDamage);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.restoreAbilities();
        super.onDisable();
    }

    @Override
    public void onTick() {
        double dz;
        double cos;
        double yaw;
        double sin;
        double dx;
        double length;
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1690 == null) {
            return;
        }
        class_746 player = this.mc.field_1724;
        if (!player.method_5805() || player.method_5765()) {
            return;
        }
        if (this.noFallDamage.getValue()) {
            player.field_6017 = 0.0;
        }
        if (this.mode.isMode(Mode.Vanilla)) {
            class_1656 abilities = player.method_31549();
            abilities.field_7478 = true;
            abilities.field_7479 = true;
            abilities.method_7248((float)(this.speed.getValue() / 5.0));
            return;
        }
        double speedValue = this.speed.getValue();
        double forward = 0.0;
        double strafe = 0.0;
        if (this.mc.field_1690.field_1894.method_1434()) {
            forward += 1.0;
        }
        if (this.mc.field_1690.field_1881.method_1434()) {
            forward -= 1.0;
        }
        if (this.mc.field_1690.field_1913.method_1434()) {
            strafe += 1.0;
        }
        if (this.mc.field_1690.field_1849.method_1434()) {
            strafe -= 1.0;
        }
        if ((length = Math.sqrt((dx = forward * -(sin = Math.sin(yaw = Math.toRadians(player.method_36454()))) + strafe * (cos = Math.cos(yaw))) * dx + (dz = forward * cos + strafe * sin) * dz)) > 0.0) {
            dx = dx / length * speedValue;
            dz = dz / length * speedValue;
        }
        double dy = this.mc.field_1690.field_1903.method_1434() ? speedValue : (this.mc.field_1690.field_1832.method_1434() ? -speedValue : (this.hover.getValue() ? 0.0 : player.method_18798().field_1351 * 0.8));
        player.method_18800(dx, dy, dz);
    }

    private void restoreAbilities() {
        if (this.mc == null || this.mc.field_1724 == null) {
            return;
        }
        class_746 player = this.mc.field_1724;
        class_1656 abilities = player.method_31549();
        abilities.field_7478 = player.method_68878() || player.method_7325();
        abilities.field_7479 = false;
    }

    public static enum Mode {
        Velocity,
        Vanilla;

    }
}

