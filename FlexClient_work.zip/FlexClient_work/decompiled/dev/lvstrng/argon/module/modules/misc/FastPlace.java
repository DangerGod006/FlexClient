/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_3965
 *  net.minecraft.class_9334
 *  org.lwjgl.glfw.GLFW
 */
package dev.lvstrng.argon.module.modules.misc;

import dev.lvstrng.argon.event.events.ItemUseListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.MouseSimulation;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class FastPlace
extends Module
implements TickListener,
ItemUseListener {
    private final NumberSetting speed = (NumberSetting)new NumberSetting(EncryptedString.of("Speed"), 0.0, 100.0, 0.0, 1.0).setDescription(EncryptedString.of("0 = instant, 100 = vanilla speed"));
    private final BooleanSetting blockOnly = (BooleanSetting)new BooleanSetting(EncryptedString.of("Block Only"), false).setDescription(EncryptedString.of("Only fast place solid BlockItems. Buckets, trapdoors, frames etc. unaffected when ON"));
    private final BooleanSetting excludeCobweb = (BooleanSetting)new BooleanSetting(EncryptedString.of("Exclude Cobweb"), true).setDescription(EncryptedString.of("Don't fast place cobweb items from hotbar"));
    private final BooleanSetting excludeAnchor = (BooleanSetting)new BooleanSetting(EncryptedString.of("Exclude Anchor"), true).setDescription(EncryptedString.of("Don't fast place respawn anchor items from hotbar"));
    private final BooleanSetting excludeGlowstone = (BooleanSetting)new BooleanSetting(EncryptedString.of("Exclude Glowstone"), true).setDescription(EncryptedString.of("Don't fast place glowstone items from hotbar"));
    private final BooleanSetting excludeCrystal = (BooleanSetting)new BooleanSetting(EncryptedString.of("Exclude Crystal"), true).setDescription(EncryptedString.of("Don't fast place end crystals from hotbar"));
    private final BooleanSetting excludeObsidian = (BooleanSetting)new BooleanSetting(EncryptedString.of("Exclude Obsidian"), false).setDescription(EncryptedString.of("Don't fast place obsidian from hotbar"));
    private final BooleanSetting clickSimulation = (BooleanSetting)new BooleanSetting(EncryptedString.of("Click Simulation"), false).setDescription(EncryptedString.of("Simulates a real right-click so CPS counter sees it as legit"));
    private final BooleanSetting perItemSpeed = (BooleanSetting)new BooleanSetting(EncryptedString.of("Per-Item Speed"), false).setDescription(EncryptedString.of("Use a separate place speed per item. -1 = leave that item at its normal speed"));
    private final NumberSetting obsidianSpeed = (NumberSetting)new NumberSetting(EncryptedString.of("Obsidian Speed"), -1.0, 100.0, -1.0, 1.0).setDescription(EncryptedString.of("0 = instant, 100 = vanilla, -1 = normal (excluded)"));
    private final NumberSetting crystalSpeed = new NumberSetting(EncryptedString.of("Crystal Speed"), -1.0, 100.0, -1.0, 1.0);
    private final NumberSetting anchorSpeed = new NumberSetting(EncryptedString.of("Anchor Speed"), -1.0, 100.0, -1.0, 1.0);
    private final NumberSetting glowstoneSpeed = new NumberSetting(EncryptedString.of("Glowstone Speed"), -1.0, 100.0, -1.0, 1.0);
    private final NumberSetting cobwebSpeed = new NumberSetting(EncryptedString.of("Cobweb Speed"), -1.0, 100.0, -1.0, 1.0);
    private int clock = 0;

    public FastPlace() {
        super(EncryptedString.of("Fast Place"), EncryptedString.of("Removes the right-click cooldown between block placements"), -1, Category.MISC);
        this.addSettings(this.speed, this.blockOnly, this.excludeCobweb, this.excludeAnchor, this.excludeGlowstone, this.excludeCrystal, this.excludeObsidian, this.clickSimulation, this.perItemSpeed, this.obsidianSpeed, this.crystalSpeed, this.anchorSpeed, this.glowstoneSpeed, this.cobwebSpeed);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(ItemUseListener.class, this);
        this.clock = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(ItemUseListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null) {
            class_3965 hit;
            class_239 class_2392;
            if (this.mc.field_1755 != null) {
                class_1799 activeStack;
                if (this.mc.field_1724.method_6115() && !FastPlace.isFoodStack(activeStack = this.mc.field_1724.method_6030()) && FastPlace.isOf(activeStack, class_1802.field_8255)) {
                    return;
                }
            } else if (this.mc.method_22683() != null && GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), (int)1) == 1 && (class_2392 = this.mc.field_1765) instanceof class_3965 && (hit = (class_3965)class_2392).method_17783() == class_239.class_240.field_1332 && !this.shouldSkipCurrentItems()) {
                boolean dontPlace;
                boolean bl = dontPlace = this.clock != 0;
                if (dontPlace) {
                    --this.clock;
                } else {
                    class_1268 hand;
                    class_1269 result;
                    if (this.clickSimulation.getValue()) {
                        MouseSimulation.mouseClick(1);
                    }
                    if ((result = this.mc.field_1761.method_2896(this.mc.field_1724, hand = this.getPlacementHand(), hit)) != null && result.method_23665()) {
                        this.mc.field_1724.method_6104(hand);
                    }
                    this.clock = Math.max(0, (int)Math.round(this.currentSpeed() * 4.0 / 100.0));
                }
            }
        }
    }

    @Override
    public void onItemUse(ItemUseListener.ItemUseEvent event) {
        class_3965 hit;
        class_239 class_2392;
        if (event != null && this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null && (class_2392 = this.mc.field_1765) instanceof class_3965 && (hit = (class_3965)class_2392).method_17783() == class_239.class_240.field_1332 && !this.shouldSkipCurrentItems()) {
            event.cancel();
        }
    }

    private boolean shouldSkipCurrentItems() {
        class_1799 mainHand = this.mc.field_1724.method_6047();
        class_1799 offHand = this.mc.field_1724.method_6079();
        if (this.perItemSpeed.getValue()) {
            Double override = this.overrideFor(mainHand, offHand);
            if (override != null) {
                return override < 0.0;
            }
            return this.blockOnly.getValue() && !FastPlace.isBlockItem(mainHand) && !FastPlace.isBlockItem(offHand);
        }
        if (!this.excludeCobweb.getValue() || !FastPlace.isOf(mainHand, class_1802.field_8786) && !FastPlace.isOf(offHand, class_1802.field_8786)) {
            if (!this.excludeAnchor.getValue() || !FastPlace.isOf(mainHand, class_1802.field_23141) && !FastPlace.isOf(offHand, class_1802.field_23141)) {
                if (!this.excludeGlowstone.getValue() || !FastPlace.isOf(mainHand, class_1802.field_8801) && !FastPlace.isOf(offHand, class_1802.field_8801)) {
                    if (!this.excludeCrystal.getValue() || !FastPlace.isOf(mainHand, class_1802.field_8301) && !FastPlace.isOf(offHand, class_1802.field_8301)) {
                        return !this.excludeObsidian.getValue() || !FastPlace.isOf(mainHand, class_1802.field_8281) && !FastPlace.isOf(offHand, class_1802.field_8281) ? this.blockOnly.getValue() && !FastPlace.isBlockItem(mainHand) && !FastPlace.isBlockItem(offHand) : true;
                    }
                    return true;
                }
                return true;
            }
            return true;
        }
        return true;
    }

    private double currentSpeed() {
        Double override;
        if (this.perItemSpeed.getValue() && this.mc != null && this.mc.field_1724 != null && (override = this.overrideFor(this.mc.field_1724.method_6047(), this.mc.field_1724.method_6079())) != null && override >= 0.0) {
            return override;
        }
        return this.speed.getValue();
    }

    private Double overrideFor(class_1799 mainHand, class_1799 offHand) {
        if (FastPlace.isOf(mainHand, class_1802.field_8281) || FastPlace.isOf(offHand, class_1802.field_8281)) {
            return this.obsidianSpeed.getValue();
        }
        if (FastPlace.isOf(mainHand, class_1802.field_8301) || FastPlace.isOf(offHand, class_1802.field_8301)) {
            return this.crystalSpeed.getValue();
        }
        if (FastPlace.isOf(mainHand, class_1802.field_23141) || FastPlace.isOf(offHand, class_1802.field_23141)) {
            return this.anchorSpeed.getValue();
        }
        if (FastPlace.isOf(mainHand, class_1802.field_8801) || FastPlace.isOf(offHand, class_1802.field_8801)) {
            return this.glowstoneSpeed.getValue();
        }
        if (FastPlace.isOf(mainHand, class_1802.field_8786) || FastPlace.isOf(offHand, class_1802.field_8786)) {
            return this.cobwebSpeed.getValue();
        }
        return null;
    }

    private class_1268 getPlacementHand() {
        class_1799 mainHand = this.mc.field_1724.method_6047();
        class_1799 offHand = this.mc.field_1724.method_6079();
        if (FastPlace.isPlaceableStack(mainHand)) {
            return class_1268.field_5808;
        }
        if (FastPlace.isPlaceableStack(offHand)) {
            return class_1268.field_5810;
        }
        return !FastPlace.isEmpty(mainHand) ? class_1268.field_5808 : class_1268.field_5810;
    }

    private static boolean isPlaceableStack(class_1799 stack) {
        return FastPlace.isBlockItem(stack) || FastPlace.isOf(stack, class_1802.field_8301);
    }

    private static boolean isBlockItem(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && stack.method_7909() instanceof class_1747;
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isFoodStack(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && stack.method_57826(class_9334.field_50075);
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isOf(class_1799 stack, class_1792 item) {
        try {
            return stack != null && item != null && !stack.method_7960() && stack.method_31574(item);
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isEmpty(class_1799 stack) {
        try {
            return stack == null || stack.method_7960();
        }
        catch (Throwable ignored) {
            return true;
        }
    }
}

