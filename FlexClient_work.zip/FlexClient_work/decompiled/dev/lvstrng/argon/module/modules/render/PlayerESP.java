/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.modules.client.Friends;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.ProjectionUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.Utils;
import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public final class PlayerESP
extends Module
implements GameRenderListener,
HudListener {
    public final ModeSetting<Mode> mode = new ModeSetting<Mode>(EncryptedString.of("Mode"), Mode.ThreeD, Mode.class);
    private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
    private final NumberSetting width = new NumberSetting(EncryptedString.of("Line width"), 1.0, 10.0, 1.0, 1.0);
    private final BooleanSetting tracers = (BooleanSetting)new BooleanSetting(EncryptedString.of("Tracers"), false).setDescription(EncryptedString.of("Draws a line from your player to the other"));
    private final BooleanSetting threeDOutline = new BooleanSetting(EncryptedString.of("3D box outline"), false);
    private final BooleanSetting twoDOutline = new BooleanSetting(EncryptedString.of("2D Outline"), false);

    public PlayerESP() {
        super(EncryptedString.of("Player ESP"), EncryptedString.of("Renders players through walls"), -1, Category.RENDER);
        this.addSettings(this.alpha, this.mode, this.threeDOutline, this.twoDOutline, this.width, this.tracers);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(GameRenderListener.class, this);
        this.eventManager.add(HudListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(GameRenderListener.class, this);
        this.eventManager.remove(HudListener.class, this);
        super.onDisable();
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        class_4184 camera;
        if (this.mc.field_1687 != null && this.mc.field_1724 != null && (camera = this.mc.field_1773.method_19418()) != null) {
            event.matrices.method_22903();
            class_243 cameraPos = camera.method_71156();
            event.matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(camera.method_19329()));
            event.matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            event.matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            for (class_1657 player : this.mc.field_1687.method_18456()) {
                if (!this.shouldRender((class_1297)player)) continue;
                class_238 box = this.getRenderBox(player, event.delta).method_1014(0.02);
                Color playerColor = this.getPlayerColor(player, this.alpha.getValueInt());
                Color playerOutlineColor = this.getPlayerColor(player, 255);
                if (this.mode.isMode(Mode.ThreeD)) {
                    RenderUtils.renderFilledBox(event.matrices, (float)box.field_1323, (float)box.field_1322, (float)box.field_1321, (float)box.field_1320, (float)box.field_1325, (float)box.field_1324, playerColor.brighter());
                    if (this.threeDOutline.getValue()) {
                        RenderUtils.renderBoxOutline(event.matrices, box, playerOutlineColor, this.width.getValueInt());
                    }
                }
                boolean isFriend = Argon.INSTANCE.getFriendManager().isFriend(player);
                boolean friendTracerOn = false;
                try {
                    Friends friendsModule = (Friends)Argon.INSTANCE.getModuleManager().getModule(Friends.class);
                    if (friendsModule != null && friendsModule.isEnabled() && friendsModule.friendTracer.getValue()) {
                        friendTracerOn = true;
                    }
                } catch (Exception ignored) {
                }

                boolean drawTracer = this.tracers.getValue() || (isFriend && friendTracerOn);
                if (drawTracer) {
                    class_243 tracerStart = this.mc.field_1765 != null ? this.mc.field_1765.method_17784() : (this.mc.field_1724 != null ? this.mc.field_1724.method_33571() : cameraPos);
                    if (tracerStart != null) {
                        RenderUtils.renderLine(event.matrices, playerOutlineColor, tracerStart, player.method_30950(RenderUtils.tickProgress()));
                    }
                }
            }
            event.matrices.method_22909();
        }
    }

    @Override
    public void onRenderHud(HudListener.HudEvent event) {
        if (this.mode.isMode(Mode.TwoD) && this.mc.field_1687 != null && this.mc.field_1724 != null) {
            for (class_1657 player : this.mc.field_1687.method_18456()) {
                ScreenBounds bounds;
                if (!this.shouldRender((class_1297)player) || (bounds = this.projectBounds(this.getRenderBox(player, event.delta))) == null || !bounds.isValid()) continue;
                Color outlineColor = this.getPlayerColor(player, 255);
                int thickness = Math.max(1, this.width.getValueInt());
                if (this.twoDOutline.getValue()) {
                    Color borderColor = new Color(0, 0, 0, Math.min(255, outlineColor.getAlpha()));
                    this.drawOutline(event.context, bounds, thickness + 1, borderColor);
                }
                this.drawOutline(event.context, bounds, thickness, outlineColor);
            }
        }
    }

    private boolean shouldRender(class_1297 entity) {
        class_1657 player;
        return entity instanceof class_1657 && (player = (class_1657)entity) != this.mc.field_1724 && player.method_5805();
    }

    private class_238 getRenderBox(class_1657 player, float tickDelta) {
        double x = class_3532.method_16436((double)tickDelta, (double)player.field_6014, (double)player.method_23317());
        double y = class_3532.method_16436((double)tickDelta, (double)player.field_6036, (double)player.method_23318());
        double z = class_3532.method_16436((double)tickDelta, (double)player.field_5969, (double)player.method_23321());
        return player.method_5829().method_989(x - player.method_23317(), y - player.method_23318(), z - player.method_23321());
    }

    private ScreenBounds projectBounds(class_238 box) {
        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;
        int visibleCorners = 0;
        for (double x : new double[]{box.field_1323, box.field_1320}) {
            for (double y : new double[]{box.field_1322, box.field_1325}) {
                for (double z : new double[]{box.field_1321, box.field_1324}) {
                    ProjectionUtils.ProjectedPoint projected = ProjectionUtils.project(new class_243(x, y, z));
                    if (projected == null) continue;
                    ++visibleCorners;
                    minX = Math.min(minX, (double)projected.x());
                    minY = Math.min(minY, (double)projected.y());
                    maxX = Math.max(maxX, (double)projected.x());
                    maxY = Math.max(maxY, (double)projected.y());
                }
            }
        }
        return visibleCorners == 0 ? null : new ScreenBounds((int)Math.floor(minX), (int)Math.floor(minY), (int)Math.ceil(maxX), (int)Math.ceil(maxY));
    }

    private void drawOutline(class_332 context, ScreenBounds bounds, int thickness, Color color) {
        int packedColor = color.getRGB();
        context.method_25294(bounds.minX, bounds.minY, bounds.maxX, bounds.minY + thickness, packedColor);
        context.method_25294(bounds.minX, bounds.maxY - thickness, bounds.maxX, bounds.maxY, packedColor);
        context.method_25294(bounds.minX, bounds.minY + thickness, bounds.minX + thickness, bounds.maxY - thickness, packedColor);
        context.method_25294(bounds.maxX - thickness, bounds.minY + thickness, bounds.maxX, bounds.maxY - thickness, packedColor);
    }

    private Color getPlayerColor(class_1657 player, int alpha) {
        try {
            Friends friendsModule = (Friends)Argon.INSTANCE.getModuleManager().getModule(Friends.class);
            if (friendsModule != null && friendsModule.isEnabled() && friendsModule.friendEsp.getValue() && Argon.INSTANCE.getFriendManager().isFriend(player)) {
                return new Color(0, 230, 118, alpha); // Distinct emerald green for friends
            }
        } catch (Exception ignored) {
        }
        return this.getColor(alpha);
    }

    private Color getColor(int alpha) {
        int red = ClickGUI.red.getValueInt();
        int green = ClickGUI.green.getValueInt();
        int blue = ClickGUI.blue.getValueInt();
        return ClickGUI.rainbow.getValue() ? ColorUtils.getBreathingRGBColor(1, alpha) : new Color(red, green, blue, alpha);
    }

    public static enum Mode {
        TwoD,
        ThreeD;

    }

    private record ScreenBounds(int minX, int minY, int maxX, int maxY) {
        private boolean isValid() {
            return this.maxX > this.minX && this.maxY > this.minY;
        }
    }
}

