package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.ItemUseListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.BlockUtils;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.MathUtils;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.WorldUtils;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class AnchorMacro
extends Module
implements TickListener,
ItemUseListener {
    private final BooleanSetting undetectable = (BooleanSetting)new BooleanSetting(EncryptedString.of("Undetectable"), false).setDescription(EncryptedString.of("Enforces humanized 1-tick pacing, slot sync, and raycast limits to bypass premium servers (MCPVP, Minemen, etc.)"));
    private final BooleanSetting whileUse = (BooleanSetting)new BooleanSetting(EncryptedString.of("While Use"), true).setDescription(EncryptedString.of("If it should trigger while eating/using shield"));
    private final BooleanSetting stopOnKill = (BooleanSetting)new BooleanSetting(EncryptedString.of("Stop on Kill"), false).setDescription(EncryptedString.of("Doesn't anchor if body nearby"));
    private final BooleanSetting clickSimulation = (BooleanSetting)new BooleanSetting(EncryptedString.of("Click Simulation"), false).setDescription(EncryptedString.of("Makes the CPS hud think you're legit"));
    private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting switchChance = new NumberSetting(EncryptedString.of("Switch Chance"), 0.0, 100.0, 100.0, 1.0);
    private final NumberSetting placeChance = (NumberSetting)new NumberSetting(EncryptedString.of("Place Chance"), 0.0, 100.0, 100.0, 1.0).setDescription(EncryptedString.of("Randomization"));
    private final NumberSetting glowstoneDelay = new NumberSetting(EncryptedString.of("Glowstone Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting glowstoneChance = new NumberSetting(EncryptedString.of("Glowstone Chance"), 0.0, 100.0, 100.0, 1.0);
    private final NumberSetting explodeDelay = new NumberSetting(EncryptedString.of("Explode Delay"), 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting explodeChance = new NumberSetting(EncryptedString.of("Explode Chance"), 0.0, 100.0, 100.0, 1.0);
    private final NumberSetting explodeSlot = new NumberSetting(EncryptedString.of("Explode Slot"), 1.0, 9.0, 1.0, 1.0);
    private final BooleanSetting onlyOwn = new BooleanSetting(EncryptedString.of("Only Own"), false);
    private final BooleanSetting onlyCharge = new BooleanSetting(EncryptedString.of("Only Charge"), false);
    private int switchClock = 0;
    private int glowstoneClock = 0;
    private int explodeClock = 0;
    private final Set<class_2338> ownedAnchors = new HashSet<class_2338>();

    public AnchorMacro() {
        super(EncryptedString.of("Anchor Macro"), EncryptedString.of("Automatically blows up respawn anchors for you"), -1, Category.COMBAT);
        this.addSettings(this.undetectable, this.whileUse, this.stopOnKill, this.clickSimulation, this.placeChance, this.switchDelay, this.switchChance, this.glowstoneDelay, this.glowstoneChance, this.explodeDelay, this.explodeChance, this.explodeSlot, this.onlyOwn, this.onlyCharge);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(ItemUseListener.class, this);
        this.switchClock = 0;
        this.glowstoneClock = 0;
        this.explodeClock = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(ItemUseListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }

        if (this.mc.field_1755 != null) {
            return;
        }

        boolean usingItem = (this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075)
            || this.mc.field_1724.method_6047().method_7909() instanceof class_1819
            || this.mc.field_1724.method_6079().method_7909() instanceof class_1819
            || this.mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075))
            && GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), (int)1) == 1;

        if (usingItem && !this.whileUse.getValue()) {
            return;
        }

        if (this.stopOnKill.getValue() && WorldUtils.isDeadBodyNearby()) {
            return;
        }

        if (!KeyUtils.isKeyPressed(1)) {
            return;
        }

        class_239 crosshair = this.mc.field_1765;
        if (!(crosshair instanceof class_3965)) {
            return;
        }

        class_3965 hit = (class_3965)crosshair;
        class_2338 blockPos = hit.method_17777();
        if (!BlockUtils.isBlock(blockPos, class_2246.field_23152)) {
            return;
        }

        if (this.onlyOwn.getValue() && !this.ownedAnchors.contains(blockPos)) {
            return;
        }

        // Release vanilla right-click so client doesn't conflict
        this.mc.field_1690.field_1904.method_23481(false);

        // Case 1: Uncharged anchor -> charge it
        if (BlockUtils.isAnchorNotCharged(blockPos)) {
            this.handleCharge(hit);
            return;
        }

        // Case 2: Charged anchor
        if (BlockUtils.isAnchorCharged(blockPos)) {
            // In Only Charge mode with continuous holding, keep explodeSlot equipped but do not auto-explode
            if (this.onlyCharge.getValue()) {
                int slot = this.explodeSlot.getValueInt() - 1;
                int currentSlot = this.mc.field_1724.method_31548().method_67532();
                if (currentSlot != slot) {
                    this.setSlotAndSync(slot);
                }
                return;
            }

            // Normal mode -> auto-explode anchor
            this.handleExplode(hit);
        }
    }

    private boolean handleCharge(class_3965 hit) {
        if (hit == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return false;
        class_2338 blockPos = hit.method_17777();
        if (!BlockUtils.isBlock(blockPos, class_2246.field_23152)) return false;
        if (!BlockUtils.isAnchorNotCharged(blockPos)) return false;
        if (this.onlyOwn.getValue() && !this.ownedAnchors.contains(blockPos)) return false;
        if (!this.isValidAnchorTarget(hit)) return false;

        int randomInt = MathUtils.randomInt(1, 100);
        if (randomInt > this.placeChance.getValueInt()) return false;

        // Switch to glowstone if not already holding it
        if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
            if (!this.selectGlowstone()) {
                return false;
            }
        }

        // Place glowstone on anchor to charge it
        if (this.clickSimulation.getValue() || this.undetectable.getValue()) {
            MouseSimulation.mouseClick(1);
        }
        WorldUtils.placeBlock(hit, true);

        // Seamlessly switch to explode slot (Totem / Sword) right after charging!
        int explodeTarget = this.explodeSlot.getValueInt() - 1;
        this.setSlotAndSync(explodeTarget);
        return true;
    }

    private boolean handleExplode(class_3965 hit) {
        if (hit == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return false;
        class_2338 blockPos = hit.method_17777();
        if (!BlockUtils.isBlock(blockPos, class_2246.field_23152)) return false;
        if (!BlockUtils.isAnchorCharged(blockPos)) return false;
        if (this.onlyOwn.getValue() && !this.ownedAnchors.contains(blockPos)) return false;
        if (!this.isValidAnchorTarget(hit)) return false;

        // Ensure player is on explode slot
        int slot = this.explodeSlot.getValueInt() - 1;
        int currentSlot = this.mc.field_1724.method_31548().method_67532();
        if (currentSlot != slot) {
            this.setSlotAndSync(slot);
        }

        int randomInt = MathUtils.randomInt(1, 100);
        if (randomInt > this.explodeChance.getValueInt()) return false;

        if (this.clickSimulation.getValue() || this.undetectable.getValue()) {
            MouseSimulation.mouseClick(1);
        }
        WorldUtils.placeBlock(hit, true);
        this.ownedAnchors.remove(blockPos);
        return true;
    }

    private boolean isValidAnchorTarget(class_3965 hit) {
        if (hit == null || this.mc == null || this.mc.field_1724 == null) return false;
        if (this.undetectable.getValue()) {
            class_243 eyePos = this.mc.field_1724.method_33571();
            class_243 hitPos = hit.method_17784();
            // Strict survival reach: max 4.0 blocks (4.0 * 4.0 = 16.0)
            if (eyePos.method_1025(hitPos) > 16.0) {
                return false;
            }
        }
        return true;
    }

    private void setSlotAndSync(int slot) {
        if (slot >= 0 && slot < 9 && this.mc.field_1724 != null) {
            this.mc.field_1724.method_31548().method_61496(slot);
            if (this.mc.field_1761 != null) {
                try {
                    ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
                } catch (Throwable ignored) {}
            }
        }
    }

    private boolean selectGlowstone() {
        if (this.mc.field_1724 == null) return false;
        class_1661 inv = this.mc.field_1724.method_31548();
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (stack != null && !stack.method_7960() && stack.method_7909() == class_1802.field_8801) {
                this.setSlotAndSync(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onItemUse(ItemUseListener.ItemUseEvent event) {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return;

        class_239 crosshair = this.mc.field_1765;
        if (!(crosshair instanceof class_3965)) return;
        class_3965 hitResult = (class_3965)crosshair;
        class_2338 blockPos = hitResult.method_17777();

        // 1. Track anchor placement (both main hand and offhand)
        class_1799 mainHand = this.mc.field_1724.method_6047();
        class_1799 offHand = this.mc.field_1724.method_6079();
        boolean placingAnchor = (mainHand != null && mainHand.method_7909() == class_1802.field_23141)
            || (offHand != null && offHand.method_7909() == class_1802.field_23141);

        if (placingAnchor && hitResult.method_17783() == class_239.class_240.field_1332) {
            class_2350 dir = hitResult.method_17780();
            class_2338 pos = hitResult.method_17777();
            if (!this.mc.field_1687.method_8320(pos).method_45474()) {
                switch (dir) {
                    case field_11036: {
                        this.ownedAnchors.add(pos.method_10069(0, 1, 0));
                        break;
                    }
                    case field_11033: {
                        this.ownedAnchors.add(pos.method_10069(0, -1, 0));
                        break;
                    }
                    case field_11034: {
                        this.ownedAnchors.add(pos.method_10069(1, 0, 0));
                        break;
                    }
                    case field_11039: {
                        this.ownedAnchors.add(pos.method_10069(-1, 0, 0));
                        break;
                    }
                    case field_11043: {
                        this.ownedAnchors.add(pos.method_10069(0, 0, -1));
                        break;
                    }
                    case field_11035: {
                        this.ownedAnchors.add(pos.method_10069(0, 0, 1));
                    }
                }
            } else {
                this.ownedAnchors.add(pos);
            }
        }

        // 2. Direct click on Respawn Anchor
        if (BlockUtils.isBlock(blockPos, class_2246.field_23152)) {
            if (this.onlyOwn.getValue() && !this.ownedAnchors.contains(blockPos)) {
                return;
            }

            // If anchor is uncharged and holding an anchor: cancel vanilla placement so no anchor is placed on the side!
            if (BlockUtils.isAnchorNotCharged(blockPos) && placingAnchor) {
                event.cancel();
            }

            // Charge uncharged anchor immediately on click
            if (BlockUtils.isAnchorNotCharged(blockPos)) {
                this.handleCharge(hitResult);
                return;
            }

            // If anchor is charged: clicking it explodes the anchor!
            if (BlockUtils.isAnchorCharged(blockPos)) {
                this.handleExplode(hitResult);
            }
        }
    }
}
