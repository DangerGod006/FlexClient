/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.class_1297;
import net.minecraft.class_238;

public final class AttackHitbox
extends Module {
    private final NumberSetting hitboxSize = (NumberSetting)new NumberSetting(EncryptedString.of("Hitbox Size"), 0.0, 2.0, 0.0, 0.01).setDescription(EncryptedString.of("How much the effective attack hitbox is grown. 0 keeps the vanilla box"));
    private final BooleanSetting throughWalls = (BooleanSetting)new BooleanSetting(EncryptedString.of("Combat Through Walls"), false).setDescription(EncryptedString.of("Let targeting ignore walls. Targeting only - it never changes how boxes are drawn"));

    public AttackHitbox() {
        super(EncryptedString.of("Attack Hitbox"), EncryptedString.of("Effective attack hitbox | target size and visibility"), -1, Category.COMBAT);
        this.addSettings(this.hitboxSize, this.throughWalls);
    }

    public boolean isCombatActive() {
        if (!this.isEnabled()) {
            return false;
        }
        return this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null;
    }

    public double getExpansion() {
        return this.hitboxSize.getValue();
    }

    public boolean allowsThroughWalls() {
        return this.throughWalls.getValue();
    }

    public static boolean isActive() {
        return EffectiveAttackHitboxProvider.isActive();
    }

    public static double expansion() {
        return EffectiveAttackHitboxProvider.expansion();
    }

    public static boolean allowsThroughWallsTargeting() {
        return EffectiveAttackHitboxProvider.allowsThroughWallsTargeting();
    }

    public static class_238 combatBox(class_1297 entity, double margin) {
        return EffectiveAttackHitboxProvider.combatBox(entity, margin);
    }

    public static class_238 visualBox(class_1297 entity, float tickDelta) {
        return EffectiveAttackHitboxProvider.effectiveBox(entity, tickDelta);
    }

    public static class_238 vanillaBox(class_1297 entity, float tickDelta) {
        return EffectiveAttackHitboxProvider.vanillaBox(entity, tickDelta);
    }
}

