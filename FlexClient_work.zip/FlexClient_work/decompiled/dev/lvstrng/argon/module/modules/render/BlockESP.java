/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_4184
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.ProjectionUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public final class BlockESP
extends Module
implements TickListener,
GameRenderListener,
HudListener {
    private final BooleanSetting fill = (BooleanSetting)new BooleanSetting(EncryptedString.of("Fill"), true).setDescription(EncryptedString.of("Fills block boxes with color"));
    private final BooleanSetting outline = (BooleanSetting)new BooleanSetting(EncryptedString.of("Outline"), true).setDescription(EncryptedString.of("Draws outline around block boxes"));
    private final BooleanSetting tracers = (BooleanSetting)new BooleanSetting(EncryptedString.of("Tracers"), false).setDescription(EncryptedString.of("Draws lines from center screen to each block"));
    private final NumberSetting range = (NumberSetting)new NumberSetting(EncryptedString.of("Range"), 8.0, 128.0, 32.0, 4.0).setDescription(EncryptedString.of("Block search radius"));
    private final NumberSetting lineWidth = new NumberSetting(EncryptedString.of("Line Width"), 1.0, 5.0, 1.0, 1.0);
    private final NumberSetting fillAlpha = new NumberSetting(EncryptedString.of("Fill Alpha"), 0.0, 255.0, 40.0, 5.0);
    private final BooleanSetting findObsidian = new BooleanSetting(EncryptedString.of("Obsidian"), false);
    private final BooleanSetting findBedrock = new BooleanSetting(EncryptedString.of("Bedrock"), false);
    private final BooleanSetting findDiamondOre = new BooleanSetting(EncryptedString.of("Diamond Ore"), false);
    private final BooleanSetting findAncientDebris = new BooleanSetting(EncryptedString.of("Ancient Debris"), false);
    private final BooleanSetting findSpawner = new BooleanSetting(EncryptedString.of("Spawner"), false);
    private final BooleanSetting findChest = new BooleanSetting(EncryptedString.of("Chest"), false);
    private final BooleanSetting findGoldOre = new BooleanSetting(EncryptedString.of("Gold Ore"), false);
    private final BooleanSetting findIronOre = new BooleanSetting(EncryptedString.of("Iron Ore"), false);
    private final NumberSetting obsidianR = new NumberSetting(EncryptedString.of("Obsidian R"), 0.0, 255.0, 128.0, 1.0);
    private final NumberSetting obsidianG = new NumberSetting(EncryptedString.of("Obsidian G"), 0.0, 255.0, 0.0, 1.0);
    private final NumberSetting obsidianB = new NumberSetting(EncryptedString.of("Obsidian B"), 0.0, 255.0, 255.0, 1.0);
    private final NumberSetting bedrockR = new NumberSetting(EncryptedString.of("Bedrock R"), 0.0, 255.0, 80.0, 1.0);
    private final NumberSetting bedrockG = new NumberSetting(EncryptedString.of("Bedrock G"), 0.0, 255.0, 80.0, 1.0);
    private final NumberSetting bedrockB = new NumberSetting(EncryptedString.of("Bedrock B"), 0.0, 255.0, 80.0, 1.0);
    private final NumberSetting diamondR = new NumberSetting(EncryptedString.of("Diamond Ore R"), 0.0, 255.0, 0.0, 1.0);
    private final NumberSetting diamondG = new NumberSetting(EncryptedString.of("Diamond Ore G"), 0.0, 255.0, 200.0, 1.0);
    private final NumberSetting diamondB = new NumberSetting(EncryptedString.of("Diamond Ore B"), 0.0, 255.0, 255.0, 1.0);
    private final NumberSetting debrisR = new NumberSetting(EncryptedString.of("Ancient Debris R"), 0.0, 255.0, 180.0, 1.0);
    private final NumberSetting debrisG = new NumberSetting(EncryptedString.of("Ancient Debris G"), 0.0, 255.0, 80.0, 1.0);
    private final NumberSetting debrisB = new NumberSetting(EncryptedString.of("Ancient Debris B"), 0.0, 255.0, 20.0, 1.0);
    private final NumberSetting spawnerR = new NumberSetting(EncryptedString.of("Spawner R"), 0.0, 255.0, 255.0, 1.0);
    private final NumberSetting spawnerG = new NumberSetting(EncryptedString.of("Spawner G"), 0.0, 255.0, 100.0, 1.0);
    private final NumberSetting spawnerB = new NumberSetting(EncryptedString.of("Spawner B"), 0.0, 255.0, 0.0, 1.0);
    private final NumberSetting chestR = new NumberSetting(EncryptedString.of("Chest R"), 0.0, 255.0, 255.0, 1.0);
    private final NumberSetting chestG = new NumberSetting(EncryptedString.of("Chest G"), 0.0, 255.0, 215.0, 1.0);
    private final NumberSetting chestB = new NumberSetting(EncryptedString.of("Chest B"), 0.0, 255.0, 0.0, 1.0);
    private final NumberSetting goldOreR = new NumberSetting(EncryptedString.of("Gold Ore R"), 0.0, 255.0, 255.0, 1.0);
    private final NumberSetting goldOreG = new NumberSetting(EncryptedString.of("Gold Ore G"), 0.0, 255.0, 215.0, 1.0);
    private final NumberSetting goldOreB = new NumberSetting(EncryptedString.of("Gold Ore B"), 0.0, 255.0, 0.0, 1.0);
    private final NumberSetting ironOreR = new NumberSetting(EncryptedString.of("Iron Ore R"), 0.0, 255.0, 200.0, 1.0);
    private final NumberSetting ironOreG = new NumberSetting(EncryptedString.of("Iron Ore G"), 0.0, 255.0, 150.0, 1.0);
    private final NumberSetting ironOreB = new NumberSetting(EncryptedString.of("Iron Ore B"), 0.0, 255.0, 100.0, 1.0);
    private final List<class_2338> cachedBlocks = new CopyOnWriteArrayList<class_2338>();
    private long lastCacheTick = 0L;

    public BlockESP() {
        super(EncryptedString.of("Block ESP"), EncryptedString.of("Highlights target blocks through walls"), -1, Category.RENDER);
        this.addSettings(this.fill, this.outline, this.tracers, this.range, this.lineWidth, this.fillAlpha, this.findObsidian, this.obsidianR, this.obsidianG, this.obsidianB, this.findBedrock, this.bedrockR, this.bedrockG, this.bedrockB, this.findDiamondOre, this.diamondR, this.diamondG, this.diamondB, this.findAncientDebris, this.debrisR, this.debrisG, this.debrisB, this.findSpawner, this.spawnerR, this.spawnerG, this.spawnerB, this.findChest, this.chestR, this.chestG, this.chestB, this.findGoldOre, this.goldOreR, this.goldOreG, this.goldOreB, this.findIronOre, this.ironOreR, this.ironOreG, this.ironOreB);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(GameRenderListener.class, this);
        this.eventManager.add(HudListener.class, this);
        this.cachedBlocks.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(GameRenderListener.class, this);
        this.eventManager.remove(HudListener.class, this);
        this.cachedBlocks.clear();
        super.onDisable();
    }

    @Override
    public void onTick() {
        long currentTick;
        if (this.mc.field_1724 != null && this.mc.field_1687 != null && (currentTick = (long)this.mc.field_1724.field_6012) - this.lastCacheTick >= 10L) {
            this.lastCacheTick = currentTick;
            int r = this.range.getValueInt();
            class_2338 origin = this.mc.field_1724.method_24515();
            ArrayList<class_2338> newCache = new ArrayList<class_2338>();
            for (int x = -r; x <= r; ++x) {
                for (int y = -r; y <= r; ++y) {
                    for (int z = -r; z <= r; ++z) {
                        class_2338 pos = origin.method_10069(x, y, z);
                        class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                        if (!this.isEnabled(block)) continue;
                        newCache.add(pos);
                    }
                }
            }
            this.cachedBlocks.clear();
            this.cachedBlocks.addAll(newCache);
        }
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null && (this.fill.getValue() || this.outline.getValue())) {
            class_4184 camera = this.mc.field_1773.method_19418();
            class_243 camPos = camera.method_71156();
            event.matrices.method_22903();
            event.matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(camera.method_19329()));
            event.matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            event.matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
            for (class_2338 pos : this.cachedBlocks) {
                if (this.mc.field_1687 == null) break;
                class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                Color color = this.getColor(block);
                if (color == null) continue;
                class_238 box = new class_238((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260(), (double)(pos.method_10263() + 1), (double)(pos.method_10264() + 1), (double)(pos.method_10260() + 1)).method_1014(0.01);
                if (this.fill.getValue()) {
                    Color fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.fillAlpha.getValueInt());
                    RenderUtils.renderFilledBox(event.matrices, (float)box.field_1323, (float)box.field_1322, (float)box.field_1321, (float)box.field_1320, (float)box.field_1325, (float)box.field_1324, fillColor);
                }
                if (!this.outline.getValue()) continue;
                RenderUtils.renderBoxOutline(event.matrices, box, new Color(color.getRed(), color.getGreen(), color.getBlue(), 255), this.lineWidth.getValueInt());
            }
            event.matrices.method_22909();
        }
    }

    @Override
    public void onRenderHud(HudListener.HudEvent event) {
        if (this.tracers.getValue() && this.mc.field_1724 != null && this.mc.field_1687 != null) {
            int screenCX = this.mc.method_22683().method_4486() / 2;
            int screenCY = this.mc.method_22683().method_4502() / 2;
            for (class_2338 pos : this.cachedBlocks) {
                class_243 center;
                ProjectionUtils.ProjectedPoint projected;
                if (this.mc.field_1687 == null) break;
                class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                Color color = this.getColor(block);
                if (color == null || (projected = ProjectionUtils.project(center = class_243.method_24953((class_2382)pos))) == null) continue;
                event.context.method_51738(screenCX, (int)projected.x(), screenCY, color.getRGB());
                event.context.method_51742((int)projected.x(), screenCY, (int)projected.y(), color.getRGB());
            }
        }
    }

    private boolean isEnabled(class_2248 block) {
        if (block == class_2246.field_10540) {
            return this.findObsidian.getValue();
        }
        if (block == class_2246.field_9987) {
            return this.findBedrock.getValue();
        }
        if (block == class_2246.field_10442 || block == class_2246.field_29029) {
            return this.findDiamondOre.getValue();
        }
        if (block == class_2246.field_22109) {
            return this.findAncientDebris.getValue();
        }
        if (block == class_2246.field_10260) {
            return this.findSpawner.getValue();
        }
        if (block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_10443) {
            return this.findChest.getValue();
        }
        if (block == class_2246.field_10571 || block == class_2246.field_29026 || block == class_2246.field_23077) {
            return this.findGoldOre.getValue();
        }
        return block != class_2246.field_10212 && block != class_2246.field_29027 ? false : this.findIronOre.getValue();
    }

    private Color getColor(class_2248 block) {
        if (block == class_2246.field_10540) {
            return new Color(this.obsidianR.getValueInt(), this.obsidianG.getValueInt(), this.obsidianB.getValueInt());
        }
        if (block == class_2246.field_9987) {
            return new Color(this.bedrockR.getValueInt(), this.bedrockG.getValueInt(), this.bedrockB.getValueInt());
        }
        if (block == class_2246.field_10442 || block == class_2246.field_29029) {
            return new Color(this.diamondR.getValueInt(), this.diamondG.getValueInt(), this.diamondB.getValueInt());
        }
        if (block == class_2246.field_22109) {
            return new Color(this.debrisR.getValueInt(), this.debrisG.getValueInt(), this.debrisB.getValueInt());
        }
        if (block == class_2246.field_10260) {
            return new Color(this.spawnerR.getValueInt(), this.spawnerG.getValueInt(), this.spawnerB.getValueInt());
        }
        if (block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_10443) {
            return new Color(this.chestR.getValueInt(), this.chestG.getValueInt(), this.chestB.getValueInt());
        }
        if (block == class_2246.field_10571 || block == class_2246.field_29026 || block == class_2246.field_23077) {
            return new Color(this.goldOreR.getValueInt(), this.goldOreG.getValueInt(), this.goldOreB.getValueInt());
        }
        return block != class_2246.field_10212 && block != class_2246.field_29027 ? null : new Color(this.ironOreR.getValueInt(), this.ironOreG.getValueInt(), this.ironOreB.getValueInt());
    }
}

