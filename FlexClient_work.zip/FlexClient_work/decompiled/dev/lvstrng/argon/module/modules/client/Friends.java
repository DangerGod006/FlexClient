/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_3966
 *  net.minecraft.class_4184
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package dev.lvstrng.argon.module.modules.client;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.ButtonListener;
import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.managers.FriendManager;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.render.PlayerESP;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import dev.lvstrng.argon.utils.WorldUtils;
import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public final class Friends
extends Module
implements ButtonListener,
AttackListener,
HudListener,
GameRenderListener {
    private final KeybindSetting addFriendKey = (KeybindSetting)new KeybindSetting(EncryptedString.of("Friend Key"), 2, false).setDescription(EncryptedString.of("Key to add/remove friends"));
    public final BooleanSetting antiAttack = (BooleanSetting)new BooleanSetting(EncryptedString.of("Anti-Attack"), false).setDescription(EncryptedString.of("Doesn't let you hit friends"));
    public final BooleanSetting disableAimAssist = (BooleanSetting)new BooleanSetting(EncryptedString.of("Anti-Aim"), false).setDescription(EncryptedString.of("Disables aim assist for friends"));
    public final BooleanSetting friendStatus = (BooleanSetting)new BooleanSetting(EncryptedString.of("Friend Status"), false).setDescription(EncryptedString.of("Tells you if you're aiming at a friend or not"));
    public final BooleanSetting friendEsp = (BooleanSetting)new BooleanSetting(EncryptedString.of("Friend ESP"), true).setDescription(EncryptedString.of("Highlights friended players with a distinct green ESP color"));
    public final BooleanSetting friendTracer = (BooleanSetting)new BooleanSetting(EncryptedString.of("Friend Tracer"), true).setDescription(EncryptedString.of("Draws a tracer line to friended players in emerald green"));
    private FriendManager manager;

    public Friends() {
        super(EncryptedString.of("Friends"), EncryptedString.of("This module makes it so you can't do certain stuff if you have a player friended!"), -1, Category.CLIENT);
        this.addSettings(this.addFriendKey, this.antiAttack, this.disableAimAssist, this.friendStatus, this.friendEsp, this.friendTracer);
        this.setKey(-1);
    }

    @Override
    public void onEnable() {
        this.manager = Argon.INSTANCE.getFriendManager();
        this.eventManager.add(ButtonListener.class, this);
        this.eventManager.add(AttackListener.class, this);
        this.eventManager.add(HudListener.class, this);
        this.eventManager.add(GameRenderListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(ButtonListener.class, this);
        this.eventManager.remove(AttackListener.class, this);
        this.eventManager.remove(HudListener.class, this);
        this.eventManager.remove(GameRenderListener.class, this);
        super.onDisable();
    }

    @Override
    public void onButtonPress(ButtonListener.ButtonEvent event) {
        if (this.mc.field_1724 != null && this.mc.field_1755 == null) {
            class_239 hit = this.mc.field_1765;
            if (hit instanceof class_3966 entityHit) {
                if (entityHit.method_17782() instanceof class_1657 player) {
                    if (event.button == this.addFriendKey.getKey() && event.action == 1) {
                        if (!this.manager.isFriend(player)) {
                            this.manager.addFriend(player);
                        } else {
                            this.manager.removeFriend(player);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (this.antiAttack.getValue() && this.manager.isAimingOverFriend()) {
            event.cancel();
        }
    }

    @Override
    public void onRenderHud(HudListener.HudEvent event) {
        if (this.friendStatus.getValue()) {
            class_332 context = event.context;
            RenderUtils.unscaledProjection(context);
            class_239 hit = WorldUtils.getHitResult(100.0);
            if (hit instanceof class_3966 entityHit) {
                if (entityHit.method_17782() instanceof class_1657 player && this.manager.isFriend(player)) {
                    TextRenderer.drawCenteredString(EncryptedString.of("Player is friend"), context, this.mc.method_22683().method_4480() / 2, this.mc.method_22683().method_4507() / 2 + 25, new Color(0, 230, 118).getRGB());
                }
            }
            RenderUtils.scaledProjection(context);
        }
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (!this.friendEsp.getValue() && !this.friendTracer.getValue()) return;
        PlayerESP esp = (PlayerESP)Argon.INSTANCE.getModuleManager().getModule(PlayerESP.class);
        if (esp != null && esp.isEnabled()) {
            return;
        }

        class_4184 camera;
        if (this.mc.field_1687 != null && this.mc.field_1724 != null && (camera = this.mc.field_1773.method_19418()) != null) {
            event.matrices.method_22903();
            class_243 cameraPos = camera.method_71156();
            event.matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(camera.method_19329()));
            event.matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            event.matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            Color friendBoxColor = new Color(0, 230, 118, 100);
            Color friendOutlineColor = new Color(0, 230, 118, 255);

            class_243 tracerStart = this.mc.field_1765 != null ? this.mc.field_1765.method_17784() : (this.mc.field_1724 != null ? this.mc.field_1724.method_33571() : cameraPos);

            for (class_1657 player : this.mc.field_1687.method_18456()) {
                if (player == this.mc.field_1724 || !player.method_5805() || !this.manager.isFriend(player)) continue;

                if (this.friendEsp.getValue()) {
                    double x = class_3532.method_16436((double)event.delta, (double)player.field_6014, (double)player.method_23317());
                    double y = class_3532.method_16436((double)event.delta, (double)player.field_6036, (double)player.method_23318());
                    double z = class_3532.method_16436((double)event.delta, (double)player.field_5969, (double)player.method_23321());
                    class_238 box = player.method_5829().method_989(x - player.method_23317(), y - player.method_23318(), z - player.method_23321()).method_1014(0.02);

                    RenderUtils.renderFilledBox(event.matrices, (float)box.field_1323, (float)box.field_1322, (float)box.field_1321, (float)box.field_1320, (float)box.field_1325, (float)box.field_1324, friendBoxColor.brighter());
                    RenderUtils.renderBoxOutline(event.matrices, box, friendOutlineColor, 1);
                }

                if (this.friendTracer.getValue() && tracerStart != null) {
                    RenderUtils.renderLine(event.matrices, friendOutlineColor, tracerStart, player.method_30950(RenderUtils.tickProgress()));
                }
            }
            event.matrices.method_22909();
        }
    }
}
