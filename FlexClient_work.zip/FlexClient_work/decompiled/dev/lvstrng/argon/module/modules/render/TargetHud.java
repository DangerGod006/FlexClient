/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2824
 *  net.minecraft.class_2824$class_5908
 *  net.minecraft.class_332
 *  net.minecraft.class_640
 *  net.minecraft.class_7532
 *  net.minecraft.class_8685
 *  org.joml.Matrix3x2fStack
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.event.events.PacketSendListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.MathUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import dev.lvstrng.argon.utils.Utils;
import java.awt.Color;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import org.joml.Matrix3x2fStack;

public final class TargetHud
extends Module
implements HudListener,
PacketSendListener {
    private final NumberSetting xCoord = new NumberSetting(EncryptedString.of("X"), 0.0, 1920.0, 500.0, 1.0);
    private final NumberSetting yCoord = new NumberSetting(EncryptedString.of("Y"), 0.0, 1080.0, 500.0, 1.0);
    private final BooleanSetting hudTimeout = (BooleanSetting)new BooleanSetting(EncryptedString.of("Timeout"), true).setDescription(EncryptedString.of("Target hud will disappear after 10 seconds"));
    private long lastAttackTime = 0L;
    public static float animation;
    private static final long timeout = 10000L;

    public TargetHud() {
        super(EncryptedString.of("Target HUD"), EncryptedString.of("Gives you information about the enemy player"), -1, Category.RENDER);
        this.addSettings(this.xCoord, this.yCoord, this.hudTimeout);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(HudListener.class, this);
        this.eventManager.add(PacketSendListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(HudListener.class, this);
        this.eventManager.remove(PacketSendListener.class, this);
        super.onDisable();
    }

    @Override
    public void onRenderHud(HudListener.HudEvent event) {
        class_1657 player;
        class_1309 class_13092;
        class_332 context = event.context;
        int x = this.xCoord.getValueInt();
        int y = this.yCoord.getValueInt();
        RenderUtils.unscaledProjection(context);
        if ((!this.hudTimeout.getValue() || System.currentTimeMillis() - this.lastAttackTime <= 10000L) && this.mc.field_1724.method_6052() != null && (class_13092 = this.mc.field_1724.method_6052()) instanceof class_1657 && (player = (class_1657)class_13092).method_5805()) {
            class_1657 player1;
            class_1309 class_13093 = this.mc.field_1724.method_6052();
            animation = RenderUtils.fast(animation, !(class_13093 instanceof class_1657) || !(player1 = (class_1657)class_13093).method_5805() ? 1 : 0, 15.0f);
            class_640 entry = this.mc.method_1562().method_2871(player.method_5667());
            Matrix3x2fStack matrices = context.method_51448();
            matrices.pushMatrix();
            matrices.scaleAround(Math.max(0.0f, 1.0f - animation), 1.0f, (float)x + 170.0f, (float)y + 100.0f);
            RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, 175), x, y, x + 340, y + 200, 5.0, 5.0, 5.0, 5.0, 10.0);
            RenderUtils.renderRoundedQuad(context, Utils.getMainColor(255, 1), x, y + 27, x + 340, y + 29, 0.0, 0.0, 0.0, 0.0, 10.0);
            TextRenderer.drawString(player.method_5477().getString() + " - " + MathUtils.roundToDecimal(player.method_5739((class_1297)this.mc.field_1724), 0.5) + " blocks", context, x + 23, y + 5, Color.WHITE.getRGB());
            if (entry == null) {
                int charOff1 = x + 5;
                String chars = "Type: Bot";
                TextRenderer.drawString(chars, context, charOff1, y + 35, new Color(255, 80, 80, 255).getRGB());
                matrices.popMatrix();
                RenderUtils.scaledProjection(context);
                return;
            }
            int charOff1 = x + 5;
            Object chars = "Type: Player";
            TextRenderer.drawString((CharSequence)chars, context, charOff1, y + 35, Color.white.getRGB());
            TextRenderer.drawString("Health: " + Math.round(player.method_6032() + player.method_6067()), context, x + 5, y + 65, Color.GREEN.getRGB());
            context.method_25294(x, y + 200, x + 4, y + 200 - Math.min(Math.round((player.method_6032() + player.method_6067()) * 5.0f), 171), Color.GREEN.darker().getRGB());
            TextRenderer.drawString("Invisible: " + (player.method_5767() ? "Yes" : "No"), context, x + 5, y + 95, Color.WHITE.getRGB());
            TextRenderer.drawString("Ping: " + entry.method_2959(), context, x + 5, y + 125, Color.WHITE.getRGB());
            class_7532.method_52722((class_332)context, (class_8685)entry.method_52810(), (int)(x + 3), (int)(y + 3), (int)20);
            if (player.field_6235 != 0) {
                charOff1 = x + 125;
                chars = "Damage Tick: " + player.field_6235;
                TextRenderer.drawString((CharSequence)chars, context, charOff1, y + 65, Color.WHITE.getRGB());
                context.method_25294(x + 125, y + 80, x + 125 + player.field_6235 * 15, y + 83, this.getDamageTickColor(player.field_6235).getRGB());
            }
            matrices.popMatrix();
        } else {
            animation = RenderUtils.fast(animation, 1.0f, 15.0f);
        }
        RenderUtils.scaledProjection(context);
    }

    private Color getDamageTickColor(int hurtTime) {
        return switch (hurtTime) {
            case 0 -> null;
            case 1 -> new Color(0, 255, 0, 255);
            case 2 -> new Color(50, 255, 0, 255);
            case 3 -> new Color(100, 255, 0, 255);
            case 4 -> new Color(175, 255, 0, 255);
            case 5 -> new Color(200, 255, 0, 255);
            case 6 -> new Color(255, 255, 0, 255);
            case 7 -> new Color(255, 150, 0, 255);
            case 8 -> new Color(255, 100, 0, 255);
            case 9 -> new Color(255, 50, 0, 255);
            case 10 -> new Color(255, 0, 0, 255);
            default -> throw new IllegalStateException("uv" + hurtTime);
        };
    }

    @Override
    public void onPacketSend(PacketSendListener.PacketSendEvent event) {
        class_2596 class_25962 = event.packet;
        if (class_25962 instanceof class_2824) {
            class_2824 packet = (class_2824)class_25962;
            packet.method_34209(new class_2824.class_5908(){

                public void method_34219(class_1268 hand) {
                }

                public void method_34220(class_1268 hand, class_243 pos) {
                }

                public void method_34218() {
                    if (((TargetHud)TargetHud.this).mc.field_1692 instanceof class_1657) {
                        TargetHud.this.lastAttackTime = System.currentTimeMillis();
                    }
                }
            });
        }
    }
}

