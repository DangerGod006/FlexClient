package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.Friends;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.SwapCoordinator;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3966;

public final class ShieldDisabler
extends Module
implements TickListener,
AttackListener {
    private final NumberSetting switchDelay = (NumberSetting)new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 1.0, 1.0).setDescription(EncryptedString.of("Ticks to wait after swapping to axe before hitting (1 tick looks human & prevents anticheat fast-switch flags)"));
    private final NumberSetting hitDelay = (NumberSetting)new NumberSetting(EncryptedString.of("Hit Delay"), 0.0, 20.0, 1.0, 1.0).setDescription(EncryptedString.of("Ticks to hold axe after striking so the axe swing visually renders before switching back"));
    private final NumberSetting cooldown = (NumberSetting)new NumberSetting(EncryptedString.of("Cooldown"), 0.0, 40.0, 15.0, 1.0).setDescription(EncryptedString.of("Debounce cooldown in ticks after a shield stun (prevents jittery spam)"));
    private final BooleanSetting switchBack = (BooleanSetting)new BooleanSetting(EncryptedString.of("Switch Back"), true).setDescription(EncryptedString.of("Switch back to your previous weapon after disabling shield"));
    private final BooleanSetting checkCooldown = (BooleanSetting)new BooleanSetting(EncryptedString.of("Check Cooldown"), true).setDescription(EncryptedString.of("Wait for weapon attack cooldown (>= 85%) before striking"));
    private final BooleanSetting whileUsingShield = (BooleanSetting)new BooleanSetting(EncryptedString.of("While Using Shield"), false).setDescription(EncryptedString.of("Allow shield disabler to attack even while you are holding/blocking with your own shield"));
    private final BooleanSetting stun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Stun"), true).setDescription(EncryptedString.of("Perform a follow-up double hit immediately after disabling the shield"));
    private final NumberSetting stunTiming = (NumberSetting)new NumberSetting(EncryptedString.of("Stun Timing"), 1.0, 20.0, 2.0, 1.0).setDescription(EncryptedString.of("Ticks to wait between shield break hit and double hit follow-up (2 ticks is optimal & clean)"));
    private final BooleanSetting clickSimulate = (BooleanSetting)new BooleanSetting(EncryptedString.of("Click Simulation"), true).setDescription(EncryptedString.of("Simulates mouse click for CPS counters and mods"));
    private final BooleanSetting requireHoldAxe = (BooleanSetting)new BooleanSetting(EncryptedString.of("Hold Axe"), false).setDescription(EncryptedString.of("Only disable when already holding an axe"));
    private final KeybindSetting activateKey = (KeybindSetting)new KeybindSetting(EncryptedString.of("Activate Key"), -1, false).setDescription(EncryptedString.of("Hold this key to do sword -> axe shield stun. None = always active"));
    private final BooleanSetting swordStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Sword Stun"), true).setDescription(EncryptedString.of("When holding a sword, swap to axe, stun shield, then swap back"));
    private final BooleanSetting manualAxeStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Manual Axe Stun"), true).setDescription(EncryptedString.of("If you manually switch to axe while target shields, hit instantly and stay on axe"));
    private final BooleanSetting automaticStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Automatic Stun"), true).setDescription(EncryptedString.of("Automatically detects shield and swaps to axe from sword/any held item"));
    private final BooleanSetting spearStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Spear Stun"), true).setDescription(EncryptedString.of("When holding a spear, swap to axe, stun shield, then swap back to spear"));
    private final BooleanSetting maceStun = (BooleanSetting)new BooleanSetting(EncryptedString.of("Mace Stun"), true).setDescription(EncryptedString.of("When holding a mace, swap to axe, stun shield, then swap back to mace"));
    private final NumberSetting spearReach = (NumberSetting)new NumberSetting(EncryptedString.of("Spear Reach"), 3.0, 5.0, 3.0, 0.1).setDescription(EncryptedString.of("Detection reach distance for spear stun (max 3.0 for undetectable axe strike)"));

    public static boolean isStunning = false;

    public enum State {
        IDLE,
        SWAP,
        ACTION,
        STUN_WAIT,
        RESTORE,
        COOLDOWN
    }

    private State state = State.IDLE;
    private int returnSlot = -1;
    private int targetAxeSlot = -1;
    private class_1657 currentTarget = null;
    private int stateTicks = 0;
    private int delayTicks = 0;
    private int cooldownTicks = 0;

    public ShieldDisabler() {
        super(EncryptedString.of("Shield Disabler"), EncryptedString.of("Automatically disables your opponents shield with realistic, undetectable axe swap"), -1, Category.COMBAT);
        this.addSettings(
            this.switchDelay,
            this.hitDelay,
            this.cooldown,
            this.switchBack,
            this.checkCooldown,
            this.whileUsingShield,
            this.stun,
            this.stunTiming,
            this.clickSimulate,
            this.requireHoldAxe,
            this.activateKey,
            this.swordStun,
            this.manualAxeStun,
            this.automaticStun,
            this.spearStun,
            this.maceStun,
            this.spearReach
        );
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(AttackListener.class, this);
        this.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(AttackListener.class, this);
        if (this.state != State.IDLE) {
            this.recover("module disabled");
        }
        SwapCoordinator.releaseLock(this);
        this.reset();
        super.onDisable();
    }

    private void reset() {
        this.state = State.IDLE;
        this.returnSlot = -1;
        this.targetAxeSlot = -1;
        this.currentTarget = null;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.cooldownTicks = 0;
        isStunning = false;
    }

    @Override
    public void onTick() {
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
        }

        // Validate basic environment
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null) {
            if (this.state != State.IDLE) {
                this.recover("player, world, or network disconnected");
            }
            return;
        }

        // Validate player alive and no screen open
        if (this.mc.field_1755 != null || !this.mc.field_1724.method_5805() || this.mc.field_1724.method_29504()) {
            if (this.state != State.IDLE) {
                this.recover("screen open or player dead");
            }
            return;
        }

        // Check if local player is blocking with shield (Bug 1 fix)
        if (!this.whileUsingShield.getValue() && this.isPlayerUsingShield()) {
            if (this.state != State.IDLE) {
                this.recover("player using shield");
            }
            return;
        }

        // Timeout guard: never hang on an incomplete state
        if (this.state != State.IDLE && this.state != State.COOLDOWN) {
            ++this.stateTicks;
            if (this.stateTicks > 30) {
                this.recover("operation timeout in " + this.state);
                return;
            }
        }

        // State Machine
        if (this.state == State.COOLDOWN) {
            if (this.cooldownTicks <= 0) {
                this.state = State.IDLE;
            }
            return;
        }

        if (this.state == State.IDLE) {
            isStunning = false;
            class_1657 target = this.getShieldTarget();
            if (target != null) {
                this.tryInitiateStun(target);
                return;
            }
            return;
        }

        // Process active SWAP, ACTION, STUN_WAIT, or RESTORE states
        this.step();
    }

    private boolean tryInitiateStun(class_1657 target) {
        if (this.state != State.IDLE || this.cooldownTicks > 0) return false;
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return false;
        if (!this.whileUsingShield.getValue() && this.isPlayerUsingShield()) return false;
        if (this.isMaceSwapHandlingFall()) return false; // Yield to MaceSwap Stun Slam during falls!

        class_1799 heldStack = this.mc.field_1724.method_6047();
        boolean holdingAxe = ShieldDisabler.isAxe(heldStack);
        boolean holdingSword = ShieldDisabler.isSword(heldStack);
        boolean holdingSpear = WorldUtils.isSpear(heldStack);
        boolean holdingMace = WorldUtils.isMace(heldStack);
        boolean keyActive = this.isActivationPressed();
        boolean hasActivationKey = this.activateKey.getKey() != -1;

        boolean automatic = this.automaticStun.getValue();
        boolean manualInstant = this.manualAxeStun.getValue() && holdingAxe;
        boolean swordKeyStun = this.swordStun.getValue() && holdingSword && (!hasActivationKey || keyActive);
        boolean spearKeyStun = this.spearStun.getValue() && holdingSpear && (!hasActivationKey || keyActive);
        boolean maceKeyStun = this.maceStun.getValue() && holdingMace && (!hasActivationKey || keyActive);
        boolean keySwapStun = hasActivationKey && keyActive;

        boolean shouldStun = manualInstant || swordKeyStun || spearKeyStun || maceKeyStun || automatic || keySwapStun;
        if (this.requireHoldAxe.getValue() && !holdingAxe) {
            return false;
        }
        if (!shouldStun) {
            return false;
        }

        // Case A: Player is ALREADY holding an axe
        if (holdingAxe) {
            if (this.checkCooldown.getValue() && this.mc.field_1724.method_7261(0.5f) < 0.85f) {
                return false; // Wait for attack cooldown on axe
            }
            this.hitShield(target);

            if (this.stun.getValue()) {
                this.currentTarget = target;
                this.returnSlot = -1;
                this.delayTicks = Math.max(1, this.stunTiming.getValueInt());
                this.state = State.STUN_WAIT;
            } else {
                this.cooldownTicks = this.cooldown.getValueInt();
                this.state = State.COOLDOWN;
            }
            return true;
        }

        // Case B: Player is holding Sword / Spear / Other item -> Swap to Axe, Hit 1, [Hit 2], Restore
        if (SwapCoordinator.isLockedByOther(this)) return false;

        int axeSlot = this.findAxeSlot();
        if (axeSlot == -1) return false;

        if (!SwapCoordinator.requestLock(this)) {
            return false;
        }

        this.returnSlot = this.mc.field_1724.method_31548().method_67532();
        this.targetAxeSlot = axeSlot;
        this.currentTarget = target;
        this.stateTicks = 0;

        // Equip axe
        this.setSlotAndSync(this.targetAxeSlot);

        int sDelay = this.switchDelay.getValueInt();
        if (sDelay > 0) {
            this.delayTicks = sDelay;
            this.state = State.SWAP;
        } else {
            this.state = State.ACTION;
            this.step();
        }
        return true;
    }

    private void step() {
        switch (this.state) {
            case IDLE:
            case COOLDOWN: {
                break;
            }

            case SWAP: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                // Verify axe is still held in hotbar
                int active = this.mc.field_1724.method_31548().method_67532();
                if (active != this.targetAxeSlot) {
                    this.setSlotAndSync(this.targetAxeSlot);
                }

                this.state = State.ACTION;
                this.stateTicks = 0;
                // Fallthrough to ACTION
            }

            case ACTION: {
                if (this.currentTarget == null || !this.currentTarget.method_5805() || this.currentTarget.method_29504()) {
                    this.recover("target invalid or dead during action");
                    return;
                }

                // Hit 1: Break / Stun Shield with Axe
                this.hitShield(this.currentTarget);
                this.stateTicks = 0;

                if (this.stun.getValue()) {
                    // Double Hit: wait stunTiming ticks before Hit 2
                    this.delayTicks = Math.max(1, this.stunTiming.getValueInt());
                    this.state = State.STUN_WAIT;
                } else if (this.switchBack.getValue() && this.returnSlot >= 0) {
                    // Hold axe for hitDelay ticks so swing animation renders visibly
                    this.delayTicks = Math.max(1, this.hitDelay.getValueInt());
                    this.state = State.RESTORE;
                } else {
                    this.finish();
                }
                break;
            }

            case STUN_WAIT: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                // Execute Hit 2: axe follow-up double hit on unshielded target
                if (this.currentTarget != null && this.currentTarget.method_5805() && !this.currentTarget.method_29504()) {
                    this.hitShield(this.currentTarget);
                }

                this.stateTicks = 0;
                if (this.switchBack.getValue() && this.returnSlot >= 0) {
                    this.delayTicks = Math.max(1, this.hitDelay.getValueInt());
                    this.state = State.RESTORE;
                } else {
                    this.finish();
                }
                break;
            }

            case RESTORE: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                if (this.returnSlot >= 0) {
                    int restore = this.getCleanReturnSlot();
                    this.setSlotAndSync(restore);
                }
                this.finish();
                break;
            }
        }
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return;
        if (this.mc.field_1755 != null) return;

        // Block overlapping attacks while a swap stun sequence is in progress
        if (this.state == State.SWAP || this.state == State.ACTION || this.state == State.STUN_WAIT || this.state == State.RESTORE) {
            event.cancel();
            return;
        }

        if (this.state != State.IDLE || this.cooldownTicks > 0) return;
        if (!this.whileUsingShield.getValue() && this.isPlayerUsingShield()) return;
        if (this.isMaceSwapHandlingFall()) return; // Yield to MaceSwap Stun Slam during falls!

        // Intercept attacks on shielding players so sword/spear doesn't uselessly bounce off shield
        class_1297 attacked = null;
        if (this.mc.field_1765 instanceof class_3966) {
            attacked = ((class_3966)this.mc.field_1765).method_17782();
        }
        if (attacked == null) {
            attacked = this.getShieldTarget();
        }
        if (attacked instanceof class_1657 && this.isValidShieldTarget((class_1657)attacked)) {
            if (this.tryInitiateStun((class_1657)attacked)) {
                event.cancel();
            }
        }
    }

    private void hitShield(class_1657 player) {
        if (player == null || this.mc == null || this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }
        isStunning = true;
        // 1. Attack entity directly (vanilla attackEntity handles packet & internal cooldown reset)
        this.mc.field_1761.method_2918(this.mc.field_1724, (class_1297)player);
        // 2. Swing main hand with full swing animation
        this.mc.field_1724.method_6104(class_1268.field_5808);
        // 3. CPS pulse / keystroke simulation
        if (this.clickSimulate.getValue()) {
            MouseSimulation.mouseClick(0);
        }
    }

    private void finish() {
        SwapCoordinator.releaseLock(this);
        this.cooldownTicks = this.cooldown.getValueInt();
        this.returnSlot = -1;
        this.targetAxeSlot = -1;
        this.currentTarget = null;
        this.stateTicks = 0;
        this.delayTicks = 0;
        isStunning = false;
        this.state = State.COOLDOWN;
    }

    private void recover(String reason) {
        if (this.returnSlot >= 0 && this.returnSlot < 9 && this.mc != null && this.mc.field_1724 != null) {
            this.setSlotAndSync(this.returnSlot);
        }
        SwapCoordinator.releaseLock(this);
        this.returnSlot = -1;
        this.targetAxeSlot = -1;
        this.currentTarget = null;
        this.stateTicks = 0;
        this.delayTicks = 0;
        isStunning = false;
        this.state = State.IDLE;
    }

    private boolean isPlayerUsingShield() {
        if (this.mc == null || this.mc.field_1724 == null) return false;
        class_1657 player = this.mc.field_1724;
        if (!player.method_6039()) { // isUsingItem()
            return false;
        }
        return (player.method_6079() != null && player.method_6079().method_7909() == class_1802.field_8255)
            || (player.method_6047() != null && player.method_6047().method_7909() == class_1802.field_8255);
    }

    private class_1657 getShieldTarget() {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return null;
        }

        // 1. Crosshair targeted entity (vanilla raycast)
        class_239 hitResult = this.mc.field_1765;
        if (hitResult instanceof class_3966) {
            class_1297 ent = ((class_3966)hitResult).method_17782();
            if (ent instanceof class_1657 && this.isValidShieldTarget((class_1657)ent)) {
                return (class_1657)ent;
            }
        }

        // 2. Direct melee raycast up to legal axe reach (3.2 blocks)
        class_1297 inReach = WorldUtils.getEntityInReach(3.2);
        if (inReach instanceof class_1657 && this.isValidShieldTarget((class_1657)inReach)) {
            return (class_1657)inReach;
        }

        // 3. Scan nearby players who are blocking with shield in line of sight (closest first)
        class_1657 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1657 player : this.mc.field_1687.method_18456()) {
            if (player != this.mc.field_1724 && this.isValidShieldTarget(player)) {
                double d = this.mc.field_1724.method_5858((class_1297)player);
                if (d < bestDist) {
                    bestDist = d;
                    best = player;
                }
            }
        }

        return best;
    }

    private boolean isValidShieldTarget(class_1657 player) {
        if (player == null || this.mc == null || this.mc.field_1724 == null) return false;
        if (player == this.mc.field_1724) return false;
        if (!player.method_5805() || player.method_29504()) return false;

        try {
            Friends friends = Argon.INSTANCE.getModuleManager().getModule(Friends.class);
            if (friends != null && friends.isEnabled() && Argon.INSTANCE.getFriendManager().isFriend(player)) {
                return false;
            }
        } catch (Throwable ignored) {}

        class_243 eyePos = this.mc.field_1724.method_33571();
        double eyeDistSq = eyePos.method_1025(player.method_33571());
        double feetDistSq = this.mc.field_1724.method_5858((class_1297)player);
        double distSq = Math.min(eyeDistSq, feetDistSq);
        if (distSq > 10.24) { // 3.2 blocks max reach
            return false;
        }

        if (!ShieldDisabler.isBlockingWithShield(player)) return false;

        // Line of sight check using vanilla canSee
        if (!this.mc.field_1724.method_6057(player)) {
            return false;
        }

        // Must be in front of player (FOV check)
        class_243 dir = this.mc.field_1724.method_5828(1.0f);
        class_243 toEntity = player.method_5829().method_1005().method_1020(eyePos).method_1029();
        if (dir.method_1026(toEntity) < 0.40) {
            return false;
        }

        return true;
    }

    public boolean isSpearReachActive() {
        return false;
    }

    public double getSpearReach() {
        return 3.0;
    }

    private boolean isValidDoubleHitTarget(class_1657 player) {
        if (player == null || this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return false;
        if (player == this.mc.field_1724) return false;
        if (!player.method_5805() || player.method_29504()) return false;

        try {
            Friends friends = Argon.INSTANCE.getModuleManager().getModule(Friends.class);
            if (friends != null && friends.isEnabled() && Argon.INSTANCE.getFriendManager().isFriend(player)) {
                return false;
            }
        } catch (Throwable ignored) {}

        class_243 eyePos = this.mc.field_1724.method_33571();
        double eyeDistSq = eyePos.method_1025(player.method_33571());
        double feetDistSq = this.mc.field_1724.method_5858((class_1297)player);
        double distSq = Math.min(eyeDistSq, feetDistSq);
        if (distSq > 10.24) {
            return false;
        }

        if (!this.mc.field_1724.method_6057(player)) {
            return false;
        }

        class_243 dir = this.mc.field_1724.method_5828(1.0f);
        class_243 toEntity = player.method_5829().method_1005().method_1020(eyePos).method_1029();
        if (dir.method_1026(toEntity) < 0.40) {
            return false;
        }

        return true;
    }

    private static boolean isBlockingWithShield(class_1657 player) {
        try {
            if (player == null || !player.method_5805()) return false;
            if (player.method_6039()) {
                class_1799 active = player.method_6030();
                if (isShield(active)) return true;
                if (isShield(player.method_6079()) || isShield(player.method_6047())) return true;
            }
            return false;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isShield(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (stack.method_7909() == class_1802.field_8255) return true;
        try {
            String name = stack.method_7909().toString().toLowerCase();
            return name.contains("shield");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isActivationPressed() {
        try {
            int key = this.activateKey.getKey();
            return key == -1 || KeyUtils.isKeyPressed(key);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private int findAxeSlot() {
        if (this.mc.field_1724 == null) return -1;
        class_1661 inv = this.mc.field_1724.method_31548();
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (ShieldDisabler.isAxe(stack)) {
                return i;
            }
        }
        return -1;
    }

    private int getCleanReturnSlot() {
        if (this.mc == null || this.mc.field_1724 == null) return 0;
        if (this.returnSlot >= 0 && this.returnSlot < 9) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(this.returnSlot);
            if (!ShieldDisabler.isAxe(stack)) {
                return this.returnSlot;
            }
        }
        int sword = InventoryUtils.getSwordSlot();
        if (sword != -1) return sword;
        int mace = this.findMaceSlot();
        if (mace != -1) return mace;
        int current = this.mc.field_1724.method_31548().method_67532();
        return (current >= 0 && current < 9) ? current : 0;
    }

    private int findMaceSlot() {
        if (this.mc.field_1724 == null) return -1;
        class_1661 inv = this.mc.field_1724.method_31548();
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (WorldUtils.isMace(stack)) {
                return i;
            }
        }
        return -1;
    }

    private void setSlotAndSync(int slot) {
        if (slot >= 0 && slot <= 8 && this.mc.field_1724 != null) {
            this.mc.field_1724.method_31548().method_61496(slot);
            this.syncSelectedSlot();
        }
    }

    private void syncSelectedSlot() {
        try {
            if (this.mc.field_1761 != null) {
                ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
            }
        } catch (Throwable ignored) {}
    }

    private static boolean isSword(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && WorldUtils.isSword(stack);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isAxe(class_1799 stack) {
        try {
            return stack != null && !stack.method_7960() && WorldUtils.isAxe(stack);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isMaceSwapHandlingFall() {
        try {
            MaceSwap maceSwap = Argon.INSTANCE.getModuleManager().getModule(MaceSwap.class);
            if (maceSwap != null && maceSwap.shouldHandleShieldStun()) {
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }
}
