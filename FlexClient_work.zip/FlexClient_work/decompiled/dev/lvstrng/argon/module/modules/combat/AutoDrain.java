/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1657
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3610
 *  net.minecraft.class_3611
 *  net.minecraft.class_3612
 *  net.minecraft.class_3965
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.ItemUseListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3965;

public final class AutoDrain
extends Module
implements TickListener,
ItemUseListener {
    private final BooleanSetting onlyBucket = (BooleanSetting)new BooleanSetting(EncryptedString.of("Only Bucket"), false).setDescription(EncryptedString.of("Only drain with empty bucket. Other methods disabled."));
    private final BooleanSetting onlyWebString = (BooleanSetting)new BooleanSetting(EncryptedString.of("Only Web/String"), false).setDescription(EncryptedString.of("Only drain by placing cobweb/string. Blocks disabled unless both filters are off."));
    private final BooleanSetting autoSwap = (BooleanSetting)new BooleanSetting(EncryptedString.of("Auto Swap"), false).setDescription(EncryptedString.of("Swap to bucket first, else cobweb/string/block when aiming at enemy lava/water"));
    private final BooleanSetting switchBack = (BooleanSetting)new BooleanSetting(EncryptedString.of("Switch Back"), true).setDescription(EncryptedString.of("Return to previous slot after Auto Swap drains"));
    private final NumberSetting enemyRange = (NumberSetting)new NumberSetting(EncryptedString.of("Enemy Range"), 1.0, 8.0, 5.0, 0.5).setDescription(EncryptedString.of("Requires another player near the lava/water so your own utility is not drained"));
    private final NumberSetting delay = (NumberSetting)new NumberSetting(EncryptedString.of("Delay"), 0.0, 10.0, 2.0, 1.0).setDescription(EncryptedString.of("Ticks between drain attempts"));
    private final BooleanSetting protectOwn = (BooleanSetting)new BooleanSetting(EncryptedString.of("Protect Own"), true).setDescription(EncryptedString.of("Do not drain lava/water that you placed yourself"));
    private int cooldown = 0;
    private int previousSlot = -1;
    private final Set<class_2338> ownedFluids = new HashSet<class_2338>();

    public AutoDrain() {
        super(EncryptedString.of("Auto Drain"), EncryptedString.of("Drains enemy placed lava/water with bucket, cobweb/string or blocks"), -1, Category.COMBAT);
        this.addSettings(this.onlyBucket, this.onlyWebString, this.autoSwap, this.switchBack, this.protectOwn, this.enemyRange, this.delay);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(ItemUseListener.class, this);
        this.cooldown = 0;
        this.previousSlot = -1;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(ItemUseListener.class, this);
        this.cooldown = 0;
        this.previousSlot = -1;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null && this.mc.field_1755 == null) {
            if (this.cooldown > 0) {
                --this.cooldown;
            } else {
                class_3965 hit = this.getBlockHit();
                if (hit != null) {
                    class_2338 fluidPos = this.findDrainableFluidPos(hit);
                    this.pruneOwnedFluidMarks();
                    if (fluidPos != null && !this.isOwnBodyFluid(fluidPos) && !this.isOwnPlacedFluid(fluidPos) && this.hasEnemyNear(fluidPos)) {
                        int selectedSlot = this.mc.field_1724.method_31548().method_67532();
                        class_1799 held = this.mc.field_1724.method_6047();
                        DrainTool heldTool = AutoDrain.getTool(held);
                        boolean used = false;
                        if (this.autoSwap.getValue()) {
                            int toolSlot;
                            if (this.previousSlot == -1) {
                                this.previousSlot = selectedSlot;
                            }
                            if ((toolSlot = this.findBestToolSlot(fluidPos)) == -1) {
                                this.previousSlot = -1;
                                return;
                            }
                            this.setSlot(toolSlot);
                            used = this.drain(fluidPos, hit, AutoDrain.getTool(this.mc.field_1724.method_6047()));
                            if (used && this.switchBack.getValue() && this.previousSlot != -1) {
                                this.setSlot(this.previousSlot);
                            }
                            this.previousSlot = -1;
                        } else if (this.isAllowedTool(heldTool, fluidPos)) {
                            used = this.drain(fluidPos, hit, heldTool);
                        }
                        if (used) {
                            this.cooldown = this.delay.getValueInt();
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onItemUse(ItemUseListener.ItemUseEvent event) {
        class_3965 hit;
        if (this.mc != null && this.mc.field_1724 != null && this.mc.field_1687 != null && (hit = this.getBlockHit()) != null && hit.method_17783() == class_239.class_240.field_1332) {
            class_1799 stack = this.mc.field_1724.method_6047();
            if (!AutoDrain.isFluidBucket(stack)) {
                stack = this.mc.field_1724.method_6079();
            }
            if (AutoDrain.isFluidBucket(stack)) {
                class_2338 clicked = hit.method_17777();
                this.ownedFluids.add(clicked);
                class_2350 side = hit.method_17780();
                if (side != null) {
                    this.ownedFluids.add(clicked.method_10093(side));
                }
            }
        }
    }

    private class_3965 getBlockHit() {
        class_239 target = this.mc.field_1765;
        return target instanceof class_3965 ? (class_3965)target : null;
    }

    private class_2338 findDrainableFluidPos(class_3965 hit) {
        class_2338 offset;
        class_2338 pos = hit.method_17777();
        if (this.isDrainableFluid(pos)) {
            return pos;
        }
        class_2350 side = hit.method_17780();
        if (side != null && this.isDrainableFluid(offset = pos.method_10093(side))) {
            return offset;
        }
        class_2338 up = pos.method_10084();
        return this.isDrainableFluid(up) ? up : null;
    }

    private boolean isDrainableFluid(class_2338 pos) {
        try {
            class_3610 fluid = this.mc.field_1687.method_8316(pos);
            return fluid != null && !fluid.method_15769() && (fluid.method_39360((class_3611)class_3612.field_15910) || fluid.method_39360((class_3611)class_3612.field_15908));
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isStillFluid(class_2338 pos) {
        try {
            class_3610 fluid = this.mc.field_1687.method_8316(pos);
            return fluid != null && fluid.method_15771();
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isOwnPlacedFluid(class_2338 fluidPos) {
        return this.protectOwn.getValue() && this.ownedFluids.contains(fluidPos);
    }

    private void pruneOwnedFluidMarks() {
        try {
            this.ownedFluids.removeIf(pos -> !this.isDrainableFluid((class_2338)pos));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean hasEnemyNear(class_2338 fluidPos) {
        try {
            class_243 fluidCenter = AutoDrain.center(fluidPos);
            double rangeSq = this.enemyRange.getValue() * this.enemyRange.getValue();
            for (class_1657 player : this.mc.field_1687.method_18456()) {
                if (player == null || player == this.mc.field_1724 || !player.method_5805() || !(player.method_33571().method_1025(fluidCenter) <= rangeSq)) continue;
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private boolean isOwnBodyFluid(class_2338 fluidPos) {
        try {
            class_2338 self = this.mc.field_1724.method_24515();
            return fluidPos.equals((Object)self) || fluidPos.equals((Object)self.method_10084());
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private int findBestToolSlot(class_2338 fluidPos) {
        int bucket = this.findSlot(DrainTool.BUCKET, fluidPos);
        if (bucket != -1) {
            return bucket;
        }
        int webString = this.findSlot(DrainTool.WEB_STRING, fluidPos);
        return webString != -1 ? webString : this.findSlot(DrainTool.BLOCK, fluidPos);
    }

    private int findSlot(DrainTool wanted, class_2338 fluidPos) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            DrainTool tool = AutoDrain.getTool(stack);
            if (tool != wanted || !this.isAllowedTool(tool, fluidPos)) continue;
            return i;
        }
        return -1;
    }

    private boolean drain(class_2338 fluidPos, class_3965 originalHit, DrainTool tool) {
        if (tool != DrainTool.NONE && this.isAllowedTool(tool, fluidPos)) {
            class_3965 fluidHit = this.makeFluidHit(fluidPos, originalHit);
            try {
                class_1269 result;
                if (tool == DrainTool.BUCKET) {
                    result = this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, fluidHit);
                    if (result == null || !result.method_23665()) {
                        result = this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
                    }
                } else {
                    result = this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, fluidHit);
                }
                if (result != null && result.method_23665()) {
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                    return true;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return false;
        }
        return false;
    }

    private class_3965 makeFluidHit(class_2338 fluidPos, class_3965 originalHit) {
        class_2350 side = originalHit.method_17780() == null ? class_2350.field_11036 : originalHit.method_17780();
        return new class_3965(AutoDrain.center(fluidPos), side, fluidPos, false);
    }

    private boolean isAllowedTool(DrainTool tool, class_2338 fluidPos) {
        boolean bucketFilter = this.onlyBucket.getValue();
        boolean webFilter = this.onlyWebString.getValue();
        if (tool == DrainTool.NONE) {
            return false;
        }
        if (tool == DrainTool.BUCKET && !this.isStillFluid(fluidPos)) {
            return false;
        }
        if (!bucketFilter && !webFilter) {
            return true;
        }
        return bucketFilter && tool == DrainTool.BUCKET ? true : webFilter && tool == DrainTool.WEB_STRING;
    }

    private static boolean isFluidBucket(class_1799 stack) {
        try {
            if (stack != null && !stack.method_7960()) {
                class_1792 item = stack.method_7909();
                return item == class_1802.field_8705 || item == class_1802.field_8187;
            }
            return false;
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static DrainTool getTool(class_1799 stack) {
        try {
            if (stack == null || stack.method_7960()) {
                return DrainTool.NONE;
            }
            class_1792 item = stack.method_7909();
            if (item == class_1802.field_8550) {
                return DrainTool.BUCKET;
            }
            if (item == class_1802.field_8786 || item == class_1802.field_8276) {
                return DrainTool.WEB_STRING;
            }
            if (item instanceof class_1747) {
                return DrainTool.BLOCK;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return DrainTool.NONE;
    }

    private void setSlot(int slot) {
        if (slot >= 0 && slot <= 8) {
            this.mc.field_1724.method_31548().method_61496(slot);
            try {
                ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static class_243 center(class_2338 pos) {
        return new class_243((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5);
    }

    private static enum DrainTool {
        NONE,
        BUCKET,
        WEB_STRING,
        BLOCK;

    }
}

