/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.module.modules.misc;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;

public final class NoHitDelay
extends Module {
    public final NumberSetting delay = (NumberSetting)new NumberSetting(EncryptedString.of("Delay (Ticks)"), 0.0, 20.0, 0.0, 1.0).setDescription(EncryptedString.of("Fake cooldown ticks to report. 0 = no delay, 20 = vanilla"));
    public final BooleanSetting weaponsOnly = (BooleanSetting)new BooleanSetting(EncryptedString.of("Weapons Only"), false).setDescription(EncryptedString.of("Only remove hit delay when holding a sword or axe"));
    public final BooleanSetting onlyOnGround = (BooleanSetting)new BooleanSetting(EncryptedString.of("Only On Ground"), false).setDescription(EncryptedString.of("Only remove hit delay when standing on the ground"));

    public NoHitDelay() {
        super(EncryptedString.of("No Hit Delay (Soon)"), EncryptedString.of("Removes the attack cooldown (Temporarily disabled for bug fix)"), -1, Category.MISC);
        this.addSettings(this.delay, this.weaponsOnly, this.onlyOnGround);
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}

