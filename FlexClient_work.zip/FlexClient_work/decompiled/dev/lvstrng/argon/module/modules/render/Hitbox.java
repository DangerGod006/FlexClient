/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_4184
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.hitbox.EffectiveAttackHitbox;
import dev.lvstrng.argon.hitbox.EffectiveAttackHitboxProvider;
import dev.lvstrng.argon.hitbox.VisualizationContext;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.combat.AttackHitbox;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.WorldUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public final class Hitbox
extends Module
implements GameRenderListener {
    private final BooleanSetting showAttackHitbox = (BooleanSetting)new BooleanSetting(EncryptedString.of("Show Attack Hitbox"), true).setDescription(EncryptedString.of("Draw the effective attack hitbox. Off hides only the overlay, the size itself is untouched"));
    private final BooleanSetting useAttackHitboxForRendering = (BooleanSetting)new BooleanSetting(EncryptedString.of("Use Attack Hitbox For Rendering"), true).setDescription(EncryptedString.of("ON: the drawn box uses the effective Attack Hitbox bounds. OFF: the normal entity box is shown. Combat is unaffected either way"));
    private final BooleanSetting showAttackHitboxInDebugHitbox = (BooleanSetting)new BooleanSetting(EncryptedString.of("Show Attack Hitbox In Debug Hitbox"), true).setDescription(EncryptedString.of("ON: F3+B itself draws the effective Attack Hitbox. OFF: F3+B shows the normal Minecraft box"));
    private final BooleanSetting debugHitboxLogging = (BooleanSetting)new BooleanSetting(EncryptedString.of("Debug Hitbox Logging"), false).setDescription(EncryptedString.of("Log the bounds handed to the F3+B debug renderer, at most once a second"));
    private final BooleanSetting showVanillaHitbox = (BooleanSetting)new BooleanSetting(EncryptedString.of("Show Vanilla Hitbox"), false).setDescription(EncryptedString.of("Also draw the normal Minecraft box, the same shape F3+B shows"));
    private final BooleanSetting throughWalls = (BooleanSetting)new BooleanSetting(EncryptedString.of("Render Through Walls"), false).setDescription(EncryptedString.of("Drawing only - show boxes through terrain. Never affects targeting"));
    private final NumberSetting renderRange = (NumberSetting)new NumberSetting(EncryptedString.of("Render Range"), 8.0, 128.0, 64.0, 1.0).setDescription(EncryptedString.of("Only entities within this many blocks are considered for drawing"));
    private final ModeSetting<Target> target = new ModeSetting<Target>(EncryptedString.of("Target"), Target.Players, Target.class);
    private final BooleanSetting filled = (BooleanSetting)new BooleanSetting(EncryptedString.of("Filled"), true).setDescription(EncryptedString.of("Draw a translucent fill inside the box"));
    private final BooleanSetting outline = (BooleanSetting)new BooleanSetting(EncryptedString.of("Outline"), true).setDescription(EncryptedString.of("Draw the box outline"));
    private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 70.0, 1.0);
    private final NumberSetting width = new NumberSetting(EncryptedString.of("Line Width"), 1.0, 5.0, 1.0, 1.0);
    private final Map<class_1297, Boolean> visibilityCache = new HashMap<class_1297, Boolean>();
    private final List<EffectiveAttackHitbox> frame = new ArrayList<EffectiveAttackHitbox>();
    private final List<class_238> attackBatch = new ArrayList<class_238>();
    private final List<class_238> vanillaBatch = new ArrayList<class_238>();

    public Hitbox() {
        super(EncryptedString.of("Hitbox"), EncryptedString.of("Draws the attack hitbox | visualises the combat bounds"), -1, Category.RENDER);
        this.addSettings(this.showAttackHitbox, this.useAttackHitboxForRendering, this.showAttackHitboxInDebugHitbox, this.debugHitboxLogging, this.showVanillaHitbox, this.throughWalls, this.renderRange, this.target, this.filled, this.outline, this.alpha, this.width);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(GameRenderListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(GameRenderListener.class, this);
        this.visibilityCache.clear();
        this.frame.clear();
        super.onDisable();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        boolean drawAttack = this.showAttackHitbox.getValue() && AttackHitbox.isActive();
        boolean drawVanilla = this.showVanillaHitbox.getValue();
        if (!drawAttack && !drawVanilla) {
            return;
        }
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        class_4184 camera = this.mc.field_1773.method_19418();
        if (camera == null) {
            return;
        }
        boolean drawFill = this.filled.getValue();
        boolean drawOutline = this.outline.getValue();
        if (!drawFill && !drawOutline) {
            return;
        }
        float tickDelta = event.delta;
        boolean checkWalls = !this.throughWalls.getValue();
        double rangeSquared = this.renderRange.getValue() * this.renderRange.getValue();
        float lineWidth = Math.max(1.0f, (float)this.width.getValue());
        boolean useEffective = this.useAttackHitboxForRendering.getValue();
        boolean sameBounds = EffectiveAttackHitboxProvider.expansion() == 0.0;
        boolean drawVanillaLayer = drawVanilla && useEffective && (!sameBounds || !useEffective);
        this.visibilityCache.clear();
        this.frame.clear();
        for (Object entity : this.mc.field_1687.method_18112()) {
            EffectiveAttackHitbox hitbox;
            if (!this.matches((class_1297)entity, rangeSquared) || (hitbox = EffectiveAttackHitboxProvider.of((class_1297)entity, tickDelta)) == null || checkWalls && !this.isVisible((class_1297)entity, hitbox.vanilla().method_1005())) continue;
            this.frame.add(hitbox);
        }
        if (this.frame.isEmpty()) {
            return;
        }
        class_243 cameraPos = camera.method_71156();
        event.matrices.method_22903();
        try {
            boolean handled;
            event.matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(camera.method_19329()));
            event.matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            event.matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            if (drawVanillaLayer) {
                this.vanillaBatch.clear();
                for (EffectiveAttackHitbox hitbox : this.frame) {
                    this.vanillaBatch.add(hitbox.vanilla());
                }
                Color color = new Color(255, 255, 255, this.alpha.getValueInt());
                if (drawFill) {
                    RenderUtils.renderFilledBoxes(event.matrices, this.vanillaBatch, color);
                }
                if (drawOutline) {
                    RenderUtils.renderBoxOutlines(event.matrices, this.vanillaBatch, new Color(255, 255, 255, 255), lineWidth);
                }
            }
            if (drawAttack && !(handled = EffectiveAttackHitboxProvider.dispatch(new VisualizationContext(event.matrices, this.frame, tickDelta, useEffective)))) {
                this.attackBatch.clear();
                for (EffectiveAttackHitbox hitbox : this.frame) {
                    this.attackBatch.add(EffectiveAttackHitboxProvider.boundsForVisualization(hitbox, useEffective));
                }
                if (drawFill) {
                    RenderUtils.renderFilledBoxes(event.matrices, this.attackBatch, RenderUtils.accentColor(this.alpha.getValueInt()));
                }
                if (drawOutline) {
                    RenderUtils.renderBoxOutlines(event.matrices, this.attackBatch, RenderUtils.accentColor(255), lineWidth);
                }
            }
        }
        finally {
            event.matrices.method_22909();
        }
    }

    private boolean isVisible(class_1297 entity, class_243 point) {
        Boolean cached = this.visibilityCache.get(entity);
        if (cached != null) {
            return cached;
        }
        boolean visible = WorldUtils.hasLineOfSight(point);
        this.visibilityCache.put(entity, visible);
        return visible;
    }

    public boolean isShowAttackHitboxInDebugHitbox() {
        return this.showAttackHitboxInDebugHitbox.getValue();
    }

    public boolean isDebugHitboxLogging() {
        return this.debugHitboxLogging.getValue();
    }

    private boolean matches(class_1297 entity, double rangeSquared) {
        if (entity == null || entity == this.mc.field_1724 || entity.method_31481() || !entity.method_5805()) {
            return false;
        }
        if (!(entity instanceof class_1309) || entity.method_7325()) {
            return false;
        }
        if (entity.method_5858((class_1297)this.mc.field_1724) > rangeSquared) {
            return false;
        }
        boolean isPlayer = entity instanceof class_1657;
        return switch (this.target.getMode().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> isPlayer;
            case 1 -> {
                if (!isPlayer) {
                    yield true;
                }
                yield false;
            }
            case 2 -> true;
        };
    }

    public static enum Target {
        Players,
        Mobs,
        All;

    }
}

