/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1802
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  org.lwjgl.glfw.GLFW
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.PlayerTickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class MaceAssist
extends Module
implements PlayerTickListener {
    private final NumberSetting activationHeight = (NumberSetting)new NumberSetting(EncryptedString.of("Activation Height"), 0.5, 5.0, 2.5, 0.1).setDescription(EncryptedString.of("Max distance to ground to trigger mace smash"));
    private final NumberSetting targetRange = (NumberSetting)new NumberSetting(EncryptedString.of("Target Range"), 3.0, 15.0, 8.0, 0.5).setDescription(EncryptedString.of("Max range to find a target"));
    private final BooleanSetting attackMobs = (BooleanSetting)new BooleanSetting(EncryptedString.of("Attack Mobs"), true).setDescription(EncryptedString.of("Also target mobs, not just players"));
    private final BooleanSetting requireHoldMace = (BooleanSetting)new BooleanSetting(EncryptedString.of("Require Mace"), true).setDescription(EncryptedString.of("Only activate when mace is in main hand"));
    private final BooleanSetting requireClick = (BooleanSetting)new BooleanSetting(EncryptedString.of("Require Click"), false).setDescription(EncryptedString.of("Only trigger when holding left click"));
    private boolean hasAttacked = false;

    public MaceAssist() {
        super(EncryptedString.of("Mace Assist"), EncryptedString.of("Automatically aims and times your mace smash attack"), -1, Category.COMBAT);
        this.addSettings(this.activationHeight, this.targetRange, this.attackMobs, this.requireHoldMace, this.requireClick);
    }

    @Override
    public void onEnable() {
        this.eventManager.add(PlayerTickListener.class, this);
        this.hasAttacked = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(PlayerTickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onPlayerTick() {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
            class_1309 target;
            double distToGround;
            if (this.mc.field_1724.method_24828() || this.mc.field_1724.method_5799()) {
                this.hasAttacked = false;
            } else if (!(this.hasAttacked || this.requireHoldMace.getValue() && !this.mc.field_1724.method_6047().method_31574(class_1802.field_49814) || this.mc.field_1724.method_18798().field_1351 >= 0.0 || this.requireClick.getValue() && GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), (int)0) != 1 || (distToGround = this.getDistanceToGround()) < 0.0 || distToGround > this.activationHeight.getValue() || (target = this.findTarget()) == null)) {
                this.rotateTowards(target);
                this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, (class_1297)target);
                this.mc.field_1724.method_6104(class_1268.field_5808);
                this.hasAttacked = true;
            }
        }
    }

    private class_1309 findTarget() {
        List<class_1309> entities = this.attackMobs.getValue() ? this.mc.field_1687.method_8390(class_1309.class, this.mc.field_1724.method_5829().method_1014(this.targetRange.getValue()), this::isValid) : this.mc.field_1687.method_8390(class_1657.class, this.mc.field_1724.method_5829().method_1014(this.targetRange.getValue()), this::isValid).stream().map(e -> e).toList();
        return entities.stream().min(Comparator.comparingDouble(e -> this.mc.field_1724.method_5858((class_1297)e))).orElse(null);
    }

    private boolean isValid(class_1309 e) {
        if (e == this.mc.field_1724) {
            return false;
        }
        if (e.method_5805() && !e.method_7325()) {
            class_1657 p;
            if (this.mc.field_1724.method_5739((class_1297)e) > this.targetRange.getValueFloat()) {
                return false;
            }
            return !this.attackMobs.getValue() && !(e instanceof class_1657) ? false : !(e instanceof class_1657) || !(p = (class_1657)e).method_68878() && !p.method_7325();
        }
        return false;
    }

    private void rotateTowards(class_1309 target) {
        class_243 aimPos = target.method_73189().method_1031(0.0, (double)target.method_17682() * 0.5, 0.0);
        class_243 camera = this.mc.field_1724.method_5836(1.0f);
        double dX = aimPos.field_1352 - camera.field_1352;
        double dY = aimPos.field_1351 - camera.field_1351;
        double dZ = aimPos.field_1350 - camera.field_1350;
        float yaw = (float)Math.toDegrees(Math.atan2(dZ, dX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(dY, Math.sqrt(dX * dX + dZ * dZ))));
        this.mc.field_1724.method_36456(yaw);
        this.mc.field_1724.method_36457(class_3532.method_15363((float)pitch, (float)-89.0f, (float)89.0f));
    }

    private double getDistanceToGround() {
        class_243 pos = this.mc.field_1724.method_73189();
        class_3965 hit = this.mc.field_1687.method_17742(new class_3959(pos, new class_243(pos.field_1352, pos.field_1351 - 256.0, pos.field_1350), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)this.mc.field_1724));
        return hit == null ? -1.0 : pos.field_1351 - hit.method_17784().field_1351;
    }
}

