/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.utils.EncryptedString;

public final class Xray
extends Module {
    public final BooleanSetting diamonds = new BooleanSetting(EncryptedString.of("Diamonds"), true);
    public final BooleanSetting ancientDebris = new BooleanSetting(EncryptedString.of("Ancient Debris"), true);
    public final BooleanSetting gold = new BooleanSetting(EncryptedString.of("Gold Ore"), true);
    public final BooleanSetting iron = new BooleanSetting(EncryptedString.of("Iron Ore"), true);
    public final BooleanSetting emerald = new BooleanSetting(EncryptedString.of("Emerald Ore"), true);
    public final BooleanSetting lapis = new BooleanSetting(EncryptedString.of("Lapis Ore"), true);
    public final BooleanSetting redstone = new BooleanSetting(EncryptedString.of("Redstone Ore"), true);
    public final BooleanSetting coal = new BooleanSetting(EncryptedString.of("Coal Ore"), false);
    public final BooleanSetting copper = new BooleanSetting(EncryptedString.of("Copper Ore"), false);
    public final BooleanSetting chest = new BooleanSetting(EncryptedString.of("Chests"), true);
    public final BooleanSetting spawner = new BooleanSetting(EncryptedString.of("Spawners"), true);

    public Xray() {
        super(EncryptedString.of("Xray"), EncryptedString.of("Only renders ores, chests, and spawners through walls"), -1, Category.RENDER);
        this.addSettings(this.diamonds, this.ancientDebris, this.gold, this.iron, this.emerald, this.lapis, this.redstone, this.coal, this.copper, this.chest, this.spawner);
    }

    @Override
    public void onEnable() {
        this.reloadChunks();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.reloadChunks();
        super.onDisable();
    }

    public boolean isVisible(String blockId) {
        if (blockId.contains("diamond_ore")) {
            return this.diamonds.getValue();
        }
        if (blockId.contains("ancient_debris")) {
            return this.ancientDebris.getValue();
        }
        if (blockId.contains("gold_ore")) {
            return this.gold.getValue();
        }
        if (blockId.contains("iron_ore")) {
            return this.iron.getValue();
        }
        if (blockId.contains("emerald_ore")) {
            return this.emerald.getValue();
        }
        if (blockId.contains("lapis_ore")) {
            return this.lapis.getValue();
        }
        if (blockId.contains("redstone_ore")) {
            return this.redstone.getValue();
        }
        if (blockId.contains("coal_ore")) {
            return this.coal.getValue();
        }
        if (blockId.contains("copper_ore")) {
            return this.copper.getValue();
        }
        if (blockId.contains("chest")) {
            return this.chest.getValue();
        }
        return blockId.contains("spawner") ? this.spawner.getValue() : false;
    }

    private void reloadChunks() {
        if (this.mc.field_1769 != null) {
            this.mc.field_1769.method_3279();
        }
    }
}

