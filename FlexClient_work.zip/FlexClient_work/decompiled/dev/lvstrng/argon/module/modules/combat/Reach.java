/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;

public final class Reach
extends Module {
    public static final double MAX_REACH = 10.0;
    private final NumberSetting reach = (NumberSetting)new NumberSetting(EncryptedString.of("Reach"), 0.0, 10.0, 3.0, 0.025).setDescription(EncryptedString.of("Attack reach in blocks. 3.0 = vanilla"));
    private final BooleanSetting onlyWhenSprinting = (BooleanSetting)new BooleanSetting(EncryptedString.of("Only When Sprinting"), false).setDescription(EncryptedString.of("Only apply the extra reach while you are sprinting"));
    private final BooleanSetting preferCloserTarget = (BooleanSetting)new BooleanSetting(EncryptedString.of("Keep Closer Target"), true).setDescription(EncryptedString.of("Never replace a target that vanilla already found closer than the new one"));

    public Reach() {
        super(EncryptedString.of("Reach"), EncryptedString.of("Extends attack reach | 3.0 is vanilla"), -1, Category.COMBAT);
        this.addSettings(this.reach, this.onlyWhenSprinting, this.preferCloserTarget);
    }

    public boolean isActive() {
        if (!this.isEnabled()) {
            return false;
        }
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return false;
        }
        return !this.onlyWhenSprinting.getValue() || this.mc.field_1724.method_5624();
    }

    public double getReach() {
        return this.reach.getValue();
    }

    public boolean shouldKeepCloserTarget() {
        return this.preferCloserTarget.getValue();
    }
}

