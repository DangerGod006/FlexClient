package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.ButtonListener;
import dev.lvstrng.argon.event.events.PacketReceiveListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.LivingEntityAccessor;
import dev.lvstrng.argon.mixin.MinecraftClientAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.Friends;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.Log;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.SwapCoordinator;
import dev.lvstrng.argon.utils.WorldUtils;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2735;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;

/**
 * SpearSwap - Classic ultra-fast spear lunge swap with robust activate key,
 * reach integration, multi-angle entity targeting, and zero XP bar corruption.
 */
public final class SpearSwap
extends Module
implements AttackListener,
TickListener,
ButtonListener,
PacketReceiveListener {
    private final NumberSetting triggerSlot = (NumberSetting)new NumberSetting(EncryptedString.of("Trigger Slot"), 1.0, 9.0, 9.0, 1.0).setDescription(EncryptedString.of("The slot you must be on to activate (1-9)"));
    private final KeybindSetting activateKey = new KeybindSetting(EncryptedString.of("Activate Key"), -1, false);
    private final BooleanSetting autoJump = new BooleanSetting(EncryptedString.of("Auto Jump"), false);
    private final NumberSetting spearReach = (NumberSetting)new NumberSetting(EncryptedString.of("Spear Reach"), 3.0, 6.0, 4.5, 0.05).setDescription(EncryptedString.of("Reach distance in blocks (vanilla is 3.0, spear reaches up to 4.5+ blocks)"));
    private final BooleanSetting undetectable = (BooleanSetting)new BooleanSetting(EncryptedString.of("Undetectable"), true).setDescription(EncryptedString.of("Caps combat reach to server-safe limits (3.25 blocks) to bypass strict anticheats (MCPVP, Minemen, Polar)"));
    private final NumberSetting restoreDelay = (NumberSetting)new NumberSetting(EncryptedString.of("Restore Delay"), 1.0, 10.0, 1.0, 1.0).setDescription(EncryptedString.of("Ticks to wait before swapping back"));
    private final NumberSetting cooldown = (NumberSetting)new NumberSetting(EncryptedString.of("Cooldown"), 0.0, 20.0, 2.0, 1.0).setDescription(EncryptedString.of("Debounce between two operations"));
    private final NumberSetting timeout = (NumberSetting)new NumberSetting(EncryptedString.of("Timeout"), 5.0, 100.0, 20.0, 1.0).setDescription(EncryptedString.of("Abort and restore if an operation never completes"));
    private final BooleanSetting checkCooldown = (BooleanSetting)new BooleanSetting(EncryptedString.of("Check Cooldown"), true).setDescription(EncryptedString.of("Wait until weapon cooldown is ready before swapping"));
    private final BooleanSetting preferLunge = (BooleanSetting)new BooleanSetting(EncryptedString.of("Prefer Lunge"), true).setDescription(EncryptedString.of("Prioritize spears with Lunge or Riptide enchantments"));
    private final BooleanSetting targetPlayers = (BooleanSetting)new BooleanSetting(EncryptedString.of("Target Players"), true).setDescription(EncryptedString.of("Attack player entities"));
    private final BooleanSetting targetMobs = (BooleanSetting)new BooleanSetting(EncryptedString.of("Target Mobs"), true).setDescription(EncryptedString.of("Attack mob entities"));
    private final BooleanSetting switchBack = (BooleanSetting)new BooleanSetting(EncryptedString.of("Switch Back"), true).setDescription(EncryptedString.of("Switch back to original weapon slot after hit"));
    private final BooleanSetting debugMode = (BooleanSetting)new BooleanSetting(EncryptedString.of("Debug"), false).setDescription(EncryptedString.of("Log the state machine and every packet it sends"));

    public enum State {
        IDLE,
        VALIDATING,
        REQUESTED,
        WAITING_SYNC,
        RECOVER,
        INVALID
    }

    private State state = State.IDLE;
    private int spearSlot = -1;
    private int returnSlot = -1;
    private int serverKnownSlot = -1;
    private int stateTicks = 0;
    private int delayTicks = 0;
    private int cooldownTicks = 0;
    private int sequence = 0;
    private boolean waitingForApex = false;
    private boolean movedToSpear = false;
    private int packetsSent = 0;
    private int packetsSuppressed = 0;
    private boolean keyWasDown = false;

    public SpearSwap() {
        super(EncryptedString.of("Spear Swap"), EncryptedString.of("Classic spear swap logic with trigger slot and keybind support"), -1, Category.COMBAT);
        this.addSettings(
            this.triggerSlot,
            this.activateKey,
            this.autoJump,
            this.spearReach,
            this.undetectable,
            this.restoreDelay,
            this.cooldown,
            this.timeout,
            this.checkCooldown,
            this.preferLunge,
            this.targetPlayers,
            this.targetMobs,
            this.switchBack,
            this.debugMode
        );
    }

    @Override
    public void onEnable() {
        this.eventManager.add(AttackListener.class, this);
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(ButtonListener.class, this);
        this.eventManager.add(PacketReceiveListener.class, this);
        this.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        int current;
        this.eventManager.remove(AttackListener.class, this);
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(ButtonListener.class, this);
        this.eventManager.remove(PacketReceiveListener.class, this);
        if (this.state != State.IDLE && this.state != State.INVALID && this.movedToSpear && this.switchBack.getValue() && this.validate("disable") && (current = this.mc.field_1724.method_31548().method_67532()) != this.returnSlot) {
            this.sendSlot(this.returnSlot, "restore on disable");
        }
        SwapCoordinator.releaseLock(this);
        this.reset();
        super.onDisable();
    }

    public double getEffectiveReach() {
        if (this.undetectable.getValue()) {
            return Math.min(3.25, this.spearReach.getValue());
        }
        return this.spearReach.getValue();
    }

    public boolean isReachActive() {
        if (!this.isEnabled()) return false;
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return false;
        if (this.state != State.IDLE) return true;
        class_1799 held = this.mc.field_1724.method_6047();
        if (isSpear(held)) return true;
        int actKey = this.activateKey.getKey();
        if (actKey != -1 && KeyUtils.isKeyPressed(actKey)) {
            return this.findSpear() != -1;
        }
        int reqSlot = this.triggerSlot.getValueInt();
        if (reqSlot > 0) {
            int current = this.mc.field_1724.method_31548().method_67532();
            if (current == (reqSlot - 1)) {
                return this.findSpear() != -1;
            }
        }
        return false;
    }

    public double getSpearReach() {
        if (!this.isReachActive()) return 0.0;
        return this.getEffectiveReach();
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (this.state != State.IDLE || this.cooldownTicks > 0) {
            return;
        }
        if (this.mc.field_1724 == null || this.mc.field_1724.method_31548().method_67532() != this.triggerSlot.getValueInt() - 1) {
            return;
        }
        if (this.begin("attack")) {
            event.cancel();
        }
    }

    @Override
    public void onButtonPress(ButtonListener.ButtonEvent event) {
        if (event.action != 1) {
            return;
        }
        int key = this.activateKey.getKey();
        if (key == -1 || event.button != key) {
            return;
        }
        this.begin("activate key button");
    }

    @Override
    public void onTick() {
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
        }

        // Fix XP progress bar if corrupted
        if (this.mc.field_1724 != null && this.mc.field_1724.field_7510 > 1.0f) {
            this.mc.field_1724.field_7510 = 0.0f;
        }

        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            if (this.state != State.IDLE) {
                this.recover("player or world gone");
            }
            return;
        }

        // Polling fallback for activateKey: ensures mouse buttons or keyboard keys NEVER get missed!
        int actKey = this.activateKey.getKey();
        if (actKey != -1 && this.mc.field_1755 == null) {
            boolean isDown = KeyUtils.isKeyPressed(actKey);
            if (isDown && !this.keyWasDown) {
                if (this.state == State.IDLE && this.cooldownTicks <= 0) {
                    this.begin("activate key poll");
                }
            }
            this.keyWasDown = isDown;
        } else {
            this.keyWasDown = false;
        }

        if (this.state == State.IDLE || this.state == State.INVALID) {
            return;
        }

        ++this.stateTicks;
        if (this.stateTicks > this.timeout.getValueInt()) {
            this.recover("timeout in " + String.valueOf((Object)this.state));
            return;
        }

        if (!this.validate("tick") || !this.spearStillValid()) {
            this.recover("conditions no longer valid");
            return;
        }

        if (this.waitingForApex) {
            if (this.mc.field_1724.method_24828() || this.mc.field_1724.method_18798().field_1351 <= 0.0) {
                this.waitingForApex = false;
                this.step();
            }
            return;
        }

        if (this.state == State.WAITING_SYNC) {
            if (this.delayTicks > 0) {
                --this.delayTicks;
                return;
            }
            this.state = State.RECOVER;
            this.step();
            return;
        }

        this.step();
    }

    @Override
    public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
        if (!(event.packet instanceof class_2735)) {
            return;
        }
        class_2735 packet = (class_2735)event.packet;
        int slot = packet.comp_3325();
        this.logDebug("CORRECTION server slot=" + slot + " tracked=" + this.serverKnownSlot + " state=" + String.valueOf((Object)this.state));
        this.serverKnownSlot = slot;
        if (this.state != State.IDLE) {
            this.movedToSpear = false;
            this.recover("server correction during " + String.valueOf((Object)this.state));
        }
    }

    private boolean begin(String reason) {
        if (this.state != State.IDLE && this.state != State.INVALID) {
            return false;
        }
        if (this.cooldownTicks > 0) {
            this.logDebug("suppressed duplicate request (" + reason + ") - cooldown " + this.cooldownTicks);
            return false;
        }
        if (SwapCoordinator.isLockedByOther(this)) {
            return false;
        }
        if (!this.validate(reason)) {
            return false;
        }
        if (this.checkCooldown.getValue() && this.mc.field_1724.method_7261(0.5f) < 0.70f) {
            this.logDebug("weapon cooldown not ready (" + reason + ")");
            return false;
        }
        int spear = this.findSpear();
        if (spear == -1) {
            this.logDebug("aborted (" + reason + ") - no spear in hotbar");
            return false;
        }
        if (!SwapCoordinator.requestLock(this)) {
            return false;
        }
        this.spearSlot = spear;
        this.returnSlot = this.mc.field_1724.method_31548().method_67532();
        this.state = State.VALIDATING;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.movedToSpear = false;
        this.waitingForApex = false;
        ++this.sequence;
        this.logDebug("ACTION START #" + this.sequence + " reason=" + reason + " | client=" + this.returnSlot + " spear=" + this.spearSlot);
        this.step();
        return true;
    }

    private void step() {
        for (int guard = 0; guard < 8; ++guard) {
            switch (this.state) {
                case VALIDATING: {
                    if (this.autoJump.getValue() && this.mc.field_1724.method_24828() && !this.waitingForApex) {
                        this.mc.field_1724.method_6043();
                        this.waitingForApex = true;
                        this.logDebug("STATE TRANSITION VALIDATING -> waiting for jump apex");
                        return;
                    }
                    this.state = State.REQUESTED;
                    continue;
                }
                case REQUESTED: {
                    int current = this.mc.field_1724.method_31548().method_67532();
                    if (current != this.spearSlot) {
                        this.sendSlot(this.spearSlot, "swap to spear");
                        this.movedToSpear = true;
                    } else {
                        ++this.packetsSuppressed;
                        this.logDebug("no slot packet needed - already on spear slot " + this.spearSlot);
                    }

                    // Execute attack/lunge guaranteed
                    this.performAttack();

                    this.delayTicks = Math.max(1, this.restoreDelay.getValueInt());
                    this.state = State.WAITING_SYNC;
                    this.stateTicks = 0;
                    return;
                }
                case WAITING_SYNC: {
                    if (this.delayTicks > 0) {
                        return;
                    }
                    this.state = State.RECOVER;
                    continue;
                }
                case RECOVER: {
                    this.finish();
                    return;
                }
                default: {
                    return;
                }
            }
        }
    }

    private void performAttack() {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1761 == null) return;

        // Reset weapon attack cooldown to 100% full strength
        ((LivingEntityAccessor)this.mc.field_1724).setLastAttackedTicks(20);
        ((MinecraftClientAccessor)this.mc).setAttackCooldown(0);

        class_1297 target = this.getTarget();
        if (target != null) {
            // 1. Swing hand FIRST (vanilla and anticheat packet order requirement!)
            this.mc.field_1724.method_6104(class_1268.field_5808);
            // 2. Attack entity packet SECOND
            this.mc.field_1761.method_2918(this.mc.field_1724, target);
            this.logDebug("ATTACK entity hit: " + target.method_5477().getString());
        } else {
            // Swing hand
            this.mc.field_1724.method_6104(class_1268.field_5808);
            // Native air/block attack
            ((MinecraftClientAccessor)this.mc).invokeDoAttack();
            this.logDebug("ATTACK air/swing executed");
        }

        // Simulate mouse click for CPS counters and client animations
        MouseSimulation.mouseClick(0);
    }

    private class_1297 getTarget() {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return null;
        double reach = this.getEffectiveReach();

        // 1. Check vanilla crosshair target
        if (this.mc.field_1765 instanceof class_3966) {
            class_1297 ent = ((class_3966)this.mc.field_1765).method_17782();
            if (this.isValidTarget(ent)) return ent;
        }

        // 2. Direct raycast up to spear reach
        class_1297 inReach = WorldUtils.getEntityInReach(reach);
        if (this.isValidTarget(inReach)) {
            return inReach;
        }

        // 3. Generous aim assist cone: closest entity facing within reach
        class_243 eyePos = this.mc.field_1724.method_33571();
        class_243 lookDir = this.mc.field_1724.method_5828(1.0f);
        double bestDot = 0.55; // within ~56 degrees of crosshair
        class_1297 bestTarget = null;
        for (class_1297 e : this.mc.field_1687.method_18112()) {
            if (e != this.mc.field_1724 && this.isValidTarget(e)) {
                class_243 toEntity = e.method_5829().method_1005().method_1020(eyePos).method_1029();
                double dot = lookDir.method_1026(toEntity);
                double dist = this.getDistanceToBox(e);
                if (dot > bestDot && dist <= reach) {
                    bestDot = dot;
                    bestTarget = e;
                }
            }
        }
        return bestTarget;
    }

    private boolean isValidTarget(class_1297 entity) {
        if (entity == null || entity == this.mc.field_1724 || !entity.method_5805()) return false;
        if (entity instanceof class_1309 && ((class_1309)entity).method_29504()) return false;
        if (entity instanceof class_1657) {
            if (!this.targetPlayers.getValue()) return false;
            Friends friends = Argon.INSTANCE.getModuleManager().getModule(Friends.class);
            if (friends != null && friends.isEnabled() && Argon.INSTANCE.getFriendManager().isFriend((class_1657)entity)) {
                return false;
            }
            return true;
        }
        if (entity instanceof class_1309) {
            return this.targetMobs.getValue();
        }
        return false;
    }

    private double getDistanceToBox(class_1297 entity) {
        if (this.mc.field_1724 == null || entity == null) return 999.0;
        class_243 eyePos = this.mc.field_1724.method_33571();
        class_238 box = entity.method_5829();
        double cx = Math.max(box.field_1323, Math.min(eyePos.field_1352, box.field_1320));
        double cy = Math.max(box.field_1322, Math.min(eyePos.field_1351, box.field_1325));
        double cz = Math.max(box.field_1321, Math.min(eyePos.field_1350, box.field_1324));
        return eyePos.method_1022(new class_243(cx, cy, cz));
    }

    private void finish() {
        if (this.switchBack.getValue()) {
            int current = this.mc.field_1724.method_31548().method_67532();
            if (current != this.returnSlot) {
                this.sendSlot(this.returnSlot, "restore original slot");
            } else {
                ++this.packetsSuppressed;
                this.logDebug("no restore packet needed - already back on slot " + this.returnSlot);
            }
        }
        this.logDebug("ACTION FINISH #" + this.sequence + " | restored=" + this.returnSlot + " | packets sent=" + this.packetsSent);
        SwapCoordinator.releaseLock(this);
        this.cooldownTicks = this.cooldown.getValueInt();
        this.reset();
    }

    private void recover(String reason) {
        int current;
        this.logDebug("RECOVERY from " + String.valueOf((Object)this.state) + ": " + reason);
        this.state = State.INVALID;
        if (this.movedToSpear && this.switchBack.getValue() && this.validate("recover") && (current = this.mc.field_1724.method_31548().method_67532()) != this.returnSlot) {
            this.sendSlot(this.returnSlot, "recovery restore");
        }
        SwapCoordinator.releaseLock(this);
        this.reset();
    }

    private void reset() {
        this.state = State.IDLE;
        this.spearSlot = -1;
        this.returnSlot = -1;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.waitingForApex = false;
        this.movedToSpear = false;
    }

    private void sendSlot(int slot, String reason) {
        if (this.mc.field_1761 == null) {
            return;
        }
        InventoryUtils.setInvSlot(slot);
        this.serverKnownSlot = slot;
        ++this.packetsSent;
        this.logDebug("PACKET #" + this.sequence + " UpdateSelectedSlotC2SPacket(" + slot + ") reason=" + reason);
    }

    private boolean validate(String context) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return false;
        }
        if (this.mc.field_1724.method_29504() || !this.mc.field_1724.method_5805()) {
            return false;
        }
        if (this.mc.method_1562() == null || this.mc.field_1761 == null) {
            return false;
        }
        return this.mc.field_1755 == null;
    }

    private boolean spearStillValid() {
        return this.spearSlot >= 0 && this.spearSlot < 9 && isSpear(this.mc.field_1724.method_31548().method_5438(this.spearSlot));
    }

    private int findSpear() {
        if (this.mc.field_1724 == null) {
            return -1;
        }
        int fallback = -1;
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack == null || stack.method_7960()) continue;
            if (this.preferLunge.getValue() && hasLungeEnchant(stack)) {
                return i;
            }
            if (fallback == -1 && isSpear(stack)) {
                fallback = i;
            }
        }
        return fallback;
    }

    private static boolean hasLungeEnchant(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_9304 enchants = stack.method_58657();
        if (enchants == null) return false;
        for (class_6880 entry : enchants.method_57534()) {
            if (!entry.method_40230().isPresent()) continue;
            String id = ((class_5321)entry.method_40230().get()).method_29177().toString().toLowerCase();
            if (id.contains("lunge") || id.contains("riptide")) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSpear(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return WorldUtils.isSpear(stack) || hasLungeEnchant(stack);
    }

    private void logDebug(String message) {
        if (this.debugMode.getValue()) {
            Log.info("[SpearSwap] " + message);
        }
    }
}
