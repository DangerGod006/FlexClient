package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.PacketReceiveListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.mixin.ClientPlayerInteractionManagerAccessor;
import dev.lvstrng.argon.mixin.LivingEntityAccessor;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.Log;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.SwapCoordinator;
import dev.lvstrng.argon.utils.WorldUtils;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2735;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9362;

public final class MaceSwap
extends Module
implements TickListener,
AttackListener,
PacketReceiveListener {
    private final ModeSetting<SwapMode> swapMode = (ModeSetting)new ModeSetting<SwapMode>(EncryptedString.of("Mode"), SwapMode.Normal, SwapMode.class).setDescription(EncryptedString.of("Normal: Client-side swing, Silent: Packet based attack"));
    private final BooleanSetting undetectable = (BooleanSetting)new BooleanSetting(EncryptedString.of("Undetectable"), true).setDescription(EncryptedString.of("Enforces humanized 1-tick pacing, slot sync, and raycast limits to bypass premium servers (MCPVP, Minemen, GrimAC, Polar, etc.)"));
    private final NumberSetting minFallDistance = (NumberSetting)new NumberSetting(EncryptedString.of("Min Fall Distance"), 0.1, 10.0, 1.5, 0.1).setDescription(EncryptedString.of("Minimum fall distance to trigger mace swap"));
    private final NumberSetting densityThreshold = (NumberSetting)new NumberSetting(EncryptedString.of("Density Threshold"), 1.0, 20.0, 7.0, 0.5).setDescription(EncryptedString.of("Fall distance to switch from Breach to Density Mace"));
    private final BooleanSetting targetPlayers = new BooleanSetting(EncryptedString.of("Target Players"), true);
    private final BooleanSetting targetMobs = new BooleanSetting(EncryptedString.of("Target Mobs"), false);
    private final BooleanSetting noPassive = new BooleanSetting(EncryptedString.of("No Passive Mobs"), true);
    private final BooleanSetting autoSwitchBack = new BooleanSetting(EncryptedString.of("Auto Switch Back"), true);
    private final BooleanSetting stayOnMace = new BooleanSetting(EncryptedString.of("Stay On Mace"), false);
    private final BooleanSetting smartEnchant = (BooleanSetting)new BooleanSetting(EncryptedString.of("Smart Enchant"), true).setDescription(EncryptedString.of("Targets Mace with Breach or Density enchantment based on fall distance"));
    private final NumberSetting restoreDelay = (NumberSetting)new NumberSetting(EncryptedString.of("Restore Delay"), 1.0, 10.0, 2.0, 1.0).setDescription(EncryptedString.of("Ticks to wait before restoring previous slot (gives server time to process hit)"));
    private final NumberSetting cooldown = (NumberSetting)new NumberSetting(EncryptedString.of("Cooldown"), 1.0, 20.0, 2.0, 1.0).setDescription(EncryptedString.of("Cooldown in ticks after an operation to prevent repeat spam"));
    private final NumberSetting timeout = (NumberSetting)new NumberSetting(EncryptedString.of("Timeout"), 5.0, 60.0, 20.0, 1.0).setDescription(EncryptedString.of("Maximum ticks before aborting an incomplete swap"));
    private final BooleanSetting spearCombo = (BooleanSetting)new BooleanSetting(EncryptedString.of("Spear Combo"), true).setDescription(EncryptedString.of("Auto swap Spear -> Mace on attack and combo"));
    private final BooleanSetting stunSlam = (BooleanSetting)new BooleanSetting(EncryptedString.of("Stun Slam"), true).setDescription(EncryptedString.of("When target blocks with shield during fall, Axe stuns shield then Mace slams"));
    private final BooleanSetting debugMode = (BooleanSetting)new BooleanSetting(EncryptedString.of("Debug"), false).setDescription(EncryptedString.of("Log state machine transitions and actions"));

    // State machine for clean, undetectable multi-tick execution
    public enum State {
        IDLE,
        SWAP_AXE,
        HIT_AXE,
        SWAP_MACE,
        HIT_MACE,
        RESTORE,
        COOLDOWN
    }

    private State state = State.IDLE;
    private int originalSlot = -1;
    private int targetAxeSlot = -1;
    private int targetMaceSlot = -1;
    private class_1309 currentTarget = null;
    private int stateTicks = 0;
    private int delayTicks = 0;
    private int cooldownTicks = 0;
    private boolean maceHit = false;

    // Fall tracking
    private double fallStartY = -1.0;
    private boolean isFalling = false;

    public MaceSwap() {
        super(EncryptedString.of("Mace Swap"), EncryptedString.of("Auto swaps to mace on fall/hit for maximum smash damage"), -1, Category.COMBAT);
        this.addSettings(
            this.swapMode,
            this.undetectable,
            this.minFallDistance,
            this.densityThreshold,
            this.targetPlayers,
            this.targetMobs,
            this.noPassive,
            this.autoSwitchBack,
            this.stayOnMace,
            this.smartEnchant,
            this.restoreDelay,
            this.cooldown,
            this.timeout,
            this.spearCombo,
            this.stunSlam,
            this.debugMode
        );
    }

    @Override
    public void onEnable() {
        this.eventManager.add(TickListener.class, this);
        this.eventManager.add(AttackListener.class, this);
        this.eventManager.add(PacketReceiveListener.class, this);
        this.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.eventManager.remove(TickListener.class, this);
        this.eventManager.remove(AttackListener.class, this);
        this.eventManager.remove(PacketReceiveListener.class, this);
        if (this.state != State.IDLE) {
            this.recover("module disabled");
        }
        SwapCoordinator.releaseLock(this);
        this.reset();
        super.onDisable();
    }

    /**
     * Lets ShieldDisabler yield to MaceSwap when player is airborne / falling
     * and ready to execute a full Stun Slam combo.
     */
    public boolean shouldHandleShieldStun() {
        if (!this.isEnabled()) return false;
        if (!this.stunSlam.getValue()) return false;
        if (this.mc == null || this.mc.field_1724 == null) return false;
        if (this.findAxeSlot() == -1 || this.findAnyMaceSlot() == -1) return false;
        boolean isAirborne = !this.mc.field_1724.method_24828();
        return isAirborne || (this.isFalling && this.getCurrentFallDistance() >= 0.2);
    }

    @Override
    public void onTick() {
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
        }

        // Validate basic environment
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.method_1562() == null || this.mc.field_1761 == null) {
            if (this.state != State.IDLE) {
                this.recover("player, world, or network disconnected");
            }
            return;
        }

        // Validate player alive and no screen / container open
        if (this.mc.field_1755 != null || !this.mc.field_1724.method_5805() || this.mc.field_1724.method_29504()) {
            if (this.state != State.IDLE) {
                this.recover("screen open or player dead");
            }
            return;
        }

        // Fix XP progress bar if corrupted
        if (this.mc.field_1724.field_7510 > 1.0f) {
            this.mc.field_1724.field_7510 = 0.0f;
        }

        this.updateFallTracking();

        // Timeout guard: never hang on an incomplete state
        if (this.state != State.IDLE && this.state != State.COOLDOWN) {
            ++this.stateTicks;
            if (this.stateTicks > this.timeout.getValueInt()) {
                this.recover("timeout in " + this.state);
                return;
            }
        }

        // Run state machine step
        this.step();
    }

    private void step() {
        switch (this.state) {
            case IDLE: {
                if (this.cooldownTicks > 0 || this.maceHit) return;
                if (!this.isFalling) return;
                if (this.mc.field_1724.method_18798().field_1351 >= -0.05) return;
                double fallDist = this.getCurrentFallDistance();
                if (fallDist < this.minFallDistance.getValue()) return;

                class_1309 target = this.getCrosshairTarget();
                if (target == null || !this.hasValidTarget(target)) return;

                // Weapon attack cooldown check
                if (this.mc.field_1724.method_7261(0.5f) < 0.85f) return;

                boolean isShielding = this.isTargetShielding(target);

                if (isShielding && this.stunSlam.getValue()) {
                    int axe = this.findAxeSlot();
                    int mace = this.getAppropriateMace(fallDist);
                    if (axe != -1 && mace != -1) {
                        if (!SwapCoordinator.requestLock(this)) return;

                        this.originalSlot = this.mc.field_1724.method_31548().method_67532();
                        this.targetAxeSlot = axe;
                        this.targetMaceSlot = mace;
                        this.currentTarget = target;

                        this.logDebug("STUN SLAM AUTO: Axe slot=" + axe + ", Mace slot=" + mace);
                        // Phase 1: Equip Axe & strike shield
                        this.syncSlotTo(this.targetAxeSlot);
                        this.executeAttack(target);

                        // Phase 2: Transition to SWAP_MACE with 1-tick delay so shield disable registers
                        this.state = State.SWAP_MACE;
                        this.stateTicks = 0;
                        this.delayTicks = 1;
                        return;
                    }
                }

                // Normal fall smash against non-shielding target
                int mace = this.getAppropriateMace(fallDist);
                if (mace != -1) {
                    if (!SwapCoordinator.requestLock(this)) return;

                    this.originalSlot = this.mc.field_1724.method_31548().method_67532();
                    this.targetMaceSlot = mace;
                    this.currentTarget = target;

                    this.logDebug("NORMAL MACE SWAP AUTO -> target=" + target.method_5477().getString() + ", maceSlot=" + mace);
                    this.syncSlotTo(mace);
                    this.executeAttack(target);
                    this.maceHit = true;
                    this.delayTicks = Math.max(1, this.restoreDelay.getValueInt());
                    this.state = State.RESTORE;
                    this.stateTicks = 0;
                }
                break;
            }

            case SWAP_AXE: {
                this.syncSlotTo(this.targetAxeSlot);
                this.state = State.HIT_AXE;
                this.stateTicks = 0;
                if (this.undetectable.getValue()) {
                    this.delayTicks = 1;
                    return;
                }
                this.step();
                break;
            }

            case HIT_AXE: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                if (this.currentTarget == null || !this.hasValidTarget(this.currentTarget)) {
                    this.recover("target lost before axe hit");
                    return;
                }

                this.logDebug("HIT_AXE: Striking shield with Axe to disable!");
                this.executeAttack(this.currentTarget);

                // Shield is now disabled! Move to SWAP_MACE
                this.state = State.SWAP_MACE;
                this.stateTicks = 0;
                this.delayTicks = 1;
                break;
            }

            case SWAP_MACE: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                this.logDebug("SWAP_MACE: Equipping Mace on slot " + this.targetMaceSlot);
                this.syncSlotTo(this.targetMaceSlot);
                this.state = State.HIT_MACE;
                this.stateTicks = 0;
                if (this.undetectable.getValue()) {
                    this.delayTicks = 1;
                    return;
                }
                this.step();
                break;
            }

            case HIT_MACE: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                if (this.currentTarget != null && this.currentTarget.method_5805() && !this.currentTarget.method_29504()) {
                    double maxReach = this.undetectable.getValue() ? 3.15 : 3.25;
                    if (this.getDistanceToBox(this.currentTarget) <= maxReach) {
                        this.logDebug("HIT_MACE: Delivering full smash hit on disabled opponent!");
                        this.executeAttack(this.currentTarget);
                    }
                }

                this.maceHit = true;
                this.delayTicks = Math.max(1, this.restoreDelay.getValueInt());
                this.state = State.RESTORE;
                this.stateTicks = 0;
                break;
            }

            case RESTORE: {
                if (this.delayTicks > 0) {
                    --this.delayTicks;
                    return;
                }

                if (this.autoSwitchBack.getValue() && !this.stayOnMace.getValue()) {
                    if (this.originalSlot >= 0 && this.originalSlot < 9) {
                        int current = this.mc.field_1724.method_31548().method_67532();
                        if (current != this.originalSlot) {
                            this.logDebug("RESTORE: Switching back to original slot " + this.originalSlot);
                            this.syncSlotTo(this.originalSlot);
                        }
                    }
                }

                SwapCoordinator.releaseLock(this);
                this.cooldownTicks = this.cooldown.getValueInt();
                this.state = State.COOLDOWN;
                this.stateTicks = 0;
                break;
            }

            case COOLDOWN: {
                if (this.cooldownTicks <= 0) {
                    this.reset();
                }
                break;
            }
        }
    }

    private void executeAttack(class_1309 target) {
        if (target == null || this.mc.field_1724 == null || this.mc.field_1761 == null) return;

        // 1. Reset attack cooldown to 100% full strength
        ((LivingEntityAccessor)this.mc.field_1724).setLastAttackedTicks(20);

        // 2. Swing hand FIRST (vanilla and anticheat packet order requirement!)
        this.mc.field_1724.method_6104(class_1268.field_5808);

        // 3. Send attack packet SECOND
        this.mc.field_1761.method_2918(this.mc.field_1724, (class_1297)target);

        // 4. Simulate mouse click for CPS counters
        MouseSimulation.mouseClick(0);
    }

    /**
     * Decides whether an attack should trigger a swap hit to Mace.
     * Works with Spear (Spear Combo), Sword, or Axe when airborne or falling.
     */
    private boolean shouldTriggerMace(class_1799 heldStack, double fallDist) {
        if (heldStack == null || heldStack.method_7960()) return false;

        // 1. Spear Combo: always combo to Mace on attack
        if (this.spearCombo.getValue() && WorldUtils.isSpear(heldStack)) {
            return true;
        }

        // 2. Sword or Axe: trigger whenever airborne (jump attack) or falling
        boolean isAirborne = !this.mc.field_1724.method_24828();
        boolean isMovingDown = this.mc.field_1724.method_18798().field_1351 < 0.05;
        if (isAirborne && isMovingDown) {
            return true;
        }

        // 3. Fall distance threshold
        return fallDist >= Math.min(0.2, this.minFallDistance.getValue());
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (this.mc == null || this.mc.field_1724 == null || this.mc.field_1687 == null) return;
        if (this.mc.field_1755 != null) return;
        if (this.state != State.IDLE || this.cooldownTicks > 0) return;
        if (SwapCoordinator.isLockedByOther(this)) return;

        class_1799 held = this.mc.field_1724.method_6047();
        int currentSlot = this.mc.field_1724.method_31548().method_67532();

        // If already holding Mace, let attack hit naturally
        if (this.isMaceInSlot(currentSlot)) {
            this.maceHit = true;
            return;
        }

        double fallDist = this.getCurrentFallDistance();
        if (!this.shouldTriggerMace(held, fallDist)) {
            return; // Not a mace swap situation, let normal attack proceed
        }

        class_1309 target = this.getCrosshairTarget();
        if (target == null || !this.hasValidTarget(target)) {
            return; // No valid target in reach, let normal attack proceed
        }

        boolean isShielding = this.isTargetShielding(target);

        // Case 1: STUN SLAM (opponent is shielding during attack)
        if (isShielding && this.stunSlam.getValue()) {
            int axe = this.findAxeSlot();
            int mace = this.getAppropriateMace(fallDist);
            if (axe != -1 && mace != -1) {
                if (!SwapCoordinator.requestLock(this)) return;

                event.cancel(); // Take over attack to execute Axe stun + Mace smash combo
                this.originalSlot = currentSlot;
                this.targetAxeSlot = axe;
                this.targetMaceSlot = mace;
                this.currentTarget = target;

                this.logDebug("STUN SLAM INITIATED (attack): Axe on slot " + axe + ", Mace on slot " + mace);
                // 1. Equip Axe and strike shield with 100% full attack strength
                this.syncSlotTo(this.targetAxeSlot);
                this.executeAttack(target);

                // 2. Shield is disabled! Move to SWAP_MACE state with 1-tick delay
                this.state = State.SWAP_MACE;
                this.stateTicks = 0;
                this.delayTicks = 1;
                return;
            }
        }

        // Case 2: NORMAL MACE SWAP (Sword/Axe/Spear -> Mace Smash)
        int mace = this.getAppropriateMace(fallDist);
        if (mace != -1) {
            if (!SwapCoordinator.requestLock(this)) return;

            event.cancel(); // Cancel vanilla attack so we directly execute the 100% accurate Mace hit!
            this.originalSlot = currentSlot;
            this.targetMaceSlot = mace;
            this.currentTarget = target;

            // 1. Instantly equip Mace
            this.syncSlotTo(mace);

            // 2. Directly hit target with full attack cooldown! 100% accurate!
            this.executeAttack(target);

            // 3. Set maceHit and queue clean restore
            this.maceHit = true;
            this.delayTicks = Math.max(1, this.restoreDelay.getValueInt());
            this.state = State.RESTORE;
            this.stateTicks = 0;
        }
    }

    @Override
    public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
        if (event.packet instanceof class_2735) {
            class_2735 packet = (class_2735)event.packet;
            int serverSlot = packet.comp_3325();
            this.logDebug("Server slot correction: " + serverSlot + " (current state=" + this.state + ")");
            if (this.state != State.IDLE && this.state != State.COOLDOWN) {
                this.recover("server slot override during " + this.state);
            }
        }
    }

    private void syncSlotTo(int slot) {
        if (slot < 0 || slot > 8 || this.mc.field_1724 == null) return;
        this.mc.field_1724.method_31548().method_61496(slot);
        if (this.mc.field_1761 != null) {
            ((ClientPlayerInteractionManagerAccessor)this.mc.field_1761).syncSlot();
        }
    }

    private void recover(String reason) {
        this.logDebug("RECOVERY triggered (" + reason + ") from state=" + this.state);
        if (this.autoSwitchBack.getValue() && !this.stayOnMace.getValue() && this.mc.field_1724 != null) {
            if (this.originalSlot >= 0 && this.originalSlot < 9) {
                int current = this.mc.field_1724.method_31548().method_67532();
                if (current != this.originalSlot) {
                    this.syncSlotTo(this.originalSlot);
                }
            }
        }
        SwapCoordinator.releaseLock(this);
        this.reset();
        this.cooldownTicks = 2;
    }

    private void reset() {
        this.state = State.IDLE;
        this.originalSlot = -1;
        this.targetAxeSlot = -1;
        this.targetMaceSlot = -1;
        this.currentTarget = null;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.maceHit = false;
    }

    private void updateFallTracking() {
        if (this.mc == null || this.mc.field_1724 == null) return;
        boolean onGround = this.mc.field_1724.method_24828();
        double currentY = this.mc.field_1724.method_23318();
        double velY = this.mc.field_1724.method_18798().field_1351;

        if (onGround) {
            this.isFalling = false;
            this.fallStartY = -1.0;
            this.maceHit = false; // Reset lock once safely on ground
        } else {
            if (velY < -0.05) {
                if (!this.isFalling) {
                    this.isFalling = true;
                    this.fallStartY = currentY;
                } else if (this.fallStartY != -1.0 && currentY > this.fallStartY) {
                    this.fallStartY = currentY;
                }
            } else if (velY > 0.08) {
                // Rising upward
                this.fallStartY = currentY;
                this.isFalling = false;
            }
        }
    }

    public double getCurrentFallDistance() {
        if (this.mc == null || this.mc.field_1724 == null) return 0.0;
        double trackedFall = (this.fallStartY == -1.0) ? 0.0 : Math.max(0.0, this.fallStartY - this.mc.field_1724.method_23318());
        return Math.max(trackedFall, (double)this.mc.field_1724.field_6017);
    }

    /**
     * Calculates the true 3D Euclidean distance from the player's eye position
     * to the closest point on the entity's bounding box.
     */
    private double getDistanceToBox(class_1297 entity) {
        if (this.mc.field_1724 == null || entity == null) return Double.MAX_VALUE;
        class_243 eyePos = this.mc.field_1724.method_33571();
        class_238 box = entity.method_5829();
        double cx = Math.max(box.field_1323, Math.min(eyePos.field_1352, box.field_1320));
        double cy = Math.max(box.field_1322, Math.min(eyePos.field_1351, box.field_1325));
        double cz = Math.max(box.field_1321, Math.min(eyePos.field_1350, box.field_1324));
        return eyePos.method_1022(new class_243(cx, cy, cz));
    }

    private class_1309 getCrosshairTarget() {
        if (this.mc == null || this.mc.field_1724 == null) return null;
        double maxReach = this.undetectable.getValue() ? 3.15 : 3.25;

        // 1. Crosshair targeted entity (vanilla raycast)
        if (this.mc.field_1765 instanceof class_3966) {
            class_3966 hit = (class_3966)this.mc.field_1765;
            if (hit.method_17782() instanceof class_1309) {
                class_1309 target = (class_1309)hit.method_17782();
                if (this.getDistanceToBox(target) <= maxReach) {
                    return target;
                }
            }
        }

        // 2. Direct raycast up to legal reach
        class_1297 inReach = WorldUtils.getEntityInReach(maxReach);
        if (inReach instanceof class_1309) {
            return (class_1309)inReach;
        }

        // 3. Generous aim assist cone check: finds the closest entity you are facing towards
        if (this.mc.field_1687 != null) {
            class_243 eyePos = this.mc.field_1724.method_33571();
            class_243 lookDir = this.mc.field_1724.method_5828(1.0f);
            double bestDot = 0.55; // within ~56 degrees of crosshair
            class_1309 bestTarget = null;
            for (class_1297 e : this.mc.field_1687.method_18112()) {
                if (e instanceof class_1309 && e != this.mc.field_1724 && this.hasValidTarget((class_1309)e)) {
                    class_243 toEntity = e.method_5829().method_1005().method_1020(eyePos).method_1029();
                    double dot = lookDir.method_1026(toEntity);
                    if (dot > bestDot && this.getDistanceToBox(e) <= maxReach) {
                        bestDot = dot;
                        bestTarget = (class_1309)e;
                    }
                }
            }
            if (bestTarget != null) {
                return bestTarget;
            }
        }

        return null;
    }

    private boolean isMaceInSlot(int slot) {
        if (slot < 0 || slot > 8 || this.mc.field_1724 == null) return false;
        class_1799 stack = this.mc.field_1724.method_31548().method_5438(slot);
        return stack != null && !stack.method_7960() && stack.method_7909() instanceof class_9362;
    }

    private int getAppropriateMace(double fallDistance) {
        if (this.smartEnchant.getValue()) {
            boolean useDensity = fallDistance >= this.densityThreshold.getValue();
            int slot = useDensity ? this.findMaceWithEnchant("density") : this.findMaceWithEnchant("breach");
            if (slot != -1) return slot;
        }
        return this.findAnyMaceSlot();
    }

    private int findMaceWithEnchant(String enchantName) {
        if (this.mc.field_1724 == null) return -1;
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack == null || stack.method_7960() || !(stack.method_7909() instanceof class_9362)) continue;

            class_9304 enchants = stack.method_58657();
            for (class_6880 entry : enchants.method_57534()) {
                Optional optKey = entry.method_40230();
                if (optKey.isPresent()) {
                    class_5321 regKey = (class_5321)optKey.get();
                    if (regKey.method_29177().method_12832().toLowerCase().contains(enchantName.toLowerCase())) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }

    private int findAnyMaceSlot() {
        if (this.mc.field_1724 == null) return -1;
        for (int i = 0; i < 9; ++i) {
            if (this.isMaceInSlot(i)) {
                return i;
            }
        }
        return -1;
    }

    private int findAxeSlot() {
        if (this.mc.field_1724 == null) return -1;
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (WorldUtils.isAxe(stack)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isTargetShielding(class_1309 target) {
        if (!(target instanceof class_1657)) return false;
        class_1657 player = (class_1657)target;
        try {
            if (player.method_6039()) {
                class_1799 active = player.method_6030();
                boolean hasShield = this.isShield(active) || this.isShield(player.method_6079()) || this.isShield(player.method_6047());
                if (hasShield) {
                    // If target's back is turned towards us, shield is facing away!
                    // No need to waste an axe hit, smash them directly with mace!
                    if (WorldUtils.isShieldFacingAway(player)) {
                        return false;
                    }
                    return true;
                }
            }
            return false;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isShield(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (stack.method_7909() == class_1802.field_8255) return true;
        try {
            String name = stack.method_7909().toString().toLowerCase();
            return name.contains("shield");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean hasValidTarget(class_1309 entity) {
        if (entity == null || entity == this.mc.field_1724) return false;
        if (!entity.method_5805() || entity.method_29504() || entity.method_7325()) return false;

        double maxReach = this.undetectable.getValue() ? 3.15 : 3.25;
        if (this.getDistanceToBox(entity) > maxReach) return false;

        if (entity instanceof class_1657) {
            return this.targetPlayers.getValue();
        }
        if (!this.targetMobs.getValue()) {
            return false;
        }
        if (this.noPassive.getValue() && entity instanceof class_1296) {
            return false;
        }
        return true;
    }

    private void logDebug(String msg) {
        if (this.debugMode.getValue()) {
            Log.info("[MaceSwap] " + msg);
        }
    }

    public static enum SwapMode {
        Normal,
        Silent
    }
}
