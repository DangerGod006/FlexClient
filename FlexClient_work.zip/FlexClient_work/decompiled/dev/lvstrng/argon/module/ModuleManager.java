/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 */
package dev.lvstrng.argon.module;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.ButtonListener;
import dev.lvstrng.argon.gui.ClickGui;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.modules.client.Friends;
import dev.lvstrng.argon.module.modules.client.SelfDestruct;
import dev.lvstrng.argon.module.modules.combat.AimAssist;
import dev.lvstrng.argon.module.modules.combat.AnchorMacro;
import dev.lvstrng.argon.module.modules.combat.AttackHitbox;
import dev.lvstrng.argon.module.modules.combat.AutoCrystal;
import dev.lvstrng.argon.module.modules.combat.AutoDoubleHand;
import dev.lvstrng.argon.module.modules.combat.AutoDrain;
import dev.lvstrng.argon.module.modules.combat.AutoHitCrystal;
import dev.lvstrng.argon.module.modules.combat.AutoInventoryTotem;
import dev.lvstrng.argon.module.modules.combat.AutoJumpReset;
import dev.lvstrng.argon.module.modules.combat.AutoPot;
import dev.lvstrng.argon.module.modules.combat.AutoPotRefill;
import dev.lvstrng.argon.module.modules.combat.AutoWTap;
import dev.lvstrng.argon.module.modules.combat.CrystalOptimizer;
import dev.lvstrng.argon.module.modules.combat.DoubleAnchor;
import dev.lvstrng.argon.module.modules.combat.HitCob;
import dev.lvstrng.argon.module.modules.combat.HoverTotem;
import dev.lvstrng.argon.module.modules.combat.MaceAssist;
import dev.lvstrng.argon.module.modules.combat.MaceSwap;
import dev.lvstrng.argon.module.modules.combat.NoMissDelay;
import dev.lvstrng.argon.module.modules.combat.Reach;
import dev.lvstrng.argon.module.modules.combat.ShieldDisabler;
import dev.lvstrng.argon.module.modules.combat.SpearSwap;
import dev.lvstrng.argon.module.modules.combat.TotemOffhand;
import dev.lvstrng.argon.module.modules.combat.TriggerBot;
import dev.lvstrng.argon.module.modules.misc.AutoClicker;
import dev.lvstrng.argon.module.modules.misc.AutoXP;
import dev.lvstrng.argon.module.modules.misc.BridgeAssist;
import dev.lvstrng.argon.module.modules.misc.FakeLag;
import dev.lvstrng.argon.module.modules.misc.FastPlace;
import dev.lvstrng.argon.module.modules.misc.Fly;
import dev.lvstrng.argon.module.modules.misc.Freecam;
import dev.lvstrng.argon.module.modules.misc.KeyPearl;
import dev.lvstrng.argon.module.modules.misc.NoBreakDelay;
import dev.lvstrng.argon.module.modules.misc.NoHitDelay;
import dev.lvstrng.argon.module.modules.misc.NoJumpDelay;
import dev.lvstrng.argon.module.modules.misc.NoShieldDelay;
import dev.lvstrng.argon.module.modules.misc.PackSpoof;
import dev.lvstrng.argon.module.modules.misc.PingSpoof;
import dev.lvstrng.argon.module.modules.misc.Prevent;
import dev.lvstrng.argon.module.modules.misc.Sprint;
import dev.lvstrng.argon.module.modules.render.BlockESP;
import dev.lvstrng.argon.module.modules.render.Fullbright;
import dev.lvstrng.argon.module.modules.render.HUD;
import dev.lvstrng.argon.module.modules.render.Hitbox;
import dev.lvstrng.argon.module.modules.render.NoBounce;
import dev.lvstrng.argon.module.modules.render.PlayerESP;
import dev.lvstrng.argon.module.modules.render.StorageEsp;
import dev.lvstrng.argon.module.modules.render.TargetHud;
import dev.lvstrng.argon.module.modules.render.Trajectory;
import dev.lvstrng.argon.module.modules.render.Xray;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.Setting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class ModuleManager
implements ButtonListener {
    private final List<Module> modules = new ArrayList<Module>();

    public ModuleManager() {
        this.addModules();
        this.addKeybinds();
    }

    public void addModules() {
        this.add(new AimAssist());
        AnchorMacro anchorMacro = new AnchorMacro();
        this.add(anchorMacro);
        this.add(new AutoCrystal());
        this.add(new AutoDrain());
        this.add(new AutoDoubleHand());
        this.add(new AutoHitCrystal());
        this.add(new AutoInventoryTotem());
        this.add(new TriggerBot());
        this.add(new AutoPot());
        this.add(new AutoPotRefill());
        this.add(new AutoWTap());
        this.add(new CrystalOptimizer());
        this.add(new DoubleAnchor());
        this.add(new HoverTotem());
        this.add(new NoMissDelay());
        this.add(new AttackHitbox());
        this.add(new Reach());
        this.add(new ShieldDisabler());
        this.add(new TotemOffhand());
        this.add(new AutoJumpReset());
        this.add(new MaceSwap());
        this.add(new HitCob());
        this.add(new MaceAssist());
        this.add(new SpearSwap());
        this.add(new Prevent());
        this.add(new AutoXP());
        this.add(new NoJumpDelay());
        this.add(new PingSpoof());
        this.add(new FakeLag());
        this.add(new AutoClicker());
        this.add(new KeyPearl());
        this.add(new NoBreakDelay());
        this.add(new Freecam());
        this.add(new Fly());
        this.add(new PackSpoof());
        this.add(new FastPlace());
        this.add(new BridgeAssist());
        this.add(new NoShieldDelay());
        this.add(new NoHitDelay());
        Sprint sprint = new Sprint();
        this.add(sprint);
        HUD hud = new HUD();
        this.add(hud);
        this.add(new NoBounce());
        this.add(new PlayerESP());
        this.add(new Hitbox());
        this.add(new StorageEsp());
        TargetHud targetHud = new TargetHud();
        this.add(targetHud);
        this.add(new Trajectory());
        this.add(new Xray());
        this.add(new Fullbright());
        this.add(new BlockESP());
        this.add(new ClickGUI());
        this.add(new Friends());
        this.add(new SelfDestruct());
        hud.setEnabledStatus(true);
        hud.onEnable();
        targetHud.setEnabledStatus(true);
        targetHud.onEnable();
    }

    public List<Module> getEnabledModules() {
        return this.modules.stream().filter(v0 -> v0.isEnabled()).toList();
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public void addKeybinds() {
        Argon.INSTANCE.getEventManager().add(ButtonListener.class, this);
        for (Module module : this.modules) {
            module.addSetting((Setting<?>)new KeybindSetting(EncryptedString.of("Keybind"), module.getKey(), true).setDescription(EncryptedString.of("Key to enabled the module")));
        }
        this.logKeybindConflicts();
    }

    public List<Module> getModulesInCategory(Category category) {
        return this.modules.stream().filter(module -> module.getCategory() == category).toList();
    }

    public <T extends Module> T getModule(Class<T> moduleClass) {
        Stream stream = this.modules.stream();
        Module module = stream.filter(moduleClass::isInstance).findFirst().orElse(null);
        return (T)(module == null ? null : (Module)moduleClass.cast(module));
    }

    public void add(Module module) {
        this.modules.add(module);
    }

    @Override
    public void onButtonPress(ButtonListener.ButtonEvent event) {
        if (SelfDestruct.destruct || event.action != 1) {
            return;
        }
        class_310 mc = class_310.method_1551();
        class_437 screen = mc.field_1755;
        if (screen != null && !(screen instanceof ClickGui)) {
            return;
        }
        if (this.isCapturingInput()) {
            return;
        }
        for (Module module : this.modules) {
            int key = module.getKey();
            if (key < 0 || key != event.button) continue;
            module.toggle();
        }
    }

    private boolean isCapturingInput() {
        for (Module module : this.modules) {
            for (Setting<?> setting : module.getSettings()) {
                KeybindSetting keybind;
                if (!(setting instanceof KeybindSetting) || !(keybind = (KeybindSetting)setting).isListening()) continue;
                return true;
            }
        }
        return false;
    }

    private void logKeybindConflicts() {
        HashMap<Integer, List> byKey = new HashMap<Integer, List>();
        for (Module module : this.modules) {
            int key = module.getKey();
            if (key < 0) continue;
            byKey.computeIfAbsent(key, k -> new ArrayList()).add(module.getName().toString());
        }
        for (Map.Entry entry : byKey.entrySet()) {
            List names = (List)entry.getValue();
            if (names.size() <= 1) continue;
            Log.warn("Keybind conflict: %s are all bound to key code %d", String.join((CharSequence)", ", names), entry.getKey());
        }
    }
}

