/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.module.setting;

import dev.lvstrng.argon.module.setting.Setting;

public class StringSetting
extends Setting<StringSetting> {
    public String value;
    private final String originalValue;

    public StringSetting(CharSequence name, String defaultValue) {
        super(name);
        this.value = defaultValue;
        this.originalValue = defaultValue;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public String getOriginalValue() {
        return this.originalValue;
    }
}

