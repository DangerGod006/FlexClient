/*
 * Decompiled with CFR 0.152.
 */
package dev.lvstrng.argon.module;

import dev.lvstrng.argon.utils.EncryptedString;

public enum Category {
    COMBAT(EncryptedString.of("Combat")),
    MISC(EncryptedString.of("Misc")),
    RENDER(EncryptedString.of("Render")),
    CLIENT(EncryptedString.of("Client"));

    public final CharSequence name;

    private Category(CharSequence name) {
        this.name = name;
    }
}

